
  int nbin    = 400;
  double xmin = 60.0;
  double xmax = 150.0;

// Form-factors:
//  _001_1 - first bit is flavour, second real/im, third FF number,
//           _1 - bin in costheta

  TH1D* hFF_000_1 = new TH1D("hFF_000_1"," ",nbin,xmin,xmax);
  TH1D* hFF_000_2 = new TH1D("hFF_000_2"," ",nbin,xmin,xmax);
  TH1D* hFF_000_3 = new TH1D("hFF_000_3"," ",nbin,xmin,xmax);
  TH1D* hFF_000_4 = new TH1D("hFF_000_4"," ",nbin,xmin,xmax);
  TH1D* hFF_000_5 = new TH1D("hFF_000_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_010_1 = new TH1D("hFF_010_1"," ",nbin,xmin,xmax);
  TH1D* hFF_010_2 = new TH1D("hFF_010_2"," ",nbin,xmin,xmax);
  TH1D* hFF_010_3 = new TH1D("hFF_010_3"," ",nbin,xmin,xmax);
  TH1D* hFF_010_4 = new TH1D("hFF_010_4"," ",nbin,xmin,xmax);
  TH1D* hFF_010_5 = new TH1D("hFF_010_5"," ",nbin,xmin,xmax);

  TH1D* hFF_001_1 = new TH1D("hFF_001_1"," ",nbin,xmin,xmax);
  TH1D* hFF_001_2 = new TH1D("hFF_001_2"," ",nbin,xmin,xmax);
  TH1D* hFF_001_3 = new TH1D("hFF_001_3"," ",nbin,xmin,xmax);
  TH1D* hFF_001_4 = new TH1D("hFF_001_4"," ",nbin,xmin,xmax);
  TH1D* hFF_001_5 = new TH1D("hFF_001_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_011_1 = new TH1D("hFF_011_1"," ",nbin,xmin,xmax);
  TH1D* hFF_011_2 = new TH1D("hFF_011_2"," ",nbin,xmin,xmax);
  TH1D* hFF_011_3 = new TH1D("hFF_011_3"," ",nbin,xmin,xmax);
  TH1D* hFF_011_4 = new TH1D("hFF_011_4"," ",nbin,xmin,xmax);
  TH1D* hFF_011_5 = new TH1D("hFF_011_5"," ",nbin,xmin,xmax);
  
  TH1D* hFF_002_1 = new TH1D("hFF_002_1"," ",nbin,xmin,xmax);
  TH1D* hFF_002_2 = new TH1D("hFF_002_2"," ",nbin,xmin,xmax);
  TH1D* hFF_002_3 = new TH1D("hFF_002_3"," ",nbin,xmin,xmax);
  TH1D* hFF_002_4 = new TH1D("hFF_002_4"," ",nbin,xmin,xmax);
  TH1D* hFF_002_5 = new TH1D("hFF_002_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_012_1 = new TH1D("hFF_012_1"," ",nbin,xmin,xmax);
  TH1D* hFF_012_2 = new TH1D("hFF_012_2"," ",nbin,xmin,xmax);
  TH1D* hFF_012_3 = new TH1D("hFF_012_3"," ",nbin,xmin,xmax);
  TH1D* hFF_012_4 = new TH1D("hFF_012_4"," ",nbin,xmin,xmax);
  TH1D* hFF_012_5 = new TH1D("hFF_012_5"," ",nbin,xmin,xmax);
  
  TH1D* hFF_003_1 = new TH1D("hFF_003_1"," ",nbin,xmin,xmax);
  TH1D* hFF_003_2 = new TH1D("hFF_003_2"," ",nbin,xmin,xmax);
  TH1D* hFF_003_3 = new TH1D("hFF_003_3"," ",nbin,xmin,xmax);
  TH1D* hFF_003_4 = new TH1D("hFF_003_4"," ",nbin,xmin,xmax);
  TH1D* hFF_003_5 = new TH1D("hFF_003_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_013_1 = new TH1D("hFF_013_1"," ",nbin,xmin,xmax);
  TH1D* hFF_013_2 = new TH1D("hFF_013_2"," ",nbin,xmin,xmax);
  TH1D* hFF_013_3 = new TH1D("hFF_013_3"," ",nbin,xmin,xmax);
  TH1D* hFF_013_4 = new TH1D("hFF_013_4"," ",nbin,xmin,xmax);
  TH1D* hFF_013_5 = new TH1D("hFF_013_5"," ",nbin,xmin,xmax);
  
  TH1D* hFF_006_1 = new TH1D("hFF_006_1"," ",nbin,xmin,xmax);
  TH1D* hFF_006_2 = new TH1D("hFF_006_2"," ",nbin,xmin,xmax);
  TH1D* hFF_006_3 = new TH1D("hFF_006_3"," ",nbin,xmin,xmax);
  TH1D* hFF_006_4 = new TH1D("hFF_006_4"," ",nbin,xmin,xmax);
  TH1D* hFF_006_5 = new TH1D("hFF_006_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_016_1 = new TH1D("hFF_016_1"," ",nbin,xmin,xmax);
  TH1D* hFF_016_2 = new TH1D("hFF_016_2"," ",nbin,xmin,xmax);
  TH1D* hFF_016_3 = new TH1D("hFF_016_3"," ",nbin,xmin,xmax);
  TH1D* hFF_016_4 = new TH1D("hFF_016_4"," ",nbin,xmin,xmax);
  TH1D* hFF_016_5 = new TH1D("hFF_016_5"," ",nbin,xmin,xmax);

//---------------------

  TH1D* hFF_100_1 = new TH1D("hFF_100_1"," ",nbin,xmin,xmax);
  TH1D* hFF_100_2 = new TH1D("hFF_100_2"," ",nbin,xmin,xmax);
  TH1D* hFF_100_3 = new TH1D("hFF_100_3"," ",nbin,xmin,xmax);
  TH1D* hFF_100_4 = new TH1D("hFF_100_4"," ",nbin,xmin,xmax);
  TH1D* hFF_100_5 = new TH1D("hFF_100_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_110_1 = new TH1D("hFF_110_1"," ",nbin,xmin,xmax);
  TH1D* hFF_110_2 = new TH1D("hFF_110_2"," ",nbin,xmin,xmax);
  TH1D* hFF_110_3 = new TH1D("hFF_110_3"," ",nbin,xmin,xmax);
  TH1D* hFF_110_4 = new TH1D("hFF_110_4"," ",nbin,xmin,xmax);
  TH1D* hFF_110_5 = new TH1D("hFF_110_5"," ",nbin,xmin,xmax);

  TH1D* hFF_101_1 = new TH1D("hFF_101_1"," ",nbin,xmin,xmax);
  TH1D* hFF_101_2 = new TH1D("hFF_101_2"," ",nbin,xmin,xmax);
  TH1D* hFF_101_3 = new TH1D("hFF_101_3"," ",nbin,xmin,xmax);
  TH1D* hFF_101_4 = new TH1D("hFF_101_4"," ",nbin,xmin,xmax);
  TH1D* hFF_101_5 = new TH1D("hFF_101_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_111_1 = new TH1D("hFF_111_1"," ",nbin,xmin,xmax);
  TH1D* hFF_111_2 = new TH1D("hFF_111_2"," ",nbin,xmin,xmax);
  TH1D* hFF_111_3 = new TH1D("hFF_111_3"," ",nbin,xmin,xmax);
  TH1D* hFF_111_4 = new TH1D("hFF_111_4"," ",nbin,xmin,xmax);
  TH1D* hFF_111_5 = new TH1D("hFF_111_5"," ",nbin,xmin,xmax);
  
  TH1D* hFF_102_1 = new TH1D("hFF_102_1"," ",nbin,xmin,xmax);
  TH1D* hFF_102_2 = new TH1D("hFF_102_2"," ",nbin,xmin,xmax);
  TH1D* hFF_102_3 = new TH1D("hFF_102_3"," ",nbin,xmin,xmax);
  TH1D* hFF_102_4 = new TH1D("hFF_102_4"," ",nbin,xmin,xmax);
  TH1D* hFF_102_5 = new TH1D("hFF_102_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_112_1 = new TH1D("hFF_112_1"," ",nbin,xmin,xmax);
  TH1D* hFF_112_2 = new TH1D("hFF_112_2"," ",nbin,xmin,xmax);
  TH1D* hFF_112_3 = new TH1D("hFF_112_3"," ",nbin,xmin,xmax);
  TH1D* hFF_112_4 = new TH1D("hFF_112_4"," ",nbin,xmin,xmax);
  TH1D* hFF_112_5 = new TH1D("hFF_112_5"," ",nbin,xmin,xmax);
  
  TH1D* hFF_103_1 = new TH1D("hFF_103_1"," ",nbin,xmin,xmax);
  TH1D* hFF_103_2 = new TH1D("hFF_103_2"," ",nbin,xmin,xmax);
  TH1D* hFF_103_3 = new TH1D("hFF_103_3"," ",nbin,xmin,xmax);
  TH1D* hFF_103_4 = new TH1D("hFF_103_4"," ",nbin,xmin,xmax);
  TH1D* hFF_103_5 = new TH1D("hFF_103_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_113_1 = new TH1D("hFF_113_1"," ",nbin,xmin,xmax);
  TH1D* hFF_113_2 = new TH1D("hFF_113_2"," ",nbin,xmin,xmax);
  TH1D* hFF_113_3 = new TH1D("hFF_113_3"," ",nbin,xmin,xmax);
  TH1D* hFF_113_4 = new TH1D("hFF_113_4"," ",nbin,xmin,xmax);
  TH1D* hFF_113_5 = new TH1D("hFF_113_5"," ",nbin,xmin,xmax);
  
  TH1D* hFF_106_1 = new TH1D("hFF_106_1"," ",nbin,xmin,xmax);
  TH1D* hFF_106_2 = new TH1D("hFF_106_2"," ",nbin,xmin,xmax);
  TH1D* hFF_106_3 = new TH1D("hFF_106_3"," ",nbin,xmin,xmax);
  TH1D* hFF_106_4 = new TH1D("hFF_106_4"," ",nbin,xmin,xmax);
  TH1D* hFF_106_5 = new TH1D("hFF_106_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_116_1 = new TH1D("hFF_116_1"," ",nbin,xmin,xmax);
  TH1D* hFF_116_2 = new TH1D("hFF_116_2"," ",nbin,xmin,xmax);
  TH1D* hFF_116_3 = new TH1D("hFF_116_3"," ",nbin,xmin,xmax);
  TH1D* hFF_116_4 = new TH1D("hFF_116_4"," ",nbin,xmin,xmax);
  TH1D* hFF_116_5 = new TH1D("hFF_116_5"," ",nbin,xmin,xmax);

//---------------------

  TH1D* hFF_200_1 = new TH1D("hFF_200_1"," ",nbin,xmin,xmax);
  TH1D* hFF_200_2 = new TH1D("hFF_200_2"," ",nbin,xmin,xmax);
  TH1D* hFF_200_3 = new TH1D("hFF_200_3"," ",nbin,xmin,xmax);
  TH1D* hFF_200_4 = new TH1D("hFF_200_4"," ",nbin,xmin,xmax);
  TH1D* hFF_200_5 = new TH1D("hFF_200_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_210_1 = new TH1D("hFF_210_1"," ",nbin,xmin,xmax);
  TH1D* hFF_210_2 = new TH1D("hFF_210_2"," ",nbin,xmin,xmax);
  TH1D* hFF_210_3 = new TH1D("hFF_210_3"," ",nbin,xmin,xmax);
  TH1D* hFF_210_4 = new TH1D("hFF_210_4"," ",nbin,xmin,xmax);
  TH1D* hFF_210_5 = new TH1D("hFF_210_5"," ",nbin,xmin,xmax);

  TH1D* hFF_201_1 = new TH1D("hFF_201_1"," ",nbin,xmin,xmax);
  TH1D* hFF_201_2 = new TH1D("hFF_201_2"," ",nbin,xmin,xmax);
  TH1D* hFF_201_3 = new TH1D("hFF_201_3"," ",nbin,xmin,xmax);
  TH1D* hFF_201_4 = new TH1D("hFF_201_4"," ",nbin,xmin,xmax);
  TH1D* hFF_201_5 = new TH1D("hFF_201_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_211_1 = new TH1D("hFF_211_1"," ",nbin,xmin,xmax);
  TH1D* hFF_211_2 = new TH1D("hFF_211_2"," ",nbin,xmin,xmax);
  TH1D* hFF_211_3 = new TH1D("hFF_211_3"," ",nbin,xmin,xmax);
  TH1D* hFF_211_4 = new TH1D("hFF_211_4"," ",nbin,xmin,xmax);
  TH1D* hFF_211_5 = new TH1D("hFF_211_5"," ",nbin,xmin,xmax);
  
  TH1D* hFF_202_1 = new TH1D("hFF_202_1"," ",nbin,xmin,xmax);
  TH1D* hFF_202_2 = new TH1D("hFF_202_2"," ",nbin,xmin,xmax);
  TH1D* hFF_202_3 = new TH1D("hFF_202_3"," ",nbin,xmin,xmax);
  TH1D* hFF_202_4 = new TH1D("hFF_202_4"," ",nbin,xmin,xmax);
  TH1D* hFF_202_5 = new TH1D("hFF_202_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_212_1 = new TH1D("hFF_212_1"," ",nbin,xmin,xmax);
  TH1D* hFF_212_2 = new TH1D("hFF_212_2"," ",nbin,xmin,xmax);
  TH1D* hFF_212_3 = new TH1D("hFF_212_3"," ",nbin,xmin,xmax);
  TH1D* hFF_212_4 = new TH1D("hFF_212_4"," ",nbin,xmin,xmax);
  TH1D* hFF_212_5 = new TH1D("hFF_212_5"," ",nbin,xmin,xmax);
  
  TH1D* hFF_203_1 = new TH1D("hFF_203_1"," ",nbin,xmin,xmax);
  TH1D* hFF_203_2 = new TH1D("hFF_203_2"," ",nbin,xmin,xmax);
  TH1D* hFF_203_3 = new TH1D("hFF_203_3"," ",nbin,xmin,xmax);
  TH1D* hFF_203_4 = new TH1D("hFF_203_4"," ",nbin,xmin,xmax);
  TH1D* hFF_203_5 = new TH1D("hFF_203_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_213_1 = new TH1D("hFF_213_1"," ",nbin,xmin,xmax);
  TH1D* hFF_213_2 = new TH1D("hFF_213_2"," ",nbin,xmin,xmax);
  TH1D* hFF_213_3 = new TH1D("hFF_213_3"," ",nbin,xmin,xmax);
  TH1D* hFF_213_4 = new TH1D("hFF_213_4"," ",nbin,xmin,xmax);
  TH1D* hFF_213_5 = new TH1D("hFF_213_5"," ",nbin,xmin,xmax);
  
  TH1D* hFF_206_1 = new TH1D("hFF_206_1"," ",nbin,xmin,xmax);
  TH1D* hFF_206_2 = new TH1D("hFF_206_2"," ",nbin,xmin,xmax);
  TH1D* hFF_206_3 = new TH1D("hFF_206_3"," ",nbin,xmin,xmax);
  TH1D* hFF_206_4 = new TH1D("hFF_206_4"," ",nbin,xmin,xmax);
  TH1D* hFF_206_5 = new TH1D("hFF_206_5"," ",nbin,xmin,xmax);
 
  TH1D* hFF_216_1 = new TH1D("hFF_216_1"," ",nbin,xmin,xmax);
  TH1D* hFF_216_2 = new TH1D("hFF_216_2"," ",nbin,xmin,xmax);
  TH1D* hFF_216_3 = new TH1D("hFF_216_3"," ",nbin,xmin,xmax);
  TH1D* hFF_216_4 = new TH1D("hFF_216_4"," ",nbin,xmin,xmax);
  TH1D* hFF_216_5 = new TH1D("hFF_216_5"," ",nbin,xmin,xmax);


//---------------------

void writeHistos(){

  // leptons
  
  hFF_000_1->Write();
  hFF_010_1->Write();
  hFF_000_2->Write();
  hFF_010_2->Write();
  hFF_000_3->Write();
  hFF_010_3->Write();
  hFF_000_4->Write();
  hFF_010_4->Write();
  hFF_000_5->Write();
  hFF_010_5->Write();

  hFF_001_1->Write();
  hFF_011_1->Write();
  hFF_001_2->Write();
  hFF_011_2->Write();
  hFF_001_3->Write();
  hFF_011_3->Write();
  hFF_001_4->Write();
  hFF_011_4->Write();
  hFF_001_5->Write();
  hFF_011_5->Write();

  hFF_002_1->Write();
  hFF_012_1->Write();
  hFF_002_2->Write();
  hFF_012_2->Write();
  hFF_002_3->Write();
  hFF_012_3->Write();
  hFF_002_4->Write();
  hFF_012_4->Write();
  hFF_002_5->Write();
  hFF_012_5->Write();

  hFF_003_1->Write();
  hFF_013_1->Write();
  hFF_003_2->Write();
  hFF_013_2->Write();
  hFF_003_3->Write();
  hFF_013_3->Write();
  hFF_003_4->Write();
  hFF_013_4->Write();
  hFF_003_5->Write();
  hFF_013_5->Write();

  hFF_006_1->Write();
  hFF_016_1->Write();
  hFF_006_2->Write();
  hFF_016_2->Write();
  hFF_006_3->Write();
  hFF_016_3->Write();
  hFF_006_4->Write();
  hFF_016_4->Write();
  hFF_006_5->Write();
  hFF_016_5->Write();

  // down quarks
  
  hFF_100_1->Write();
  hFF_110_1->Write();
  hFF_100_2->Write();
  hFF_110_2->Write();
  hFF_100_3->Write();
  hFF_110_3->Write();
  hFF_100_4->Write();
  hFF_110_4->Write();
  hFF_100_5->Write();
  hFF_110_5->Write();

  hFF_101_1->Write();
  hFF_111_1->Write();
  hFF_101_2->Write();
  hFF_111_2->Write();
  hFF_101_3->Write();
  hFF_111_3->Write();
  hFF_101_4->Write();
  hFF_111_4->Write();
  hFF_101_5->Write();
  hFF_111_5->Write();

  hFF_102_1->Write();
  hFF_112_1->Write();
  hFF_102_2->Write();
  hFF_112_2->Write();
  hFF_102_3->Write();
  hFF_112_3->Write();
  hFF_102_4->Write();
  hFF_112_4->Write();
  hFF_102_5->Write();
  hFF_112_5->Write();

  hFF_103_1->Write();
  hFF_113_1->Write();
  hFF_103_2->Write();
  hFF_113_2->Write();
  hFF_103_3->Write();
  hFF_113_3->Write();
  hFF_103_4->Write();
  hFF_113_4->Write();
  hFF_103_5->Write();
  hFF_113_5->Write();

  hFF_106_1->Write();
  hFF_116_1->Write();
  hFF_106_2->Write();
  hFF_116_2->Write();
  hFF_106_3->Write();
  hFF_116_3->Write();
  hFF_106_4->Write();
  hFF_116_4->Write();
  hFF_106_5->Write();
  hFF_116_5->Write();

  // up quarks
  
  hFF_200_1->Write();
  hFF_210_1->Write();
  hFF_200_2->Write();
  hFF_210_2->Write();
  hFF_200_3->Write();
  hFF_210_3->Write();
  hFF_200_4->Write();
  hFF_210_4->Write();
  hFF_200_5->Write();
  hFF_210_5->Write();

  hFF_201_1->Write();
  hFF_211_1->Write();
  hFF_201_2->Write();
  hFF_211_2->Write();
  hFF_201_3->Write();
  hFF_211_3->Write();
  hFF_201_4->Write();
  hFF_211_4->Write();
  hFF_201_5->Write();
  hFF_211_5->Write();

  hFF_202_1->Write();
  hFF_212_1->Write();
  hFF_202_2->Write();
  hFF_212_2->Write();
  hFF_202_3->Write();
  hFF_212_3->Write();
  hFF_202_4->Write();
  hFF_212_4->Write();
  hFF_202_5->Write();
  hFF_212_5->Write();

  hFF_203_1->Write();
  hFF_213_1->Write();
  hFF_203_2->Write();
  hFF_213_2->Write();
  hFF_203_3->Write();
  hFF_213_3->Write();
  hFF_203_4->Write();
  hFF_213_4->Write();
  hFF_203_5->Write();
  hFF_213_5->Write();

  hFF_206_1->Write();
  hFF_216_1->Write();
  hFF_206_2->Write();
  hFF_216_2->Write();
  hFF_206_3->Write();
  hFF_216_3->Write();
  hFF_206_4->Write();
  hFF_216_4->Write();
  hFF_206_5->Write();
  hFF_216_5->Write();


}
