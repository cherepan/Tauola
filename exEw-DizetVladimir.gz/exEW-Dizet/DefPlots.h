void ATLASLabel(Double_t x,Double_t y,const char* text,Color_t color=1) 
{
  TLatex l; //l.SetTextAlign(12); l.SetTextSize(tsize); 
  l.SetNDC();
  l.SetTextFont(32);
  l.SetTextColor(color);

  double delx = 0.115*696*gPad->GetWh()/(472*gPad->GetWw());

  l.DrawLatex(x,y,"ATLAS");
  if (text) {
    TLatex p; 
    p.SetNDC();
    p.SetTextFont(42);
    p.SetTextColor(color);
    p.DrawLatex(x+delx,y,text);
    //    p.DrawLatex(x,y,"#sqrt{s}=900GeV");
  }
}

void drawOneLogx(TH1D* histRef, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
             TString legend1, TString legend2, TString legend3, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  c->SetLogx(1);

  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);
  /*
  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    histRef->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    histRef->SetMinimum(minhist);
  }
  */

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  //  histRef->SetFillColor(kOrange);
  //  histRef->SetLineColor(kOrange);
  //  histRef->Draw("hist");
  histRef->SetMarkerColor(kBlack);
  histRef->SetMarkerStyle(20);
  histRef->Draw("p e");

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lp ");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0,xmax,0);
  line->Draw("p e same");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoLogx(TH1D* histRef,TH1D* hist, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
             TString legend1, TString legend2, TString legend3, TString legend4, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist = (TH1D*) hist->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  c->SetLogx(1);

  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);
  /*
  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    histRef->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    histRef->SetMinimum(minhist);
  }
  */

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  //  histRef->SetFillColor(kOrange);
  //  histRef->SetLineColor(kOrange);
  //  histRef->Draw("hist");
  histRef->SetMarkerColor(kBlack);
  histRef->SetMarkerStyle(20);
  histRef->Draw("p e");
  hist->SetMarkerColor(kBlack);
  hist->SetMarkerStyle(24);
  hist->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lp ");
  leg->AddEntry(hist   , legend4," lp ");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0,xmax,0);
  line->Draw("p e same");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void draw2Dlego(TH2F* hist, TString figname, float divMaximum, float divMinimum, TString Xlabel, TString Ylabel, TString legend){
 //------------------------------------------  
    TCanvas *c1 = new TCanvas("c1", "c1",66,52,698,500);
   gStyle->SetOptFit(1);
   gStyle->SetOptStat(0);
   gStyle->SetOptTitle(0);
   c1->Range(-96.139,-7.032086,707.722,5.641711);
   c1->SetFillColor(0);
   c1->SetBorderMode(0);
   c1->SetBorderSize(2);
   c1->SetTickx(1);
   c1->SetTicky(1);
   c1->SetLeftMargin(0.1195965);
   c1->SetRightMargin(0.1340058);
   c1->SetTopMargin(0.05063291);
   c1->SetBottomMargin(0.1603376);
   c1->SetFrameBorderMode(0);
   c1->SetFrameBorderMode(0);
   float divMaximum= 1.1 * hist->GetMaximum();
   float divMinimum= 0.0;
   if( hist->GetMinimum() < 0 ) divMinimum = 1.1 * hist->GetMinimum();
   hist->SetMaximum(divMaximum);
   hist->SetMinimum(divMinimum);
   hist->SetTitle(legend);
   hist->GetXaxis()->SetTitle(Xlabel);
   hist->GetYaxis()->SetTitle(Ylabel);
   hist->Draw("lego");

   c1->Print("figures/"+figname+".eps"); 
   c1->Print("figures/"+figname+".pdf"); 
   c1->Print("figures/"+figname+".C"); 


}
void draw2Dcolz(TH2F* hist, TString figname, float divMaximum, float divMinimum, TString Xlabel, TString Ylabel, TString legend){
 //------------------------------------------  
    TCanvas *c1 = new TCanvas("c1", "c1",66,52,698,500);
   gStyle->SetOptFit(1);
   gStyle->SetOptStat(0);
   gStyle->SetOptTitle(0);
   c1->Range(-96.139,-7.032086,707.722,5.641711);
   c1->SetFillColor(0);
   c1->SetBorderMode(0);
   c1->SetBorderSize(2);
   c1->SetTickx(1);
   c1->SetTicky(1);
   c1->SetLeftMargin(0.1195965);
   c1->SetRightMargin(0.1340058);
   c1->SetTopMargin(0.05063291);
   c1->SetBottomMargin(0.1603376);
   c1->SetFrameBorderMode(0);
   c1->SetFrameBorderMode(0);
   float divMaximum= 1.3 * hist->GetMaximum();
   float divMinimum= 0.0;
   if( hist->GetMinimum() < 0 ) divMinimum = 1.3 * hist->GetMinimum();
   hist->SetMaximum(divMaximum);
   hist->SetMinimum(divMinimum);
   hist->GetXaxis()->SetTitle(legend + "          " + Xlabel);
   hist->GetYaxis()->SetTitle(Ylabel);
   hist->Draw("colz");

   c1->Print("figures/"+figname+".eps"); 
   c1->Print("figures/"+figname+".pdf"); 
   c1->Print("figures/"+figname+".C"); 


}

void drawClosure(TH1D* hist, TH1D* histRef, TString figname, float divMaximum, float divMinimum, TString Xlabel, TString Ylabel, 
	     TString legend1, TString legend2, TString legend3,  TString legend4, TString legend5, int LegOpt ){

  hist = (TH1D*) hist->Clone();
  hist->Sumw2();
  histRef = (TH1D*) histRef->Clone();
  histRef->Sumw2();

 //here are plots
 //------------------------------------------  
  TCanvas *c = new TCanvas("c1","canvas",800,800);
  c->Clear();
  c->SetFillColor(0);
  
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.60,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();

  float maxhist = hist->GetMaximum();
  float minhist = hist->GetMinimum();
  float maxhistRef = histRef->GetMaximum();
  float minhistRef = histRef->GetMinimum();
  if( maxhistRef > maxhist ) maxhist =  maxhistRef;
  if( minhistRef < minhist ) minhist =  minhistRef;
  maxhist =  1.2 * maxhist;

  hist->SetMaximum(maxhist);
  hist->SetMinimum( 0);
  hist->SetTitle("");
  hist->GetXaxis()->SetTitle(Xlabel);
  hist->GetYaxis()->SetTitle(Ylabel);
  hist->SetLineColor(kBlue); 
  hist->SetMarkerColor(kBlue); 
  hist->SetMarkerStyle(24); 
  hist->Draw("p e"); 
  histRef->SetLineColor(kRed); 
  histRef->SetMarkerColor(kRed);
  histRef->SetMarkerStyle(23); 
  histRef->Draw("p e same"); 

  TLegend *leg0 = new TLegend(0.20,0.75,0.50,0.90);
  if(LegOpt == 1)
      leg0 = new TLegend(0.60,0.40,0.90,0.60);
  if(LegOpt == 2)
      leg0 = new TLegend(0.30,0.40,0.60,0.60);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(hist,    legend1,"" );
  leg0->AddEntry(hist,    legend2,"" );
  leg0->AddEntry(hist,    legend3,"" );
  leg0->AddEntry(hist,    legend4,"lp" );
  leg0->AddEntry(histRef, legend5,"lp"  );
  leg0->Draw("same");


  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.65);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  TH1D *div1 = (TH1D *)hist->Clone("temp");
  div1->Sumw2();
  div1->Add(hist, histRef, 1.0, -1.0);
  div1->Divide(div1, histRef, 1.0, 1.0,"B");
  float divMaximum =  ( div1->GetMaximum()+ div1->GetBinError(1) )* 2.0;
  float divMinimum =  ( div1->GetMinimum()- div1->GetBinError(1) )* 2.0;
  if( fabs(divMinimum) > divMaximum ) divMaximum = fabs(divMinimum);
  divMinimum =  -divMaximum;
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->GetYaxis()->SetTitle("#Delta /Reference");
  div1->GetXaxis()->SetTitle(Xlabel);
  div1->GetYaxis()->SetTitleOffset(1.3);
  div1->GetYaxis()->SetNdivisions(806);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlue);
  div1->SetMarkerStyle(27);
  div1->SetMarkerColor(kBlue);
  div1->Draw("p e");
  float xmin = hist->GetBinLowEdge(1); 
  float xmax = xmin + hist->GetBinWidth(1)* hist->GetNbinsX();
  TLine *line = new TLine(  xmin,0,xmax,0);
  line->Draw("p e same");

  TLegend *leg0 = new TLegend(0.20,0.20,0.90,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1,legend1, "" );
  leg0->AddEntry(div1,legend2, "" );
  leg0->AddEntry(div1,legend3, "" );
  leg0->AddEntry(div1,"("+legend4 + "-"+ legend5+")/"+legend5, "lp" );
  leg0->Draw("same");
 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 

} 

void drawClosureRatio(TH1D* hist, TH1D* histRef, TString figname, float divMaximum, float divMinimum, TString Xlabel, TString Ylabel, 
	     TString legend1, TString legend2, TString legend3,  TString legend4, TString legend5, int LegOpt ){

  hist = (TH1D*) hist->Clone();
  hist->Sumw2();
  float scale = 1./hist->Integral();
  hist->Scale(scale);
  histRef = (TH1D*) histRef->Clone();
  histRef->Sumw2();
  scale = 1./histRef->Integral();
  histRef->Scale(scale);


 //here are plots
 //------------------------------------------  
  TCanvas *c = new TCanvas("c1","canvas",800,800);
  c->Clear();
  c->SetFillColor(0);
  
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.60,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();

  float maxhist = hist->GetMaximum();
  float minhist = hist->GetMinimum();
  float maxhistRef = histRef->GetMaximum();
  float minhistRef = histRef->GetMinimum();
  if( maxhistRef > maxhist ) maxhist =  maxhistRef;
  if( minhistRef < minhist ) minhist =  minhistRef;
  maxhist =  1.2 * maxhist;

  hist->SetMaximum(maxhist);
  hist->SetMinimum( 0);
  hist->SetTitle("");
  hist->GetXaxis()->SetTitle(Xlabel);
  hist->GetYaxis()->SetTitle(Ylabel);
  hist->SetLineColor(kBlue); 
  hist->SetMarkerColor(kBlue); 
  hist->SetMarkerStyle(24); 
  hist->Draw("p e"); 
  histRef->SetFillColor(kOrange); 
  histRef->SetLineColor(kOrange); 
  //  histRef->SetMarkerColor(kOrange);
  //  histRef->SetMarkerStyle(23); 
  histRef->Draw("hist same"); 
  hist->Draw("p e same"); 

  TLegend *leg0 = new TLegend(0.20,0.75,0.50,0.90);
  if(LegOpt == 1)
      leg0 = new TLegend(0.60,0.40,0.90,0.60);
  if(LegOpt == 2)
      leg0 = new TLegend(0.30,0.40,0.60,0.60);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(hist,    legend1,"" );
  leg0->AddEntry(hist,    legend2,"" );
  leg0->AddEntry(hist,    legend3,"" );
  leg0->AddEntry(hist,    legend4,"lp" );
  leg0->AddEntry(histRef, legend5,"lp"  );
  leg0->Draw("same");


  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.65);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  TH1D *div1 = (TH1D *)hist->Clone("temp");
  div1->Sumw2();
  div1->Divide(div1, histRef, 1.0, 1.0,"B");
  float divMaximum =  ( div1->GetMaximum()+ div1->GetBinError(1) );
  float divMinimum =  ( div1->GetMinimum()- div1->GetBinError(1) );
  divMaximum = 1.0 + 1.5 * ( divMaximum - 1.0 );
  divMinimum = 1.0 - 3.0 * ( 1.0 - divMinimum );
  if(  divMinimum < 0.1 ) divMinimum = 1.0 - (divMaximum - 1.0);
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->GetYaxis()->SetTitle(legend4 + "/"+ legend5);
  div1->GetXaxis()->SetTitle(Xlabel);
  div1->GetYaxis()->SetTitleOffset(1.3);
  div1->GetYaxis()->SetNdivisions(806);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlue);
  div1->SetMarkerStyle(27);
  div1->SetMarkerColor(kBlue);
  div1->Draw("p e");
  float xmin = hist->GetBinLowEdge(1); 
  float xmax = xmin + hist->GetBinWidth(1)* hist->GetNbinsX();
  TLine *line = new TLine(  xmin,1,xmax,1);
  line->Draw("p e same");

  TLegend *leg0 = new TLegend(0.20,0.20,0.90,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1,legend1, "" );
  leg0->AddEntry(div1,legend2, "" );
  leg0->AddEntry(div1,legend3, "" );
  leg0->AddEntry(div1,legend4 +"/"+legend5, "lp" );
  leg0->Draw("same");
 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 

} 

void drawMultiPY(const TH1D* histRef, const TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
          TString legend1, TString legend2, TString legend3, int LegOpt ) {


  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);


  float maxhist = histRef->GetMaximum();
 
  TH1D* hist1_scale = (TH1D*)hist1->Clone();

  float scale = histRef->Integral()/hist1->Integral();
  hist1_scale->Sumw2();
  hist1_scale->Scale(scale);

  maxhist1 = hist1_scale->GetMaximum();
  if( maxhist1 > maxhist ) maxhist =  maxhist1;
  maxhist =  1.35 * maxhist;

  histRef->SetMaximum(maxhist);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetFillColor(kGreen-10);
  histRef->SetLineColor(kGreen-10);
  histRef->Draw("hist");

  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->Draw("hist same");
 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3,"  ");
  leg->AddEntry(histRef, "PYTHIA+PHOTOS "," lf ");
  leg->AddEntry(hist1_scale,   "PYTHIA+PHOTOS alpha"," l ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawMulti(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
               TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);


  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
 
  TH1D* hist1_scale = (TH1D*)hist1->Clone();
  TH1D* hist2_scale = (TH1D*)hist2->Clone();

  float scale = histRef->Integral()/hist1->Integral();
  hist1_scale->Sumw2();
  hist1_scale->Scale(scale);
  scale = histRef->Integral()/hist2->Integral();
  hist2_scale->Sumw2();
  hist2_scale->Scale(scale);

  float maxhist1 = hist1_scale->GetMaximum();
  if( maxhist1 > maxhist ) maxhist =  maxhist1;
  float maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
  maxhist =  1.35 * maxhist;

  float minhist1 = hist1_scale->GetMinimum();
  if( minhist1 < minhist ) minhist =  minhist1;
  float minhist2 = hist2_scale->GetMinimum();
  if( minhist2 < minhist ) minhist =  minhist2;
  if( minhist > 0 ){
     minhist =  0.75 * minhist;
  } else {
     minhist =  1.35 * minhist;
  }

  histRef->SetMaximum(maxhist);
  histRef->SetMinimum(minhist);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetFillColor(kOrange);
  histRef->SetLineColor(kOrange);
  histRef->Draw("hist");
  histRef->Draw("p e same");

  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(22);
  hist1_scale->Draw("hist same");
  hist1_scale->Draw("p e same");
  hist2_scale->SetLineColor(kRed-3);
  hist2_scale->SetMarkerColor(kRed-3);
  hist2_scale->SetMarkerStyle(23);
  hist2_scale->Draw("hist same");
  hist2_scale->Draw("p e same");
 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lf ");
  leg->AddEntry(hist1_scale,legend4 ," lp ");
  leg->AddEntry(hist2_scale,legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoMulti(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
                  TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);


  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
 
  TH1D* hist1_scale = (TH1D*)hist1->Clone();

  float scale = histRef->Integral()/hist1->Integral();
  hist1_scale->Sumw2();
  hist1_scale->Scale(scale);


  float maxhist1 = hist1_scale->GetMaximum();
  if( maxhist1 > maxhist ) maxhist =  maxhist1;
  maxhist =  1.35 * maxhist;

  float minhist1 = hist1_scale->GetMinimum();
  if( minhist1 < minhist ) minhist =  minhist1;
  if( minhist > 0 ){
     minhist =  0.75 * minhist;
  } else {
     minhist =  1.35 * minhist;
  }

  histRef->SetMaximum(maxhist);
  histRef->SetMinimum(minhist);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetFillColor(kOrange);
  histRef->SetLineColor(kOrange);
  histRef->Draw("hist");
  histRef->Draw("p e same");

  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(22);
  hist1_scale->Draw("hist same");
  hist1_scale->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3,"  ");
  leg->AddEntry(histRef,legend4 ," lf ");
  leg->AddEntry(hist1_scale,legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoMultiLogx(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
                  TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  c->SetLogx(1);


  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
 
  TH1D* hist1_scale = (TH1D*)hist1->Clone();

  float scale = histRef->Integral()/hist1->Integral();
  hist1_scale->Sumw2();
  hist1_scale->Scale(scale);


  float maxhist1 = hist1_scale->GetMaximum();
  if( maxhist1 > maxhist ) maxhist =  maxhist1;
  maxhist =  1.35 * maxhist;

  float minhist1 = hist1_scale->GetMinimum();
  if( minhist1 < minhist ) minhist =  minhist1;
  if( minhist > 0 ){
     minhist =  0.75 * minhist;
  } else {
     minhist =  1.35 * minhist;
  }

  histRef->SetMaximum(maxhist);
  histRef->SetMinimum(minhist);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetFillColor(kOrange);
  histRef->SetLineColor(kOrange);
  histRef->Draw("hist");
  histRef->Draw("p e same");

  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(22);
  hist1_scale->Draw("hist same");
  hist1_scale->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3,"  ");
  leg->AddEntry(histRef,legend4 ," lf ");
  leg->AddEntry(hist1_scale,legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoMultiLogy(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
                  TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  c->SetLogy(1);


  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
 
  TH1D* hist1_scale = (TH1D*)hist1->Clone();

  float scale = histRef->Integral()/hist1->Integral();
  hist1_scale->Sumw2();
  hist1_scale->Scale(scale);


  float maxhist1 = hist1_scale->GetMaximum();
  if( maxhist1 > maxhist ) maxhist =  maxhist1;
  maxhist =  1.35 * maxhist;

  float minhist1 = hist1_scale->GetMinimum();
  if( minhist1 < minhist ) minhist =  minhist1;
  if( minhist > 0 ){
     minhist =  0.75 * minhist;
  } else {
     minhist =  1.35 * minhist;
  }

  histRef->SetMaximum(maxhist);
  histRef->SetMinimum(minhist);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetFillColor(kOrange);
  histRef->SetLineColor(kOrange);
  histRef->Draw("hist");
  histRef->Draw("p e same");

  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(22);
  hist1_scale->Draw("hist same");
  hist1_scale->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3,"  ");
  leg->AddEntry(histRef,legend4 ," lf ");
  leg->AddEntry(hist1_scale,legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawMultiOverly(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
               TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
 
  TH1D* hist1_scale = (TH1D*)hist1->Clone();
  TH1D* hist2_scale = (TH1D*)hist2->Clone();

   float maxhist1 = hist1_scale->GetMaximum();
  if( maxhist1 > maxhist ) maxhist =  maxhist1;
  float maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
 

  float minhist1 = hist1_scale->GetMinimum();
  if( minhist1 < minhist ) minhist =  minhist1;
  float minhist2 = hist2_scale->GetMinimum();
  if( minhist2 < minhist ) minhist =  minhist2;



  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);
  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    histRef->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    histRef->SetMinimum(minhist);
  }

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetFillColor(kOrange);
  histRef->SetLineColor(kOrange);
  histRef->Draw("p e");

  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(22);
  //  hist1_scale->Draw("hist same");
  hist1_scale->Draw("p e same");
  hist2_scale->SetLineColor(kRed-3);
  hist2_scale->SetMarkerColor(kRed-3);
  hist2_scale->SetMarkerStyle(23);
  //  hist2_scale->Draw("hist same");
  hist2_scale->Draw("p e same");
 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lf ");
  leg->AddEntry(hist1_scale,legend4 ," lp ");
  leg->AddEntry(hist2_scale,legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawManyOverly(TH1D* histRef, TH1D* hist1, TH1D* hist2,TH1D* hist3, TH1D* hist4, TH1D* hist5, TH1D* hist6,TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, TString legend7, TString legend8, TString legend9, 
                     int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
 
  TH1D* hist1_scale = (TH1D*)hist1->Clone();
  TH1D* hist2_scale = (TH1D*)hist2->Clone();
  TH1D* hist3_scale = (TH1D*)hist3->Clone();
  TH1D* hist4_scale = (TH1D*)hist4->Clone();
  TH1D* hist5_scale = (TH1D*)hist5->Clone();
  TH1D* hist6_scale = (TH1D*)hist6->Clone();

   float maxhist1 = hist1_scale->GetMaximum();
  if( maxhist1 > maxhist ) maxhist =  maxhist1;
  float maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
 

  float minhist1 = hist1_scale->GetMinimum();
  if( minhist1 < minhist ) minhist =  minhist1;
  float minhist2 = hist2_scale->GetMinimum();
  if( minhist2 < minhist ) minhist =  minhist2;



  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);
  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    histRef->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    histRef->SetMinimum(minhist);
  }

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(20);
  //  histRef->Draw("hist");
  histRef->Draw("p e ");

  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(22);
  //  hist1_scale->Draw("hist same");
  hist1_scale->Draw("p e same");
  hist2_scale->SetLineColor(kRed-3);
  hist2_scale->SetMarkerColor(kRed-3);
  hist2_scale->SetMarkerStyle(23);
  //  hist2_scale->Draw("hist same");
  hist2_scale->Draw("p e same");
  hist3_scale->SetLineColor(kGreen-3);
  hist3_scale->SetMarkerColor(kGreen-3);
  hist3_scale->SetMarkerStyle(24);
  //  hist3_scale->Draw("hist same");
  hist3_scale->Draw("p e same");
  hist4_scale->SetLineColor(kOrange-3);
  hist4_scale->SetMarkerColor(kOrange-3);
  hist4_scale->SetMarkerStyle(24);
  //  hist4_scale->Draw("hist same");
  hist4_scale->Draw("p e same");
  hist5_scale->SetLineColor(kPink-3);
  hist5_scale->SetMarkerColor(kPink-3);
  hist5_scale->SetMarkerStyle(24);
  //  hist5_scale->Draw("hist same");
  hist5_scale->Draw("p e same");
  hist6_scale->SetLineColor(kViolet-3);
  hist6_scale->SetMarkerColor(kViolet-3);
  hist6_scale->SetMarkerStyle(24);
  //  hist6_scale->Draw("hist same");
  hist6_scale->Draw("p e same");
  histRef->Draw("p e same");


 TLegend *leg = new TLegend(0.60,0.60,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.60,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.40,0.60);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lp ");
  leg->AddEntry(hist1_scale,legend4 ," lp ");
  leg->AddEntry(hist2_scale,legend5," lp ");
  leg->AddEntry(hist3_scale,legend6," lp ");
  leg->AddEntry(hist4_scale,legend7," lp ");
  leg->AddEntry(hist5_scale,legend8," lp ");
  leg->AddEntry(hist6_scale,legend9," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawManyDiv(TH1D* histRef, TH1D* hist1, TH1D* hist2,TH1D* hist3, TH1D* hist4, TH1D* hist5, TH1D* hist6,TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, TString legend7, TString legend8, TString legend9, 
                     int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist3 = (TH1D*) hist3->Clone();
  hist4 = (TH1D*) hist4->Clone();
  hist5 = (TH1D*) hist5->Clone();
  hist6 = (TH1D*) hist6->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
 
  TH1D* hist1_scale = (TH1D*)hist1->Clone();
  TH1D* hist2_scale = (TH1D*)hist2->Clone();
  TH1D* hist3_scale = (TH1D*)hist3->Clone();
  TH1D* hist4_scale = (TH1D*)hist4->Clone();
  TH1D* hist5_scale = (TH1D*)hist5->Clone();
  TH1D* hist6_scale = (TH1D*)hist6->Clone();

  /*
   float maxhist1 = hist1_scale->GetMaximum();
  if( maxhist1 > maxhist ) maxhist =  maxhist1;
  float maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
 

  float minhist1 = hist1_scale->GetMinimum();
  if( minhist1 < minhist ) minhist =  minhist1;
  float minhist2 = hist2_scale->GetMinimum();
  if( minhist2 < minhist ) minhist =  minhist2;



  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);
  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    histRef->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    histRef->SetMinimum(minhist);
  }

  */

  hist1_scale->Add(hist1_scale, histRef, 1.0, -1.0);
  hist2_scale->Add(hist2_scale, histRef, 1.0, -1.0);
  hist3_scale->Add(hist3_scale, histRef, 1.0, -1.0);
  hist4_scale->Add(hist4_scale, histRef, 1.0, -1.0);
  hist5_scale->Add(hist5_scale, histRef, 1.0, -1.0);
  hist6_scale->Add(hist6_scale, histRef, 1.0, -1.0);


  hist1_scale->SetMaximum(maximum);
  hist1_scale->SetMinimum(minimum);

  hist1_scale->GetXaxis()->SetTitle( Xlabel );
  hist1_scale->GetYaxis()->SetTitleOffset(1.2);
  hist1_scale->GetYaxis()->SetTitle( Ylabel );
  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(22);
  //  hist1_scale->Draw("hist ");
  hist1_scale->Draw("p e ");

  hist2_scale->SetLineColor(kRed-3);
  hist2_scale->SetMarkerColor(kRed-3);
  hist2_scale->SetMarkerStyle(23);
  //  hist2_scale->Draw("hist same");
  hist2_scale->Draw("p e same");

  hist3_scale->SetLineColor(kGreen-3);
  hist3_scale->SetMarkerColor(kGreen-3);
  hist3_scale->SetMarkerStyle(24);
  //  hist3_scale->Draw("hist same");
  hist3_scale->Draw("p e same");

  hist4_scale->SetLineColor(kOrange-3);
  hist4_scale->SetMarkerColor(kOrange-3);
  hist4_scale->SetMarkerStyle(24);
  //  hist4_scale->Draw("hist same");
  hist4_scale->Draw("p e same");

  hist5_scale->SetLineColor(kPink-3);
  hist5_scale->SetMarkerColor(kPink-3);
  hist5_scale->SetMarkerStyle(24);
  //  hist5_scale->Draw("hist same");
  hist5_scale->Draw("p e same");

  hist6_scale->SetLineColor(kViolet-3);
  hist6_scale->SetMarkerColor(kViolet-3);
  hist6_scale->SetMarkerStyle(24);
  //  hist6_scale->Draw("hist same");
  hist6_scale->Draw("p e same");



 TLegend *leg = new TLegend(0.60,0.60,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.60,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.40,0.60);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AdEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  //  leg->AddEntry(histRef, legend3," lp ");
  leg->AddEntry(hist1_scale,legend4 ," lp ");
  leg->AddEntry(hist2_scale,legend5," lp ");
  leg->AddEntry(hist3_scale,legend6," lp ");
  leg->AddEntry(hist4_scale,legend7," lp ");
  leg->AddEntry(hist5_scale,legend8," lp ");
  leg->AddEntry(hist6_scale,legend9," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawWithMeanUpDown(TH1D* histRef, TH1D* histMean, TH1D* histUp, TH1D* histDown, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  histMean = (TH1D*) histMean->Clone();
  histUp = (TH1D*) histUp->Clone();
  histDown = (TH1D*) histDown->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(20);
  histRef->Draw("p e ");

  histMean->SetLineColor(kOrange+1);
  histMean->SetMarkerColor(kOrange+1);
  histMean->SetLineWidth(1);
  histMean->SetFillColor(kOrange+1);
  histUp->SetLineColor(kOrange+2);
  histUp->SetLineWidth(2);
  histDown->SetLineColor(kOrange+2);
  histDown->SetLineWidth(2);

  if(LogOpt == 2 || LogOpt == 3 ) {
    histMean->SetLineColor(kCyan+1);
    histMean->SetMarkerColor(kCyan+1);
    histMean->SetLineWidth(1);
    histMean->SetFillColor(kCyan+1);
    histUp->SetLineColor(kCyan+2);
    histUp->SetLineWidth(2);
    histDown->SetLineColor(kCyan+2);
    histDown->SetLineWidth(2);
  }

  histMean->Draw("E2same");
  histRef->Draw("p e same");
  histUp->Draw("hist same");
  histDown->Draw("hist same");

 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.60,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lp ");
  leg->AddEntry(histMean,legend4 ," lf ");
  leg->AddEntry(histUp,legend5 ," l ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeLines(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(20);
  histRef->Draw("p e ");


  hist1->SetLineColor(kOrange+1);
  hist1->SetMarkerColor(kOrange+1);
  hist1->SetLineWidth(2);
  //  hist1->SetFillColor(kOrange+1);
  hist2->SetLineColor(kOrange+1);
  hist2->SetMarkerColor(kOrange+1);
  hist2->SetLineWidth(2);
  //  hist2->SetFillColor(kOrange+1);
  if(LogOpt == 2 || LogOpt == 3) {
    hist1->SetLineColor(kCyan+1);
    hist1->SetMarkerColor(kCyan+1);
    hist1->SetLineWidth(1);
    //    hist1->SetFillColor(kCyan+1);
    hist2->SetLineColor(kCyan+1);
    hist2->SetMarkerColor(kCyan+1);
    //    hist2->SetFillColor(kCyan+1);
  }
  hist1->Draw("hist");
  hist2->Draw("hist same");
  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0.0,xmax,0.0);
  line->Draw("p e same");

 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lp ");
  leg->AddEntry(hist1,legend4 ," lf ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverlyBlack(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  if(LogOpt == 2 ) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerStyle(24);
  histRef->SetMarkerColor(1);
  histRef->Draw("p e ");


  hist1->SetLineColor(kBlue+1);
  hist1->SetMarkerColor(kBlue+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlue+1);
  hist1->SetMarkerStyle(23);
  hist1->Draw("p e same");

  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kRed+1);
  hist2->SetMarkerStyle(22);
  hist2->Draw("p e same");

  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3,"  ");
  leg->AddEntry(histRef, legend4," lp ");
  leg->AddEntry(hist1,legend5 ," lp ");
  leg->AddEntry(hist2,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

} 

void drawThreeOverly(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  if(LogOpt == 2 ) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kGreen+1);
  histRef->SetMarkerStyle(20);
  histRef->SetMarkerColor(kGreen+1);
  histRef->Draw("p e ");

  hist1->SetLineColor(kBlue+1);
  hist1->SetMarkerColor(kBlue+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlue+1);
  hist1->SetMarkerStyle(23);
  hist1->Draw("p e same");

  
  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kRed+1);
  hist2->SetMarkerStyle(22);
  hist2->Draw("p e same");

  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3,"  ");
  leg->AddEntry(histRef, legend4," lp  ");
  leg->AddEntry(hist1,legend5 ," lp ");
  leg->AddEntry(hist2,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverlyNoError(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  if(LogOpt == 2 ) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kGreen+1);
  histRef->SetMarkerStyle(20);
  histRef->SetMarkerSize(1.5);
  histRef->SetMarkerColor(kGreen+1);
  histRef->Draw("p e ");

  hist1->SetLineColor(kBlue+1);
  hist1->SetMarkerColor(kBlue+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlue+1);
  hist1->SetMarkerStyle(23);
  hist1->SetMarkerSize(1.5);
  hist1->Draw("p e same");

  
  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kRed+1);
  hist2->SetMarkerStyle(22);
  hist2->SetMarkerSize(1.5);
  hist2->Draw("p e same");

  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3,"  ");
  leg->AddEntry(histRef, legend4," lp  ");
  leg->AddEntry(hist1,legend5 ," lp ");
  leg->AddEntry(hist2,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverlyNoError(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  if(LogOpt == 2 ) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kGreen+1);
  histRef->SetMarkerStyle(20);
  histRef->SetMarkerSize(1.5);
  histRef->SetMarkerColor(kGreen+1);
  histRef->Draw("p e ");

  hist1->SetLineColor(kBlue+1);
  hist1->SetMarkerColor(kBlue+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlue+1);
  hist1->SetMarkerStyle(23);
  hist1->SetMarkerSize(1.5);
  hist1->Draw("p e same");

  
  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kRed+1);
  hist2->SetMarkerStyle(22);
  hist2->SetMarkerSize(1.5);
  hist2->Draw("p e same");

  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3,"  ");
  leg->AddEntry(histRef, legend4," lp  ");
  leg->AddEntry(hist1,legend5 ," lp ");
  leg->AddEntry(hist2,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverlyNoErrorLim150(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  if(LogOpt == 2 ) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetRange(1,90 );
  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kGreen+1);
  histRef->SetMarkerStyle(20);
  histRef->SetMarkerSize(1.5);
  histRef->SetMarkerColor(kGreen+1);
  histRef->Draw("p e ");

  hist1->SetLineColor(kBlue+1);
  hist1->SetMarkerColor(kBlue+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlue+1);
  hist1->SetMarkerStyle(23);
  hist1->SetMarkerSize(1.5);
  hist1->Draw("p e same");

  
  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kRed+1);
  hist2->SetMarkerStyle(22);
  hist2->SetMarkerSize(1.5);
  hist2->Draw("p e same");

  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3,"  ");
  leg->AddEntry(histRef, legend4," lp  ");
  leg->AddEntry(hist1,legend5 ," lp ");
  leg->AddEntry(hist2,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverlyNoErrorWithLine(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  if(LogOpt == 2 ) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kGreen+1);
  histRef->SetMarkerStyle(20);
  histRef->SetMarkerSize(1.5);
  histRef->SetMarkerColor(kGreen+1);
  histRef->Draw("p e ");

  hist1->SetLineColor(kBlue+1);
  hist1->SetMarkerColor(kBlue+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlue+1);
  hist1->SetMarkerStyle(23);
  hist1->SetMarkerSize(1.5);
  hist1->Draw("p e same");

  
  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kRed+1);
  hist2->SetMarkerStyle(22);
  hist2->SetMarkerSize(1.5);
  hist2->Draw("p e same");

  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  TH1D* histDummy = (TH1D*)histRef->Clone();
  histDummy->SetLineColor(1);
  histDummy->SetLineStyle(2);
  leg->AddEntry(histDummy, legend3,"l  ");
  leg->AddEntry(histRef, legend4," lp  ");
  leg->AddEntry(hist1,legend5 ," lp ");
  leg->AddEntry(hist2,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverlyRatioWithLine(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(histRef);
  hist2->Divide(histRef);
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kRed+1);
  hist1->SetMarkerStyle(22);
  hist1->Draw("p e ");

  hist2->SetLineColor(kBlue+1);
  hist2->SetMarkerColor(kBlue+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kBlue+1);
  hist2->SetMarkerStyle(23);
  hist2->Draw("p e same");
 

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->Draw("p e same");


 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.30,0.70,0.90,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  TH1D* histDummy = (TH1D*)histRef->Clone();
  histDummy->SetLineColor(1);
  histDummy->SetLineStyle(2);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(histDummy, legend3," l ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeBinomialRatio(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
			    TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  hist2->Divide(hist2, histRef, 1.0, 1.0, "B");
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kBlue+1);
  hist1->SetMarkerColor(kBlue+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlue+1);
  hist1->SetMarkerStyle(23);
  hist1->Draw("p e ");

  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kRed+1);
  hist2->SetMarkerStyle(22);
  hist2->Draw("p e same");
 

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.50,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeNoErrorRatio(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
			    TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  hist2->Divide(hist2, histRef, 1.0, 1.0, "B");
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kBlue+1);
  hist1->SetMarkerColor(kBlue+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlue+1);
  hist1->SetMarkerSize(1.5);
  hist1->SetMarkerStyle(23);
  hist1->Draw("p e ");

  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kRed+1);
  hist2->SetMarkerSize(1.5);
  hist2->SetMarkerStyle(22);
  hist2->Draw("p e same");
 

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.50,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  histRef->SetLineStyle(1);
  histRef->SetLineColor(1);
  leg->AddEntry(histRef,  legend3 ," l ");
  leg->AddEntry(hist1,  legend4 ," lp ");
  leg->AddEntry(hist2,  legend5 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeNoErrorDelta(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
			    TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Add(hist1, histRef, 1.0, -1.0);
  hist2->Add(hist2, histRef, 1.0, -1.0);
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kBlue+1);
  hist1->SetMarkerColor(kBlue+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlue+1);
  hist1->SetMarkerSize(1.5);
  hist1->SetMarkerStyle(23);
  hist1->Draw("p e ");

  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kRed+1);
  hist2->SetMarkerSize(1.5);
  hist2->SetMarkerStyle(22);
  hist2->Draw("p e same");
 

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.50,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  histRef->SetLineStyle(2);
  histRef->SetLineColor(1);
  leg->AddEntry(histRef,  legend3 ," l ");
  leg->AddEntry(hist1,  legend4 ," lp ");
  leg->AddEntry(hist2,  legend5 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeNoErrorRatioATLAS(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
			    TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  hist2->Divide(hist2, histRef, 1.0, 1.0, "B");
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kBlue+1);
  hist1->SetMarkerColor(kBlue+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlue+1);
  hist1->SetMarkerSize(1.5);
  hist1->SetMarkerStyle(23);
  hist1->Draw("p e ");

  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kRed+1);
  hist2->SetMarkerSize(1.5);
  hist2->SetMarkerStyle(22);
  hist2->Draw("p e same");
 

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.50,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);

 
  ATLASLabel(0.2,0.25,"Simulation Internal");

    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawFourBinomialRatio(TH1D* histRef, TH1D* hist1, TH1D* hist2, TH1D* hist3, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
			   TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist3 = (TH1D*) hist3->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  hist2->Divide(hist2, histRef, 1.0, 1.0, "B");
  hist3->Divide(hist3, histRef, 1.0, 1.0, "B");
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kGreen+1);
  hist1->SetMarkerColor(kGreen+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kGreen+1);
  hist1->SetMarkerStyle(20);
  hist1->Draw("p e ");

  hist2->SetLineColor(kBlue+1);
  hist2->SetMarkerColor(kBlue+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kBlue+1);
  hist2->SetMarkerStyle(22);
  hist2->Draw("p e same");

  hist3->SetLineColor(kRed+1);
  hist3->SetMarkerColor(kRed+1);
  hist3->SetLineWidth(1);
  hist3->SetFillColor(kRed+1);
  hist3->SetMarkerStyle(23);
  hist3->Draw("p e same");
 

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeNoErrorRatio(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
			   TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  hist2->Divide(hist2, histRef, 1.0, 1.0, "B");

  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kGreen+1);
  hist1->SetMarkerColor(kGreen+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kGreen+1);
  hist1->SetMarkerStyle(20);
  hist1->SetMarkerSize(1.5);
  hist1->Draw("p e ");

  hist2->SetLineColor(kBlue+1);
  hist2->SetMarkerColor(kBlue+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kBlue+1);
  hist2->SetMarkerStyle(22);
  hist2->SetMarkerSize(1.5);
  hist2->Draw("p e same");
 

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  histRef->SetLineWidth(1);
  histRef->SetLineStyle(2);
  histRef->SetLineColor(1);  
  leg->AddEntry(histRef, legend3," l ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}
void drawFourNoErrorRatio(TH1D* histRef, TH1D* hist1, TH1D* hist2, TH1D* hist3, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
			   TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist3 = (TH1D*) hist3->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
    hist3->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  hist2->Divide(hist2, histRef, 1.0, 1.0, "B");
  hist3->Divide(hist3, histRef, 1.0, 1.0, "B");
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kGreen+1);
  hist1->SetMarkerColor(kGreen+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kGreen+1);
  hist1->SetMarkerStyle(20);
  hist1->SetMarkerSize(1.5);
  hist1->Draw("p e ");

  hist2->SetLineColor(kBlue+1);
  hist2->SetMarkerColor(kBlue+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kBlue+1);
  hist2->SetMarkerStyle(22);
  hist2->SetMarkerSize(1.5);
  hist2->Draw("p e same");

  hist3->SetLineColor(kRed+1);
  hist3->SetMarkerColor(kRed+1);
  hist3->SetLineWidth(1);
  hist3->SetFillColor(kRed+1);
  hist3->SetMarkerStyle(23);
  hist3->SetMarkerSize(1.5);
  hist3->Draw("p e same");
 

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}
void drawFourBinomialRatioBlack(TH1D* histRef, TH1D* hist1, TH1D* hist2, TH1D* hist3, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist3 = (TH1D*) hist3->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  hist2->Divide(hist2, histRef, 1.0, 1.0, "B");
  hist3->Divide(hist3, histRef, 1.0, 1.0, "B");
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kBlack);
  hist1->SetMarkerColor(kBlack);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlack);
  hist1->SetMarkerStyle(24);
  hist1->Draw("p e ");

  hist2->SetLineColor(kBlue+1);
  hist2->SetMarkerColor(kBlue+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kBlue+1);
  hist2->SetMarkerStyle(22);
  hist2->Draw("p e same");

  hist3->SetLineColor(kRed+1);
  hist3->SetMarkerColor(kRed+1);
  hist3->SetLineWidth(1);
  hist3->SetFillColor(kRed+1);
  hist3->SetMarkerStyle(23);
  hist3->Draw("p e same");
 

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.20,0.70,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}
void drawFourNoErrorRatioBlack(TH1D* histRef, TH1D* hist1, TH1D* hist2, TH1D* hist3, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist3 = (TH1D*) hist3->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
    hist3->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  hist2->Divide(hist2, histRef, 1.0, 1.0, "B");
  hist3->Divide(hist3, histRef, 1.0, 1.0, "B");
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kBlack);
  hist1->SetMarkerColor(kBlack);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlack);
  hist1->SetMarkerStyle(24);
  hist1->SetMarkerSize(1.5);
  hist1->Draw("p e ");

  hist2->SetLineColor(kBlue+1);
  hist2->SetMarkerColor(kBlue+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kBlue+1);
  hist2->SetMarkerStyle(22);
  hist2->SetMarkerSize(1.5);
  hist2->Draw("p e same");

  hist3->SetLineColor(kRed+1);
  hist3->SetMarkerColor(kRed+1);
  hist3->SetLineWidth(1);
  hist3->SetFillColor(kRed+1);
  hist3->SetMarkerStyle(23);
  hist3->SetMarkerSize(1.5);
  hist3->Draw("p e same");
 

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.20,0.70,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}
void drawFiveBinomialRatioBlack(TH1D* hRef, TH1D* h1, TH1D* h2, TH1D* h3, TH1D* h4, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
				TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, TString legend7, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) hRef->Clone();
  hist1 = (TH1D*) h1->Clone();
  hist2 = (TH1D*) h2->Clone();
  hist3 = (TH1D*) h3->Clone();
  hist4 = (TH1D*) h4->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  hist2->Divide(hist2, histRef, 1.0, 1.0, "B");
  hist3->Divide(hist3, histRef, 1.0, 1.0, "B");
  hist4->Divide(hist4, histRef, 1.0, 1.0, "B");
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kBlack);
  hist1->SetMarkerColor(kBlack);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlack);
  hist1->SetMarkerStyle(24);
  hist1->Draw("p e ");

  hist2->SetLineColor(kGreen+1);
  hist2->SetMarkerColor(kGreen+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kGreen+1);
  hist2->SetMarkerStyle(20);
  hist2->Draw("p e same");

  hist3->SetLineColor(kBlue+1);
  hist3->SetMarkerColor(kBlue+1);
  hist3->SetLineWidth(1);
  hist3->SetFillColor(kBlue+1);
  hist3->SetMarkerStyle(23);
  hist3->Draw("p e same");

  hist4->SetLineColor(kRed+1);
  hist4->SetMarkerColor(kRed+1);
  hist4->SetLineWidth(1);
  hist4->SetFillColor(kRed+1);
  hist4->SetMarkerStyle(22);
  hist4->Draw("p e same");
 

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.90,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.50,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");
  leg->AddEntry(hist4,legend7 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}
void drawFiveNoErrorRatioBlack(TH1D* hRef, TH1D* h1, TH1D* h2, TH1D* h3, TH1D* h4, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
				TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, TString legend7, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) hRef->Clone();
  hist1 = (TH1D*) h1->Clone();
  hist2 = (TH1D*) h2->Clone();
  hist3 = (TH1D*) h3->Clone();
  hist4 = (TH1D*) h4->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
    hist3->SetBinError(ibin,0.0);
    hist4->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  hist2->Divide(hist2, histRef, 1.0, 1.0, "B");
  hist3->Divide(hist3, histRef, 1.0, 1.0, "B");
  hist4->Divide(hist4, histRef, 1.0, 1.0, "B");
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kBlack);
  hist1->SetMarkerColor(kBlack);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlack);
  hist1->SetMarkerStyle(24);
  hist1->SetMarkerSize(1.5);
  hist1->Draw("p e ");

  hist2->SetLineColor(kGreen+1);
  hist2->SetMarkerColor(kGreen+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kGreen+1);
  hist2->SetMarkerStyle(20);
  hist2->SetMarkerSize(1.5);
  hist2->Draw("p e same");

  hist3->SetLineColor(kBlue+1);
  hist3->SetMarkerColor(kBlue+1);
  hist3->SetLineWidth(1);
  hist3->SetFillColor(kBlue+1);
  hist3->SetMarkerStyle(23);
  hist3->SetMarkerSize(1.5);
  hist3->Draw("p e same");

  hist4->SetLineColor(kRed+1);
  hist4->SetMarkerColor(kRed+1);
  hist4->SetLineWidth(1);
  hist4->SetFillColor(kRed+1);
  hist4->SetMarkerStyle(22);
  hist4->SetMarkerSize(1.5);
  hist4->Draw("p e same");
 

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.90,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.50,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");
  leg->AddEntry(hist4,legend7 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}
void drawFiveNoErrorRatio(TH1D* hRef, TH1D* h1, TH1D* h2, TH1D* h3, TH1D* h4, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
				TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, TString legend7, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) hRef->Clone();
  hist1 = (TH1D*) h1->Clone();
  hist2 = (TH1D*) h2->Clone();
  hist3 = (TH1D*) h3->Clone();
  hist4 = (TH1D*) h4->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
    hist3->SetBinError(ibin,0.0);
    hist4->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  hist2->Divide(hist2, histRef, 1.0, 1.0, "B");
  hist3->Divide(hist3, histRef, 1.0, 1.0, "B");
  hist4->Divide(hist4, histRef, 1.0, 1.0, "B");
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kOrange);
  hist1->SetMarkerColor(kOrange);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kOrange);
  hist1->SetMarkerStyle(29);
  hist1->SetMarkerSize(1.5);
  hist1->Draw("p e ");

  hist2->SetLineColor(kGreen+1);
  hist2->SetMarkerColor(kGreen+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kGreen+1);
  hist2->SetMarkerStyle(20);
  hist2->SetMarkerSize(1.5);
  hist2->Draw("p e same");
  hist1->Draw("p e same");

  hist3->SetLineColor(kBlue+1);
  hist3->SetMarkerColor(kBlue+1);
  hist3->SetLineWidth(1);
  hist3->SetFillColor(kBlue+1);
  hist3->SetMarkerStyle(23);
  hist3->SetMarkerSize(1.5);
  hist3->Draw("p e same");

  hist4->SetLineColor(kRed+1);
  hist4->SetMarkerColor(kRed+1);
  hist4->SetLineWidth(1);
  hist4->SetFillColor(kRed+1);
  hist4->SetMarkerStyle(22);
  hist4->SetMarkerSize(1.5);
  hist4->Draw("p e same");
 

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.65,0.90,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.50,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  histRef->SetLineWidth(1);
  histRef->SetLineStyle(2);
  histRef->SetLineColor(1);
  leg->AddEntry(histRef, legend3," l ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");
  leg->AddEntry(hist4,legend7 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}
void drawFiveNoErrorDelta(TH1D* hRef, TH1D* h1, TH1D* h2, TH1D* h3, TH1D* h4, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
				TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, TString legend7, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) hRef->Clone();
  hist1 = (TH1D*) h1->Clone();
  hist2 = (TH1D*) h2->Clone();
  hist3 = (TH1D*) h3->Clone();
  hist4 = (TH1D*) h4->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
    hist3->SetBinError(ibin,0.0);
    hist4->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Add(hist1, histRef, 1.0, -1.0);
  hist2->Add(hist2, histRef, 1.0, -1.0);
  hist3->Add(hist3, histRef, 1.0, -1.0);
  hist4->Add(hist4, histRef, 1.0, -1.0);
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kOrange);
  hist1->SetMarkerColor(kOrange);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kOrange);
  hist1->SetMarkerStyle(29);
  hist1->SetMarkerSize(1.5);
  hist1->Draw("p e ");

  hist2->SetLineColor(kGreen+1);
  hist2->SetMarkerColor(kGreen+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kGreen+1);
  hist2->SetMarkerStyle(20);
  hist2->SetMarkerSize(1.5);
  hist2->Draw("p e same");
  hist1->Draw("p e same");

  hist3->SetLineColor(kBlue+1);
  hist3->SetMarkerColor(kBlue+1);
  hist3->SetLineWidth(1);
  hist3->SetFillColor(kBlue+1);
  hist3->SetMarkerStyle(23);
  hist3->SetMarkerSize(1.5);
  hist3->Draw("p e same");

  hist4->SetLineColor(kRed+1);
  hist4->SetMarkerColor(kRed+1);
  hist4->SetLineWidth(1);
  hist4->SetFillColor(kRed+1);
  hist4->SetMarkerStyle(22);
  hist4->SetMarkerSize(1.5);
  hist4->Draw("p e same");
 

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.65,0.90,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.50,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  histRef->SetLineWidth(1);
  histRef->SetLineStyle(2);
  histRef->SetLineColor(1);
  leg->AddEntry(histRef, legend3," l ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");
  leg->AddEntry(hist4,legend7 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoBinomialRatio(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		          TString legend1, TString legend2, TString legend3, TString legend4, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kRed+1);
  hist1->SetMarkerStyle(22);
  hist1->Draw("p e ");


  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1,legend4 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoNoErrorRatio(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		          TString legend1, TString legend2, TString legend3, TString legend4, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kRed+1);
  hist1->SetMarkerStyle(22);
  hist1->SetMarkerSize(1.5);
  hist1->Draw("p e ");


  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1,legend4 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoBinomialRatioBlack(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
			       TString legend1, TString legend2, TString legend3, TString legend4, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kBlack);
  hist1->SetMarkerColor(kBlack);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlack);
  hist1->SetMarkerStyle(24);
  hist1->Draw("p e ");

 
  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.75,0.90);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1,legend4 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoBinomialRatioBlack(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
			       TString legend1, TString legend2, TString legend3, TString legend4, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(hist1, histRef, 1.0, 1.0, "B");
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kBlack);
  hist1->SetMarkerColor(kBlack);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kBlack);
  hist1->SetMarkerStyle(24);
  hist1->Draw("p e ");

 
  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.75,0.90);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1,legend4 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawFourOverly(TH1D* histRef, TH1D* hist1, TH1D* hist2,TH1D* hist3, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		    TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist3 = (TH1D*) hist3->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  if(LogOpt == 2 ) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kOrange);
  histRef->SetMarkerStyle(29);
  histRef->SetMarkerColor(kOrange);
  histRef->Draw("p e ");

  hist1->SetLineColor(kGreen+1);
  hist1->SetMarkerColor(kGreen+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kGreen+1);
  hist1->SetMarkerStyle(20);
  hist1->Draw("p e same");
  histRef->Draw("p e same");

  hist2->SetLineColor(kBlue+1);
  hist2->SetMarkerColor(kBlue+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kBlue+1);
  hist2->SetMarkerStyle(23);
  hist2->Draw("p e same");

  hist3->SetLineColor(kRed+1);
  hist3->SetMarkerColor(kRed+1);
  hist3->SetLineWidth(1);
  hist3->SetFillColor(kRed+1);
  hist3->SetMarkerStyle(22);
  hist3->Draw("p e same");

  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
    leg->AddEntry(histRef, legend3," lp ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawFourOverlyCol(TH1D* histRef, TH1D* hist1, TH1D* hist2,TH1D* hist3, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		    TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist3 = (TH1D*) hist3->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  if(LogOpt == 2 ) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kBlue+1);
  histRef->SetMarkerColor(kBlue+1);
  histRef->SetLineWidth(1);
  histRef->SetFillColor(kBlue+1);
  histRef->SetMarkerStyle(23);
  histRef->Draw("p e");

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kRed+1);
  hist1->SetMarkerStyle(22);
  hist1->Draw("p e same");

  hist2->SetLineColor(kOrange);
  hist2->SetMarkerStyle(29);
  hist2->SetMarkerColor(kOrange);
  hist2->Draw("p e same");

  hist3->SetLineColor(kGreen+1);
  hist3->SetMarkerColor(kGreen+1);
  hist3->SetLineWidth(1);
  hist3->SetMarkerStyle(24);
  hist3->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.50,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.60,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.60,0.45);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lp ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawFiveOverlyCol(TH1D* histRef, TH1D* hist1, TH1D* hist2,TH1D* hist3,TH1D* hist4, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		    TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6,TString legend7, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist3 = (TH1D*) hist3->Clone();
  hist4 = (TH1D*) hist4->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  if(LogOpt == 2 ) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kBlue+1);
  histRef->SetMarkerColor(kBlue+1);
  histRef->SetLineWidth(1);
  histRef->SetFillColor(kBlue+1);
  histRef->SetMarkerStyle(23);
  histRef->Draw("p e");

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kRed+1);
  hist1->SetMarkerStyle(22);
  hist1->Draw("p e same");

  hist2->SetLineColor(kOrange);
  hist2->SetMarkerStyle(29);
  hist2->SetMarkerColor(kOrange);
  hist2->Draw("p e same");

  hist3->SetLineColor(kGreen+1);
  hist3->SetMarkerColor(kGreen+1);
  hist3->SetLineWidth(1);
  hist3->SetMarkerStyle(20);
  hist3->Draw("p e same");

  hist4->SetLineColor(kViolet+1);
  hist4->SetMarkerColor(kViolet+1);
  hist4->SetLineWidth(1);
  hist4->SetMarkerStyle(24);
  hist4->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.60,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.60,0.45);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
    leg->AddEntry(histRef, legend3," lp ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");
  leg->AddEntry(hist4,legend7 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverlyCol(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		    TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  if(LogOpt == 2 ) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kBlue+1);
  histRef->SetMarkerColor(kBlue+1);
  histRef->SetLineWidth(1);
  histRef->SetFillColor(kBlue+1);
  histRef->SetMarkerStyle(23);
  histRef->Draw("p e");

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kRed+1);
  hist1->SetMarkerStyle(22);
  hist1->Draw("p e same");

  hist2->SetLineColor(kOrange);
  hist2->SetMarkerStyle(29);
  hist2->SetMarkerColor(kOrange);
  hist2->Draw("p e same");


  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.60,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.60,0.45);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
    leg->AddEntry(histRef, legend3," lp ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawFourOverlyNoError(TH1D* histRef, TH1D* hist1, TH1D* hist2,TH1D* hist3, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		    TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist3 = (TH1D*) hist3->Clone();

   for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.1e-6);
    hist1->SetBinError(ibin,0.1e-6);
    hist2->SetBinError(ibin,0.1e-6);
    hist3->SetBinError(ibin,0.1e-6);
  }
 

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  if(LogOpt == 2 ) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kOrange);
  histRef->SetMarkerStyle(29);
  histRef->SetMarkerColor(kOrange);
  histRef->Draw("p e ");

  hist1->SetLineColor(kGreen+1);
  hist1->SetMarkerColor(kGreen+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kGreen+1);
  hist1->SetMarkerStyle(20);
  hist1->Draw("p e same");

  hist2->SetLineColor(kBlue+1);
  hist2->SetMarkerColor(kBlue+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kBlue+1);
  hist2->SetMarkerStyle(23);
  hist2->Draw("p e same");

  hist3->SetLineColor(kRed+1);
  hist3->SetMarkerColor(kRed+1);
  hist3->SetLineWidth(1);
  hist3->SetFillColor(kRed+1);
  hist3->SetMarkerStyle(22);
  hist3->Draw("p e same");

  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
  if(LegOpt == 5 ) 
   leg = new TLegend(0.20,0.70,0.40,0.90);
   
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lp ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawFiveOverlyNoError(TH1D* histRef, TH1D* hist1, TH1D* hist2,TH1D* hist3, TH1D* hist4, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		    TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist3 = (TH1D*) hist3->Clone();
  hist4 = (TH1D*) hist4->Clone();

   for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.1e-6);
    hist1->SetBinError(ibin,0.1e-6);
    hist2->SetBinError(ibin,0.1e-6);
    hist3->SetBinError(ibin,0.1e-6);
    hist4->SetBinError(ibin,0.1e-6);
  }
 

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  if(LogOpt == 2 ) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kOrange);
  histRef->SetMarkerStyle(29);
  histRef->SetMarkerColor(kOrange);
  histRef->Draw("p e ");

  hist1->SetLineColor(kGreen+1);
  hist1->SetMarkerColor(kGreen+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kGreen+1);
  hist1->SetMarkerStyle(20);
  hist1->Draw("p e same");

  hist2->SetLineColor(kBlue+1);
  hist2->SetMarkerColor(kBlue+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kBlue+1);
  hist2->SetMarkerStyle(23);
  hist2->Draw("p e same");

  hist3->SetLineColor(kRed+1);
  hist3->SetMarkerColor(kRed+1);
  hist3->SetLineWidth(1);
  hist3->SetFillColor(kRed+1);
  hist3->SetMarkerStyle(22);
  hist3->Draw("p e same");

  hist4->SetLineColor(7);
  hist4->SetMarkerColor(7);
  hist4->SetLineWidth(1);
  hist4->SetFillColor(7);
  hist4->SetMarkerStyle(21);
  hist4->Draw("p e same");

  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1 ) {
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2 ) {
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.65,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
  if(LegOpt == 5 ) 
   leg = new TLegend(0.20,0.70,0.40,0.90);
   
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, " ","  ");
  leg->AddEntry(histRef, legend2," lp  ");
  leg->AddEntry(hist1,legend3 ," lp ");
  leg->AddEntry(hist2,legend4 ," lp ");
  leg->AddEntry(hist3,legend5 ," lp ");
  leg->AddEntry(hist4,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}


void drawFiveOverly(TH1D* histRef, TH1D* hist1, TH1D* hist2,TH1D* hist3,TH1D* hist4, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, TString legend7, int LegOpt, int LogOpt , int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist3 = (TH1D*) hist3->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  if(LogOpt == 2 ) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kViolet+1);
  histRef->SetMarkerStyle(25);
  histRef->SetMarkerColor(kViolet+1);
  histRef->Draw("p e ");

  hist1->SetLineColor(kOrange);
  hist1->SetMarkerColor(kOrange);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(1);
  hist1->SetMarkerStyle(29);
  hist1->Draw("p e same");

  hist2->SetLineColor(kGreen+1);
  hist2->SetMarkerColor(kGreen+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kGreen+1);
  hist2->SetMarkerStyle(20);
  hist2->Draw("p e same");
  hist1->Draw("p e same");

  hist3->SetLineColor(kBlue+1);
  hist3->SetMarkerColor(kBlue+1);
  hist3->SetLineWidth(1);
  hist3->SetFillColor(kBlue+1);
  hist3->SetMarkerStyle(23);
  hist3->Draw("p e same");

  hist4->SetLineColor(kRed+1);
  hist4->SetMarkerColor(kRed+1);
  hist4->SetLineWidth(1);
  hist4->SetFillColor(kRed+1);
  hist4->SetMarkerStyle(22);
  hist4->Draw("p e same");

  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0.0,xmax,0.0);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.40,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lp ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");
  leg->AddEntry(hist4,legend7 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawFourOverlyRatio(TH1D* histRef, TH1D* hist1, TH1D* hist2, TH1D* hist3, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist3 = (TH1D*) hist3->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  hist1->Divide(histRef);
  hist2->Divide(histRef);
  hist3->Divide(histRef);
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kRed+1);
  hist1->SetMarkerStyle(22);
  hist1->Draw("p e ");

  hist2->SetLineColor(kBlue+1);
  hist2->SetMarkerColor(kBlue+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kBlue+1);
  hist2->SetMarkerStyle(23);
  hist2->Draw("p e same");

  hist3->SetLineColor(kGreen+1);
  hist3->SetMarkerColor(kGreen+1);
  hist3->SetLineWidth(1);
  hist3->SetFillColor(kGreen+1);
  hist3->SetMarkerStyle(21);
  hist3->Draw("p e same");

  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->Draw("p e same");


 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.30,0.70,0.90,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverlyBis(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();


  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum );
  histRef->SetMinimum(minimum );

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kYellow+1);
  histRef->SetFillColor(kYellow);
  histRef->Draw("hist  ");

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kRed+1);
  hist1->SetMarkerStyle(22);
  hist1->Draw("p e same");

  hist2->SetLineColor(1);
  hist2->SetMarkerColor(1);
  hist2->SetLineWidth(1);
  hist2->SetMarkerStyle(20);
  hist2->Draw("p e  same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0.0,xmax,0.0);
  line->Draw("p e same");

 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.30,0.70,0.90,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lf ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverlyNorm(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  histRef->Sumw2();
  hist1->Sumw2();
  hist2->Sumw2();

  histRef->Scale(1./histRef->Integral());
  hist1->Scale(1./hist1->Integral());
  hist2->Scale(1./hist2->Integral());


  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum );
  histRef->SetMinimum(minimum );

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kYellow+1);
  histRef->SetFillColor(kYellow);
  //  histRef->SetMarkerColor(1);
  //  histRef->SetMarkerStyle(20);
  histRef->Draw(" hist ");

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kRed+1);
  hist1->SetMarkerStyle(22);
  hist1->Draw("p e same");

  hist2->SetLineColor(kBlue+1);
  hist2->SetMarkerColor(kBlue+1);
  hist2->SetLineWidth(2);
  //  hist2->SetFillColor(kBlue+1);
  //  hist2->SetMarkerStyle(23);
  hist2->Draw("hist same");
  //  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0.0,xmax,0.0);
  line->Draw("p e same");

 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.30,0.70,0.90,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lf ");
  leg->AddEntry(hist1,legend4 ," lp ");
  leg->AddEntry(hist2,legend5 ," l ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverlyNoErrorDelta(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist1->Add(hist1,histRef,1.0,-1.0);
  hist2 = (TH1D*) hist2->Clone();
  hist2->Add(hist2,histRef,1.0,-1.0);
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kGreen);
  hist1->SetMarkerColor(kGreen);
  hist1->SetMarkerStyle(20);
  hist1->Draw("p e ");

  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerStyle(23);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->SetLineStyle(2);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  line->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
 if(LegOpt == 5 ) 
   leg = new TLegend(0.20,0.70,0.40,0.90);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  TH1D* histDummy = (TH1D*)histRef->Clone();
  histDummy->SetLineColor(1);
  histDummy->SetLineStyle(2);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2," ");
  histRef->SetLineStyle(2);
  histRef->SetLineColor(1);
  leg->AddEntry(histRef, legend3," l ");
  leg->AddEntry(hist1, legend4," lp  ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->Draw("same"); 

 

  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawFourOverlyNoErrorDelta(TH1D* histRef, TH1D* hist1, TH1D* hist2, TH1D* hist3, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist1->Add(hist1,histRef,1.0,-1.0);
  hist2 = (TH1D*) hist2->Clone();
  hist2->Add(hist2,histRef,1.0,-1.0);
  hist3 = (TH1D*) hist3->Clone();
  hist3->Add(hist3, histRef,1.0,-1.0);
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
    hist3->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kGreen);
  hist1->SetMarkerColor(kGreen);
  hist1->SetMarkerStyle(20);
  hist1->Draw("p e ");

  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerStyle(23);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->Draw("p e same");

  hist3->SetLineColor(kBlue+1);
  hist3->SetMarkerStyle(22);
  hist3->SetMarkerColor(kBlue+1);
  hist3->SetLineWidth(1);
  hist3->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->SetLineStyle(2);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  line->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
 if(LegOpt == 5 ) 
   leg = new TLegend(0.20,0.70,0.40,0.90);
 if(LegOpt == 6 ) 
   leg = new TLegend(0.20,0.70,0.80,0.90);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  TH1D* histDummy = (TH1D*)histRef->Clone();
  histDummy->SetLineColor(1);
  histDummy->SetLineStyle(2);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2," ");
  histRef->SetLineStyle(2);
  histRef->SetLineColor(1);
  leg->AddEntry(histRef, legend3," l ");
  leg->AddEntry(hist1, legend4," lp  ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");
  leg->Draw("same"); 

 

  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverlyNoErrorRatio(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist1->Divide(hist1,histRef,1.0,1.0);
  hist2 = (TH1D*) hist2->Clone();
  hist2->Divide(hist2,histRef,1.0,1.0);
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kGreen);
  hist1->SetMarkerColor(kGreen);
  hist1->SetMarkerStyle(20);
  hist1->Draw("p e ");

  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerStyle(23);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->SetLineStyle(2);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  line->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
 if(LegOpt == 5 ) 
   leg = new TLegend(0.20,0.70,0.40,0.90);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  TH1D* histDummy = (TH1D*)histRef->Clone();
  histDummy->SetLineColor(1);
  histDummy->SetLineStyle(2);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2," ");
  histRef->SetLineStyle(2);
  histRef->SetLineColor(1);
  leg->AddEntry(histRef, legend3," l ");
  leg->AddEntry(hist1, legend4," lp  ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->Draw("same"); 

 

  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawFourOverlyNoErrorRatio(TH1D* histRef, TH1D* hist1, TH1D* hist2, TH1D* hist3, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, TString legend6, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist1->Divide(hist1,histRef,1.0,1.0);
  hist2 = (TH1D*) hist2->Clone();
  hist2->Divide(hist2,histRef,1.0,1.0);
  hist3 = (TH1D*) hist3->Clone();
  hist3->Divide(hist3, histRef,1.0,1.0);
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
    hist3->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(kGreen);
  hist1->SetMarkerColor(kGreen);
  hist1->SetMarkerStyle(20);
  hist1->Draw("p e ");

  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerStyle(23);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->Draw("p e same");

  hist3->SetLineColor(kBlue+1);
  hist3->SetMarkerStyle(22);
  hist3->SetMarkerColor(kBlue+1);
  hist3->SetLineWidth(1);
  hist3->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->SetLineStyle(2);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  line->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
 if(LegOpt == 5 ) 
   leg = new TLegend(0.20,0.70,0.40,0.90);
 if(LegOpt == 6 ) 
   leg = new TLegend(0.50,0.20,0.90,0.50);
 if(LegOpt == 7 ) 
   leg = new TLegend(0.15,0.60,0.65,0.90);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  TH1D* histDummy = (TH1D*)histRef->Clone();
  histDummy->SetLineColor(1);
  histDummy->SetLineStyle(2);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2," ");
  histRef->SetLineStyle(2);
  histRef->SetLineColor(1);
  leg->AddEntry(histRef, legend3," l ");
  leg->AddEntry(hist1, legend4," lp  ");
  leg->AddEntry(hist2,legend5 ," lp ");
  leg->AddEntry(hist3,legend6 ," lp ");
  leg->Draw("same"); 

 

  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoOverlyNoErrorWithRatio(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.10,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(24);
  histRef->Draw("p e ");

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerStyle(20);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->SetLineStyle(2);
  if( LineOpt == 1) line->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  TH1D* histDummy = (TH1D*)histRef->Clone();
  histDummy->SetLineColor(1);
  histDummy->SetLineStyle(2);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histDummy, legend3,"   ");
  leg->AddEntry(histRef,legend4 ," lp ");
  leg->AddEntry(hist1,legend5 ," lp ");
  leg->Draw("same"); 

  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.25);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  TH1D *div1 = (TH1D *)hist1->Clone("temp");
  div1->Sumw2();
  //  div1->Divide(div1, histRef, 1.0, 1.0,"B");
  div1->Divide(div1, histRef, 1.0, 1.0);
  float divMaximum =  ( div1->GetMaximum()+ div1->GetBinError(1) );
  float divMinimum =  ( div1->GetMinimum()- div1->GetBinError(1) );
  divMaximum = 1.0 + 1.5 * ( divMaximum - 1.0 );
  if(divMaximum  > 1.1) divMaximum = 1.1;
  divMinimum = 1.0 - 3.0 * ( 1.0 - divMinimum );
  if(  divMinimum < 0.1 ) divMinimum = 1.0 - (divMaximum - 1.0);
  if(divMinimum  < 0.9) divMinimum = 0.9;
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->SetMaximum(1.01);
  div1->SetMinimum(0.99);
  div1->GetYaxis()->SetTitle("Ratio");
  //  div1->GetXaxis()->SetTitle(Xlabel);
  div1->GetYaxis()->SetLabelSize(0.1);
  div1->GetYaxis()->SetNdivisions(806);
  div1->GetYaxis()->SetTitleOffset(0.3);
  div1->GetYaxis()->SetTitleSize(0.15);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlack);
  div1->SetMarkerStyle(20);
  div1->SetMarkerColor(kBlack);
  div1->Draw("p e");
  div1->Draw("hist same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = xmin + hist1->GetBinWidth(1)* hist1->GetNbinsX();
  TLine *line = new TLine(  xmin,1,xmax,1);
  line->Draw("p e same");
  /*
  TLegend *leg0 = new TLegend(0.20,0.20,0.90,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1,legend1, "" );
  leg0->AddEntry(div1,legend2, "" );
  leg0->AddEntry(div1,legend3, "" );
  leg0->AddEntry(div1,legend4 +"/"+legend5, "lp" );
  leg0->Draw("same");
  */ 


  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoOverlyNoErrorWithRatioRange200(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.40,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();
   pad1->Range(39.75904,-0.01226562,208.4337,0.01117187);
   pad1->SetFillColor(0);
   pad1->SetBorderMode(0);
   pad1->SetBorderSize(2);
   pad1->SetTickx(1);
   pad1->SetTicky(1);
   pad1->SetLeftMargin(0.12);
   pad1->SetRightMargin(0.05);
   pad1->SetTopMargin(0.05);
   pad1->SetBottomMargin(0.31);
   pad1->SetFrameBorderMode(0);
   pad1->SetFrameBorderMode(0);

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetXaxis()->SetRange(1,140);
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(24);
  histRef->Draw("p e ");

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerStyle(20);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->SetLineStyle(2);
  if( LineOpt == 1) line->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  TH1D* histDummy = (TH1D*)histRef->Clone();
  histDummy->SetLineColor(1);
  histDummy->SetLineStyle(2);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histDummy, legend3,"   ");
  leg->AddEntry(histRef,legend4 ," lp ");
  leg->AddEntry(hist1,legend5 ," lp ");
  leg->Draw("same"); 

  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.43);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  pad2->Range(39.77517,-0.0007477876,208.4799,0.0007707964);
  pad2->SetFillColor(0);
  pad2->SetBorderMode(0);
  pad2->SetBorderSize(2);
  pad2->SetTickx(1);
  pad2->SetTicky(1);
  pad2->SetLeftMargin(0.119883);
  pad2->SetRightMargin(0.05026455);
  pad2->SetTopMargin(0.1783217);
  pad2->SetBottomMargin(0.1631702);
  pad2->SetFrameBorderMode(0);
  pad2->SetFrameBorderMode(0);

  
  TH1D *div1 = (TH1D *)hist1->Clone("temp");
  div1->Sumw2();
  //  div1->Divide(div1, histRef, 1.0, 1.0,"B");
  div1->Divide(div1, histRef, 1.0, 1.0);
  float divMaximum =  ( div1->GetMaximum()+ div1->GetBinError(1) );
  float divMinimum =  ( div1->GetMinimum()- div1->GetBinError(1) );
  divMaximum = 1.0 + 1.5 * ( divMaximum - 1.0 );
  if(divMaximum  > 1.1) divMaximum = 1.1;
  divMinimum = 1.0 - 3.0 * ( 1.0 - divMinimum );
  if(  divMinimum < 0.1 ) divMinimum = 1.0 - (divMaximum - 1.0);
  if(divMinimum  < 0.9) divMinimum = 0.9;
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->SetMaximum(1.005);
  div1->SetMinimum(0.995);
  div1->GetXaxis()->SetRange(1,140);
  div1->GetYaxis()->SetTitle("Ratio");
  //  div1->GetXaxis()->SetTitle(Xlabel);
  div1->GetYaxis()->SetLabelSize(0.1);
  div1->GetYaxis()->SetNdivisions(806);
  div1->GetYaxis()->SetTitleOffset(0.3);
  div1->GetYaxis()->SetTitleSize(0.15);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlack);
  div1->SetMarkerStyle(20);
  div1->SetMarkerColor(kBlack);
  div1->Draw("p e");
  div1->Draw("hist same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = xmin + hist1->GetBinWidth(1)* hist1->GetNbinsX();
  TLine *line = new TLine(  xmin,1,xmax,1);
  line->Draw("p e same");
  /*
  TLegend *leg0 = new TLegend(0.20,0.20,0.90,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1,legend1, "" );
  leg0->AddEntry(div1,legend2, "" );
  leg0->AddEntry(div1,legend3, "" );
  leg0->AddEntry(div1,legend4 +"/"+legend5, "lp" );
  leg0->Draw("same");
  */ 


  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoOverlyNoErrorWithRatioLim150(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.40,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();
   pad1->Range(39.75904,-0.01226562,208.4337,0.01117187);
   pad1->SetFillColor(0);
   pad1->SetBorderMode(0);
   pad1->SetBorderSize(2);
   pad1->SetTickx(1);
   pad1->SetTicky(1);
   pad1->SetLeftMargin(0.12);
   pad1->SetRightMargin(0.05);
   pad1->SetTopMargin(0.05);
   pad1->SetBottomMargin(0.31);
   pad1->SetFrameBorderMode(0);
   pad1->SetFrameBorderMode(0);

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetXaxis()->SetRange(1,90);
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->GetYaxis()->SetTitleSize( 0.05);
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(24);
  histRef->Draw("p e ");

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerStyle(20);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->SetLineStyle(2);
  if( LineOpt == 1) line->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  TH1D* histDummy = (TH1D*)histRef->Clone();
  histDummy->SetLineColor(1);
  histDummy->SetLineStyle(2);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histDummy, legend3,"   ");
  leg->AddEntry(histRef,legend4 ," lp ");
  leg->AddEntry(hist1,legend5 ," lp ");
  leg->Draw("same"); 

  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.43);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  pad2->Range(39.77517,-0.0007477876,208.4799,0.0007707964);
  pad2->SetFillColor(0);
  pad2->SetBorderMode(0);
  pad2->SetBorderSize(2);
  pad2->SetTickx(1);
  pad2->SetTicky(1);
  pad2->SetLeftMargin(0.119883);
  pad2->SetRightMargin(0.05026455);
  pad2->SetTopMargin(0.1783217);
  pad2->SetBottomMargin(0.1631702);
  pad2->SetFrameBorderMode(0);
  pad2->SetFrameBorderMode(0);

  
  TH1D *div1 = (TH1D *)hist1->Clone("temp");
  div1->Sumw2();
  //  div1->Divide(div1, histRef, 1.0, 1.0,"B");
  div1->Divide(div1, histRef, 1.0, 1.0);
  float divMaximum =  ( div1->GetMaximum()+ div1->GetBinError(1) );
  float divMinimum =  ( div1->GetMinimum()- div1->GetBinError(1) );
  divMaximum = 1.0 + 1.5 * ( divMaximum - 1.0 );
  if(divMaximum  > 1.1) divMaximum = 1.1;
  divMinimum = 1.0 - 3.0 * ( 1.0 - divMinimum );
  if(  divMinimum < 0.1 ) divMinimum = 1.0 - (divMaximum - 1.0);
  if(divMinimum  < 0.9) divMinimum = 0.9;
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->SetMaximum(1.005);
  div1->SetMinimum(0.995);
  div1->GetXaxis()->SetRange(1,90);
  div1->GetYaxis()->SetTitle("Ratio of ratios");
  //  div1->GetXaxis()->SetTitle(Xlabel);
  div1->GetYaxis()->SetLabelSize(0.05);
  div1->GetYaxis()->SetNdivisions(806);
  div1->GetYaxis()->SetTitleOffset(0.8);
  div1->GetYaxis()->SetTitleSize(0.08);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlack);
  div1->SetMarkerStyle(20);
  div1->SetMarkerColor(kBlack);
  div1->Draw("p e");
  div1->Draw("hist same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = xmin + hist1->GetBinWidth(1)* hist1->GetNbinsX();
  TLine *line = new TLine(  xmin,1,xmax,1);
  line->Draw("p e same");
  /*
  TLegend *leg0 = new TLegend(0.20,0.20,0.90,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1,legend1, "" );
  leg0->AddEntry(div1,legend2, "" );
  leg0->AddEntry(div1,legend3, "" );
  leg0->AddEntry(div1,legend4 +"/"+legend5, "lp" );
  leg0->Draw("same");
  */ 


  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoOverlyNoErrorWithDelta(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.10,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(24);
  histRef->Draw("p e ");

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerStyle(20);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  if( LineOpt == 1) line = new TLine(  xmin,0.0,xmax,0.0);
  line->SetLineStyle(2);
  if( LineOpt == 1) line->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  TH1D* histDummy = (TH1D*)histRef->Clone();
  histDummy->SetLineColor(1);
  histDummy->SetLineStyle(2);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef,legend4 ," lp ");
  leg->AddEntry(hist1,legend5 ," lp ");
  leg->Draw("same"); 

  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.25);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  TH1D *div1 = (TH1D *)hist1->Clone("temp");
  div1->Sumw2();
  //  div1->Divide(div1, histRef, 1.0, 1.0,"B");
  div1->Add(div1, histRef, 1.0, -1.0);
  float divMaximum =  ( div1->GetMaximum()+ div1->GetBinError(1) );
  float divMinimum =  ( div1->GetMinimum()- div1->GetBinError(1) );
  divMaximum = 1.0 + 1.5 * ( divMaximum - 1.0 );
  if(divMaximum  > 1.1) divMaximum = 1.1;
  divMinimum = 1.0 - 3.0 * ( 1.0 - divMinimum );
  if(  divMinimum < 0.1 ) divMinimum = 1.0 - (divMaximum - 1.0);
  if(divMinimum  < 0.9) divMinimum = 0.9;
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->SetMaximum( 0.005);
  div1->SetMinimum(-0.005);
  div1->GetYaxis()->SetTitle("#Delta");
  //  div1->GetXaxis()->SetTitle(Xlabel);
  div1->GetYaxis()->SetLabelSize(0.1);
  div1->GetYaxis()->SetNdivisions(806);
  div1->GetYaxis()->SetTitleOffset(0.3);
  div1->GetYaxis()->SetTitleSize(0.15);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlack);
  div1->SetMarkerStyle(20);
  div1->SetMarkerColor(kBlack);
  div1->Draw("p e");
  div1->Draw("hist same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = xmin + hist1->GetBinWidth(1)* hist1->GetNbinsX();
  TLine *line = new TLine(  xmin,0,xmax,0);
  line->Draw("p e same");
  /*
  TLegend *leg0 = new TLegend(0.20,0.20,0.90,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1,legend1, "" );
  leg0->AddEntry(div1,legend2, "" );
  leg0->AddEntry(div1,legend3, "" );
  leg0->AddEntry(div1,legend4 +"/"+legend5, "lp" );
  leg0->Draw("same");
  */ 


  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoOverlyNoErrorWithDeltaRange200(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.40,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();
   pad1->Range(39.75904,-0.01226562,208.4337,0.01117187);
   pad1->SetFillColor(0);
   pad1->SetBorderMode(0);
   pad1->SetBorderSize(2);
   pad1->SetTickx(1);
   pad1->SetTicky(1);
   pad1->SetLeftMargin(0.12);
   pad1->SetRightMargin(0.05);
   pad1->SetTopMargin(0.05);
   pad1->SetBottomMargin(0.31);
   pad1->SetFrameBorderMode(0);
   pad1->SetFrameBorderMode(0);

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetXaxis()->SetRange(1,140);
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(24);
  histRef->Draw("p e ");

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerStyle(20);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  if( LineOpt == 1) line = new TLine(  xmin,0.0,xmax,0.0);
  line->SetLineStyle(2);
  if( LineOpt == 1) line->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  TH1D* histDummy = (TH1D*)histRef->Clone();
  histDummy->SetLineColor(1);
  histDummy->SetLineStyle(2);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef,legend4 ," lp ");
  leg->AddEntry(hist1,legend5 ," lp ");
  leg->Draw("same"); 

  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.43);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  pad2->Range(39.77517,-0.0007477876,208.4799,0.0007707964);
  pad2->SetFillColor(0);
  pad2->SetBorderMode(0);
  pad2->SetBorderSize(2);
  pad2->SetTickx(1);
  pad2->SetTicky(1);
  pad2->SetLeftMargin(0.119883);
  pad2->SetRightMargin(0.05026455);
  pad2->SetTopMargin(0.1783217);
  pad2->SetBottomMargin(0.1631702);
  pad2->SetFrameBorderMode(0);
  pad2->SetFrameBorderMode(0);


  TH1D *div1 = (TH1D *)hist1->Clone("temp");
  div1->Sumw2();
  //  div1->Divide(div1, histRef, 1.0, 1.0,"B");
  div1->Add(div1, histRef, 1.0, -1.0);
  float divMaximum =  ( div1->GetMaximum()+ div1->GetBinError(1) );
  float divMinimum =  ( div1->GetMinimum()- div1->GetBinError(1) );
  divMaximum = 1.0 + 1.5 * ( divMaximum - 1.0 );
  if(divMaximum  > 1.1) divMaximum = 1.1;
  divMinimum = 1.0 - 3.0 * ( 1.0 - divMinimum );
  if(  divMinimum < 0.1 ) divMinimum = 1.0 - (divMaximum - 1.0);
  if(divMinimum  < 0.9) divMinimum = 0.9;
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->SetMaximum( 0.001);
  div1->SetMinimum(-0.001);
  div1->GetYaxis()->SetTitle("#Delta");
  div1->GetXaxis()->SetTitle(Xlabel);
  div1->GetXaxis()->SetRange(1,140);
  div1->GetYaxis()->SetLabelSize(0.1);
  div1->GetYaxis()->SetNdivisions(806);
  div1->GetYaxis()->SetTitleOffset(0.3);
  div1->GetYaxis()->SetTitleSize(0.15);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlack);
  div1->SetMarkerStyle(20);
  div1->SetMarkerColor(kBlack);
  div1->Draw("p e");
  div1->Draw("hist same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = xmin + hist1->GetBinWidth(1)* hist1->GetNbinsX();
  TLine *line = new TLine(  xmin,0,xmax,0);
  line->Draw("p e same");
  /*
  TLegend *leg0 = new TLegend(0.20,0.20,0.90,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1,legend1, "" );
  leg0->AddEntry(div1,legend2, "" );
  leg0->AddEntry(div1,legend3, "" );
  leg0->AddEntry(div1,legend4 +"/"+legend5, "lp" );
  leg0->Draw("same");
  */ 


  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoOverlyNoErrorWithDeltaLim150(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.40,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();
   pad1->Range(39.75904,-0.01226562,208.4337,0.01117187);
   pad1->SetFillColor(0);
   pad1->SetBorderMode(0);
   pad1->SetBorderSize(2);
   pad1->SetTickx(1);
   pad1->SetTicky(1);
   pad1->SetLeftMargin(0.12);
   pad1->SetRightMargin(0.05);
   pad1->SetTopMargin(0.05);
   pad1->SetBottomMargin(0.31);
   pad1->SetFrameBorderMode(0);
   pad1->SetFrameBorderMode(0);

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetXaxis()->SetRange(1,90);
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->GetYaxis()->SetTitleSize(0.05 );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(24);
  histRef->Draw("p e ");

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerStyle(20);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  if( LineOpt == 1) line = new TLine(  xmin,0.0,xmax,0.0);
  line->SetLineStyle(2);
  if( LineOpt == 1) line->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  TH1D* histDummy = (TH1D*)histRef->Clone();
  histDummy->SetLineColor(1);
  histDummy->SetLineStyle(2);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3,"  ");
  leg->AddEntry(histRef,legend4 ," lp ");
  leg->AddEntry(hist1,legend5 ," lp ");
  leg->Draw("same"); 

  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.43);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  pad2->Range(39.77517,-0.0007477876,208.4799,0.0007707964);
  pad2->SetFillColor(0);
  pad2->SetBorderMode(0);
  pad2->SetBorderSize(2);
  pad2->SetTickx(1);
  pad2->SetTicky(1);
  pad2->SetLeftMargin(0.119883);
  pad2->SetRightMargin(0.05026455);
  pad2->SetTopMargin(0.1783217);
  pad2->SetBottomMargin(0.1631702);
  pad2->SetFrameBorderMode(0);
  pad2->SetFrameBorderMode(0);


  TH1D *div1 = (TH1D *)hist1->Clone("temp");
  div1->Sumw2();
  //  div1->Divide(div1, histRef, 1.0, 1.0,"B");
  div1->Add(div1, histRef, 1.0, -1.0);
  float divMaximum =  ( div1->GetMaximum()+ div1->GetBinError(1) );
  float divMinimum =  ( div1->GetMinimum()- div1->GetBinError(1) );
  divMaximum = 1.0 + 1.5 * ( divMaximum - 1.0 );
  if(divMaximum  > 1.1) divMaximum = 1.1;
  divMinimum = 1.0 - 3.0 * ( 1.0 - divMinimum );
  if(  divMinimum < 0.1 ) divMinimum = 1.0 - (divMaximum - 1.0);
  if(divMinimum  < 0.9) divMinimum = 0.9;
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->SetMaximum( 0.001);
  div1->SetMinimum(-0.001);
  div1->GetYaxis()->SetTitle("#Delta");
  div1->GetXaxis()->SetTitle(Xlabel);
  div1->GetXaxis()->SetRange(1,90);
  div1->GetYaxis()->SetLabelSize(0.05);
  div1->GetYaxis()->SetNdivisions(806);
  div1->GetYaxis()->SetTitleOffset(0.8);
  div1->GetYaxis()->SetTitleSize(0.08);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlack);
  div1->SetMarkerStyle(20);
  div1->SetMarkerColor(kBlack);
  div1->Draw("p e");
  div1->Draw("hist same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = xmin + hist1->GetBinWidth(1)* hist1->GetNbinsX();
  TLine *line = new TLine(  xmin,0,xmax,0);
  line->Draw("p e same");
  /*
  TLegend *leg0 = new TLegend(0.20,0.20,0.90,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1,legend1, "" );
  leg0->AddEntry(div1,legend2, "" );
  leg0->AddEntry(div1,legend3, "" );
  leg0->AddEntry(div1,legend4 +"/"+legend5, "lp" );
  leg0->Draw("same");
  */ 


  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoOverlyNoErrorWithRatioColor(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.10,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kBlue);
  histRef->SetMarkerColor(kBlue);
  histRef->SetMarkerStyle(23);
  histRef->Draw("p e ");

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerStyle(22);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->SetLineStyle(2);
  line->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  TH1D* histDummy = (TH1D*)histRef->Clone();
  histDummy->SetLineColor(1);
  histDummy->SetLineStyle(2);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histDummy, legend3," l  ");
  leg->AddEntry(histRef,legend4 ," lp ");
  leg->AddEntry(hist1,legend5 ," lp ");
  leg->Draw("same"); 

  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.25);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  TH1D *div1 = (TH1D *)hist1->Clone("temp");
  div1->Sumw2();
  //  div1->Divide(div1, histRef, 1.0, 1.0,"B");
  div1->Divide(div1, histRef, 1.0, 1.0);
  float divMaximum =  ( div1->GetMaximum()+ div1->GetBinError(1) );
  float divMinimum =  ( div1->GetMinimum()- div1->GetBinError(1) );
  divMaximum = 1.0 + 1.5 * ( divMaximum - 1.0 );
  if(divMaximum  > 1.1) divMaximum = 1.1;
  divMinimum = 1.0 - 3.0 * ( 1.0 - divMinimum );
  if(  divMinimum < 0.1 ) divMinimum = 1.0 - (divMaximum - 1.0);
  if(divMinimum  < 0.9) divMinimum = 0.9;
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  //  div1->SetMaximum(1.01);
  //  div1->SetMinimum(0.99);
  div1->SetMaximum(1.005);
  div1->SetMinimum(0.995);
  div1->GetYaxis()->SetTitle("Ratio");
  //  div1->GetXaxis()->SetTitle(Xlabel);
  div1->GetYaxis()->SetLabelSize(0.1);
  div1->GetYaxis()->SetNdivisions(806);
  div1->GetYaxis()->SetTitleOffset(0.3);
  div1->GetYaxis()->SetTitleSize(0.15);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlack);
  div1->SetMarkerStyle(20);
  div1->SetMarkerColor(kBlack);
  div1->Draw("p e");
  div1->Draw("hist same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = xmin + hist1->GetBinWidth(1)* hist1->GetNbinsX();
  TLine *line = new TLine(  xmin,1,xmax,1);
  line->Draw("p e same");
  /*
  TLegend *leg0 = new TLegend(0.20,0.20,0.90,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1,legend1, "" );
  leg0->AddEntry(div1,legend2, "" );
  leg0->AddEntry(div1,legend3, "" );
  leg0->AddEntry(div1,legend4 +"/"+legend5, "lp" );
  leg0->Draw("same");
  */ 


  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoOverlyNoErrorWithRatioCorse(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.10,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(20);
  histRef->Draw("p e ");
  histRef->Draw("hist same ");

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  //  line->Draw("p e same");

 TLegend *leg = new TLegend(0.60,0.65,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.40,0.20,0.90,0.45);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
    leg->AddEntry(histRef, legend3,"  ");
  leg->AddEntry(histRef,legend4 ," lp ");
  leg->AddEntry(hist1,legend5 ," lp ");
  leg->Draw("same"); 

  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.25);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  TH1D *div1 = (TH1D *)hist1->Clone("temp");
  div1->Sumw2();
  //  div1->Divide(div1, histRef, 1.0, 1.0,"B");
  div1->Divide(div1, histRef, 1.0, 1.0);
  float divMaximum =  ( div1->GetMaximum()+ div1->GetBinError(1) );
  float divMinimum =  ( div1->GetMinimum()- div1->GetBinError(1) );
  divMaximum = 1.0 + 1.5 * ( divMaximum - 1.0 );
  if(divMaximum  > 1.1) divMaximum = 1.1;
  divMinimum = 1.0 - 3.0 * ( 1.0 - divMinimum );
  if(  divMinimum < 0.1 ) divMinimum = 1.0 - (divMaximum - 1.0);
  if(divMinimum  < 0.9) divMinimum = 0.9;
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->SetMaximum(1.005);
  div1->SetMinimum(0.995);
  div1->GetYaxis()->SetTitle("Ratio");
  //  div1->GetXaxis()->SetTitle(Xlabel);
  div1->GetYaxis()->SetLabelSize(0.1);
  div1->GetYaxis()->SetNdivisions(806);
  div1->GetYaxis()->SetTitleOffset(0.3);
  div1->GetYaxis()->SetTitleSize(0.15);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlack);
  div1->SetMarkerStyle(20);
  div1->SetMarkerColor(kBlack);
  div1->Draw("p e");
  div1->Draw("hist same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = xmin + hist1->GetBinWidth(1)* hist1->GetNbinsX();
  TLine *line = new TLine(  xmin,1,xmax,1);
  line->Draw("p e same");
  /*
  TLegend *leg0 = new TLegend(0.20,0.20,0.90,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1,legend1, "" );
  leg0->AddEntry(div1,legend2, "" );
  leg0->AddEntry(div1,legend3, "" );
  leg0->AddEntry(div1,legend4 +"/"+legend5, "lp" );
  leg0->Draw("same");
  */ 


  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoOverlyBlack(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		   TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }
  if(LogOpt == 2) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  std::cout << LogOpt << std::endl;


  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  //  if(LogOpt == 1 || LogOpt == 3 )histRef->GetXaxis()->SetRange(6,23 );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(24);
  histRef->Draw("p e ");

  

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kRed+1);
  hist1->SetMarkerStyle(20);
  hist1->Draw("p e same");

  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 || LegOpt == 10 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3,"  ");
  leg->AddEntry(histRef, legend4," lp ");
  leg->AddEntry(hist1,legend5 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoOverlyNoErrorBlack(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		   TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
    hist1->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }
  if(LogOpt == 2) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  std::cout << LogOpt << std::endl;


  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  //  if(LogOpt == 1 || LogOpt == 3 )histRef->GetXaxis()->SetRange(6,23 );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(24);
  histRef->SetMarkerSize(1.5);
  histRef->Draw("p e ");

  hist1->SetLineColor(kRed+1);
  hist1->SetMarkerColor(kRed+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kRed+1);
  hist1->SetMarkerStyle(20);
  hist1->SetMarkerSize(1.5);
  hist1->Draw("p e same");

  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 || LegOpt == 10 ) 
   leg = new TLegend(0.20,0.70,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.70,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3,"  ");
  leg->AddEntry(histRef, legend4," lp ");
  leg->AddEntry(hist1,legend5 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}
/*
void drawThreeOverly(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  float scale = histRef->Integral();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }


  histRef->SetMaximum(maximum*scale);
  histRef->SetMinimum(minimum*scale);

  histRef->GetXaxis()->SetTitle( Xlabel );
  //  if(LogOpt == 1 || LogOpt == 3 )histRef->GetXaxis()->SetRange(6,23 );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(20);
  histRef->Draw("p e ");

  hist1->SetLineColor(kGreen+1);
  hist1->SetMarkerColor(kGreen+1);
  hist1->SetLineWidth(1);
  hist1->SetFillColor(kGreen+1);
  hist1->SetMarkerStyle(22);
  hist1->Draw("p e same");

  hist2->SetLineColor(kRed+1);
  hist2->SetMarkerColor(kRed+1);
  hist2->SetLineWidth(1);
  hist2->SetFillColor(kRed+1);
  hist2->SetMarkerStyle(23);
  hist2->Draw("p e same");

  histRef->Draw("p e same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0.0,xmax,0.0);
  line->Draw("p e same");

 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 || LegOpt == 10 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lp ");
  if(LegOpt != 10) leg->AddEntry(hist1,legend4 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}
*/
void drawOneOverlyNoError(TH1D* histRef, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		   TString legend1, TString legend2, TString legend3, TString legend4, int LegOpt, int LogOpt, int LineOpt=0) {

  histRef = (TH1D*) histRef->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogy();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }
  histRef = (TH1D*) histRef->Clone();
  for( ibin=1; ibin < histRef->GetNbinsX()+1; ibin++){
    histRef->SetBinError(ibin,0.0);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(20);
  histRef->Draw("p e ");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0.0,xmax,0.0);
  line->Draw("p e same");


  TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
  if(LegOpt == 1 ) 
    leg = new TLegend(0.20,0.75,0.90,0.90);
  if(LegOpt == 2 ) 
    leg = new TLegend(0.40,0.75,0.75,0.90);
  if(LegOpt == 3 ) 
    leg = new TLegend(0.60,0.20,0.80,0.40);
  if(LegOpt == 4 ) 
    leg = new TLegend(0.20,0.20,0.20,0.40);
  
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," ");
  leg->AddEntry(histRef, legend4," lp ");

  leg->Draw("same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }


  
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawOneOverly(TH1D* histRef, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		   TString legend1, TString legend2, TString legend3, TString legend4, int LegOpt, int LogOpt) {

  histRef = (TH1D*) histRef->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(20);
  histRef->Draw("p e ");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0.0,xmax,0.0);
  line->Draw("p e same");


  TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
  if(LegOpt == 1 ) 
    leg = new TLegend(0.20,0.75,0.70,0.90);
  if(LegOpt == 2 ) 
    leg = new TLegend(0.40,0.75,0.75,0.90);
  if(LegOpt == 3 ) 
    leg = new TLegend(0.60,0.20,0.80,0.40);
  if(LegOpt == 4 ) 
    leg = new TLegend(0.20,0.20,0.20,0.40);
  
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," ");
  leg->AddEntry(histRef, legend4," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}
void drawOneOverlyWithLine(TH1D* histRef, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
			   TString legend1, TString legend2, TString legend3, TString legend4, int LegOpt, int LogOpt, int LineOpt) {

  histRef = (TH1D*) histRef->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(20);
  histRef->Draw("p e ");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0.0,xmax,0.0);
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

  TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
  if(LegOpt == 1 ) 
    leg = new TLegend(0.20,0.75,0.70,0.90);
  if(LegOpt == 2 ) 
    leg = new TLegend(0.40,0.75,0.75,0.90);
  if(LegOpt == 3 ) 
    leg = new TLegend(0.60,0.20,0.80,0.40);
  if(LegOpt == 4 ) 
    leg = new TLegend(0.20,0.20,0.20,0.40);
  
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," ");
  leg->AddEntry(histRef, legend4," lp ");
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawWithTotError(TH1D* h_tot, TH1D* h_stat,TH1D* h_syst1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5,TString legend6, int LegOpt, int LogOpt ) {

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 2 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

  TH1D* hist_tot   = (TH1D*)h_tot->Clone();
  TH1D* hist_stat  = (TH1D*)h_stat->Clone();
  TH1D* hist_syst1 = (TH1D*)h_syst1->Clone();


  hist_tot->SetMaximum(maximum);
  hist_tot->SetMinimum(minimum);
  hist_tot->GetXaxis()->SetTitle( Xlabel );
  hist_tot->GetYaxis()->SetTitleOffset(1.2);
  hist_tot->GetYaxis()->SetTitle( Ylabel );
  hist_tot->SetLineColor(kOrange-3);
  hist_tot->SetLineWidth(1);
  hist_tot->SetFillColor(kOrange-3);
  hist_tot->Draw("E2");

  hist_syst1->SetLineColor(kCyan+1);
  hist_syst1->SetFillColor(kCyan+1);
  hist_syst1->SetLineWidth(1);
  hist_syst1->Draw("E2same");
  hist_stat->SetLineColor(1);
  hist_stat->SetMarkerColor(1);
  hist_stat->SetMarkerStyle(20);
  hist_stat->Draw("p e same");
 
  float xmin = hist_stat->GetBinLowEdge(1); 
  float xmax = hist_stat->GetBinLowEdge(hist_stat->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0.0,xmax,0.0);
  line->Draw("p e same");


 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.60,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.60,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist_stat, legend1,"  ");
  leg->AddEntry(hist_stat, legend2,"  ");
  leg->AddEntry(hist_stat, legend3,"  ");
  leg->AddEntry(hist_stat, legend4," lp ");
  leg->AddEntry(hist_syst1,legend5 ," lf ");
  leg->AddEntry(hist_tot,legend6 ," lf ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverly_div(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist1->Sumw2();
  hist2->Sumw2();
  hist1->Add(hist1,histRef,1.0,-1.0);
  hist2->Add(hist2,histRef,1.0,-1.0);
  for(int i =1; i < 23; i++){
    std::cout <<  hist1->GetBinContent(i) << " " << hist2->GetBinContent(i) << std::endl;
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 2 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

 
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(1);
  hist1->SetLineColor(kOrange+1);
  hist1->SetFillColor(kOrange+1);
  hist2->SetLineColor(kOrange+1);
  hist2->SetFillColor(kOrange+1);
  if(LogOpt == 2) {
    hist1->SetLineColor(kCyan+1);
    hist1->SetFillColor(kCyan+1);
    hist2->SetLineColor(kCyan+1);
    hist2->SetFillColor(kCyan+1);
  }
  hist1->Draw("hist");
  hist2->Draw("hist same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = hist1->GetBinLowEdge(hist1->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0.0,xmax,0.0);
  line->Draw("p e same");


 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  //  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1, legend4 ," f ");
  //  leg->AddEntry(hist2, legend5," f ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverlyDiv(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist1->Sumw2();
  hist2->Sumw2();
  hist1->Add(hist1,histRef,1.0,-1.0);
  hist2->Add(hist2,histRef,1.0,-1.0);
  for(int i =1; i < 23; i++){
    std::cout <<  hist1->GetBinContent(i) << " " << hist2->GetBinContent(i) << std::endl;
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 2 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

 
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(1);
  hist1->SetLineColor(kOrange+1);
  hist1->SetFillColor(kOrange+1);
  hist2->SetLineColor(kOrange+1);
  hist2->SetFillColor(kOrange+1);
  if(LogOpt == 2) {
    hist1->SetLineColor(kCyan+1);
    hist1->SetFillColor(kCyan+1);
    hist2->SetLineColor(kCyan+1);
    hist2->SetFillColor(kCyan+1);
  }
  hist1->Draw("hist");
  hist2->Draw("hist same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = hist1->GetBinLowEdge(hist1->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0.0,xmax,0.0);
  line->Draw("p e same");


 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1, legend4 ," f ");
  //  leg->AddEntry(hist2, legend5," f ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawErrorSyst(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist1->Clone();
  histRef->Sumw2();
  hist1->Sumw2();
  hist2->Sumw2();
  for(int i =1; i < hist2->GetNbinsX()+1; i++){
    hist2->SetBinContent(i,0);
    hist2->SetBinError(i,hist1->GetBinError(i));
  }
  hist1->Add(histRef,hist1,1.0,-1.0);
  for(int i =1; i < hist2->GetNbinsX()+1; i++){
    hist1->SetBinError(i,histRef->GetBinError(i));
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

 
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(1);
  hist1->SetMarkerColor(1);
  hist1->SetMarkerStyle(20);
  hist1->Draw("p e ");
  hist2->SetMarkerColor(kOrange+1);
  hist2->SetLineColor(kOrange+1);
  hist2->SetFillColor(kOrange+1);
  if(LogOpt == 2 || LogOpt == 3) {
  hist2->SetMarkerColor(kCyan+1);
  hist2->SetLineColor(kCyan+1);
  hist2->SetFillColor(kCyan+1);
  }
  hist2->Draw("E2 same");
  hist1->Draw("p e same ");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = hist1->GetBinLowEdge(hist1->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0.0,xmax,0.0);
  line->Draw("p e same");


 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1, legend4 ,"lp");
  leg->AddEntry(hist2, legend5,"lf");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawAsymErrorSyst(TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt ) {

  histRef  = (TH1D*) hist1->Clone();
  histMean = (TH1D*) hist2->Clone();
  histRef->Sumw2();
  histMean->Sumw2();
  histMean->Add(hist1,hist2,1.0,-1.0);
  for(int i =1; i < histRef->GetNbinsX()+1; i++){
    histRef->SetBinContent(i,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

 
  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetMarkerStyle(20);
  histRef->SetMarkerColor(1);
  histRef->Draw("p e  ");

  histMean->SetLineColor(kOrange+1);
  histMean->SetFillColor(kOrange+1);
  histMean->SetMarkerColor(kOrange+1);
  if(LogOpt == 2 || LogOpt == 3) {
    histMean->SetMarkerColor(kCyan+1);
    histMean->SetLineColor(kCyan+1);
    histMean->SetFillColor(kCyan+1);
  }
  histMean->Draw("E2same");
  histRef->Draw("p e  same");

  float xmin = histRef->GetBinLowEdge(1); 
  float xmax = histRef->GetBinLowEdge(histRef->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0.0,xmax,0.0);
  line->Draw("p e same");


 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(histRef, legend3," lp ");
  leg->AddEntry(histMean, legend4 ,"lf");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawRelErrorSyst(TH1D* histRef, TH1D* hist1, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		     TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist1->Clone();
  histRef->Sumw2();
  hist1->Sumw2();
  hist2->Sumw2();
  for(int i =1; i < hist2->GetNbinsX()+1; i++){
    hist2->SetBinContent(i,0);
    hist2->SetBinError(i,hist1->GetBinError(i)/hist1->GetBinContent(i));
  }
  hist1->Add(histRef,hist1,1.0,-1.0);
  for(int i =1; i < hist2->GetNbinsX()+1; i++){
     if( histRef->GetBinContent(i) < 0.001){ 
       hist1->SetBinError(i,histRef->GetBinError(i));
       hist1->SetBinContent(i,hist1->GetBinContent(i));
     } else {
       hist1->SetBinContent(i,hist1->GetBinContent(i)/histRef->GetBinContent(i));
       hist1->SetBinError(i,histRef->GetBinError(i)/histRef->GetBinContent(i));
     }
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  if(LogOpt == 1 || LogOpt == 3 ) {
    c->SetLogx();
    //    c->SetGridx();
    c->SetTickx(1);
    c->SetTicky(1);
  }

 
  hist1->SetMaximum(maximum);
  hist1->SetMinimum(minimum);

  hist1->GetXaxis()->SetTitle( Xlabel );
  hist1->GetYaxis()->SetTitleOffset(1.2);
  hist1->GetYaxis()->SetTitle( Ylabel );
  hist1->SetLineColor(1);
  hist1->SetMarkerColor(1);
  hist1->SetMarkerStyle(20);
  hist1->Draw("p e ");
  hist2->SetMarkerColor(kOrange+1);
  hist2->SetLineColor(kOrange+1);
  hist2->SetFillColor(kOrange+1);
  if(LogOpt == 2 || LogOpt == 3 ) {
  hist2->SetMarkerColor(kCyan+1);
  hist2->SetLineColor(kCyan+1);
  hist2->SetFillColor(kCyan+1);
  }
  hist2->Draw("E2 same");
  hist1->Draw("p e same ");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = hist1->GetBinLowEdge(hist1->GetNbinsX()+1);
  TLine *line = new TLine(  xmin,0.0,xmax,0.0);
  line->Draw("p e same");


 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.20,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1, legend1,"  ");
  leg->AddEntry(hist1, legend2,"  ");
  leg->AddEntry(hist1, legend3,"  ");
  leg->AddEntry(hist1, legend4 ,"lp");
  leg->AddEntry(hist2, legend5,"lf");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverlyLogy(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
               TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  c->SetLogy(1);

  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
 
  TH1D* hist1_scale = (TH1D*)hist1->Clone();
  TH1D* hist2_scale = (TH1D*)hist2->Clone();

   float maxhist1 = hist1_scale->GetMaximum();
  if( maxhist1 > maxhist ) maxhist =  maxhist1;
  float maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
 

  float minhist1 = hist1_scale->GetMinimum();
  if( minhist1 < minhist ) minhist =  minhist1;
  float minhist2 = hist2_scale->GetMinimum();
  if( minhist2 < minhist ) minhist =  minhist2;



  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);
  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    histRef->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    histRef->SetMinimum(minhist);
  }

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
   histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(20);
  histRef->Draw("hist");
  histRef->Draw("e same");

  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(22);
  hist1_scale->Draw("hist same");
  hist1_scale->Draw("e same");
  hist2_scale->SetLineColor(kRed-3);
  hist2_scale->SetMarkerColor(kRed-3);
  hist2_scale->SetMarkerStyle(23);
  hist2_scale->Draw("hist same");
  hist2_scale->Draw("e same");
 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lp ");
  leg->AddEntry(hist1_scale,legend4 ," lp ");
  leg->AddEntry(hist2_scale,legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawThreeOverlyLogyZoom(int binMin, int binMax, TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
               TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  c->SetLogy(1);

  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
 
  TH1D* hist1_scale = (TH1D*)hist1->Clone();
  TH1D* hist2_scale = (TH1D*)hist2->Clone();

   float maxhist1 = hist1_scale->GetMaximum();
  if( maxhist1 > maxhist ) maxhist =  maxhist1;
  float maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
 

  float minhist1 = hist1_scale->GetMinimum();
  if( minhist1 < minhist ) minhist =  minhist1;
  float minhist2 = hist2_scale->GetMinimum();
  if( minhist2 < minhist ) minhist =  minhist2;



  histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);
  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    histRef->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    histRef->SetMinimum(minhist);
  }

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->GetXaxis()->SetRange( binMin, binMax );
  histRef->SetLineColor(1);
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(20);
  histRef->Draw("hist");
  histRef->Draw("e same");

  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(22);
  hist1_scale->Draw("hist same");
  hist1_scale->Draw("e same");
  hist2_scale->SetLineColor(kRed-3);
  hist2_scale->SetMarkerColor(kRed-3);
  hist2_scale->SetMarkerStyle(23);
  hist2_scale->Draw("hist same");
  hist2_scale->Draw("e same");
 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lp ");
  leg->AddEntry(hist1_scale,legend4 ," lp ");
  leg->AddEntry(hist2_scale,legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void draw(TH1D* histRef, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
             TString legend1, TString legend2, TString legend3, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);

  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
   histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);
  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    histRef->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    histRef->SetMinimum(minhist);
  }

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(1);
  histRef->Draw("hist");
  histRef->SetMarkerColor(1);
  histRef->SetMarkerStyle(1);
  histRef->Draw("e same");

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lfp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}
void drawTwoIsotropic(TH1D* histRef, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
             TString legend1, TString legend2, TString legend3, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();
  div1 = (TH1D*) histRef->Clone();
  div1->Sumw2();
  float scale = 1./div1->Integral()*div1->GetNbinsX();
  div1->Scale(scale);

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.60,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();

  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
   histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);
  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    histRef->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    histRef->SetMinimum(minhist);
  }

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kBlue);
  histRef->Draw("hist");
  histRef->SetMarkerColor(kBlue-3);
  histRef->SetMarkerStyle(1);
  histRef->Draw("e same");

  TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
  if(LegOpt == 1)
      leg = new TLegend(0.60,0.40,0.90,0.60);
  if(LegOpt == 2)
      leg = new TLegend(0.20,0.40,0.40,0.60);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lfp ");

  leg->Draw("same"); 

  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.65);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  float divMaximum =  (div1->GetMaximum()+ div1->GetBinError(1)- 1.0)*1.5 + 1.0;
  float divMinimum =  (div1->GetMinimum()- div1->GetBinError(1)- 1.0)*1.5 + 1.0;
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->GetYaxis()->SetTitle("Bias vs flat");
  div1->GetYaxis()->SetTitleOffset(1.3);
  div1->GetYaxis()->SetNdivisions(806);
  //  div1->GetYaxis()->SetLabelSize(0.2);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlue);
  div1->SetMarkerStyle(27);
  div1->SetMarkerColor(kBlue);
  div1->Draw("p e");
  float xmin = div1->GetBinLowEdge(1); 
  float xmax = xmin + div1->GetBinWidth(1)* div1->GetNbinsX();
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->Draw("p e same");

  TLegend *leg0 = new TLegend(0.60,0.20,0.90,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(histRef, legend1,"  ");
  leg0->AddEntry(histRef, legend2,"  ");
  leg0->AddEntry(histRef, legend3," lfp ");
  leg0->Draw("same");

  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}


void drawIsotropic(TH1D* histRef, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
             TString legend1, TString legend2, TString legend3, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();
  div1 = (TH1D*) histRef->Clone();
  div1->Sumw2();
  float scale = 1./div1->Integral()*div1->GetNbinsX();
  div1->Scale(scale);

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.60,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();

  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
   histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);
  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    histRef->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    histRef->SetMinimum(minhist);
  }

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetLineColor(kBlue);
  histRef->Draw("hist");
  histRef->SetMarkerColor(kBlue-3);
  histRef->SetMarkerStyle(1);
  histRef->Draw("e same");

  TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
  if(LegOpt == 1)
      leg = new TLegend(0.60,0.40,0.90,0.60);
  if(LegOpt == 2)
      leg = new TLegend(0.20,0.40,0.40,0.60);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lfp ");

  leg->Draw("same"); 

  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.65);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  float divMaximum =  (div1->GetMaximum()+ div1->GetBinError(1)- 1.0)*1.5 + 1.0;
  float divMinimum =  (div1->GetMinimum()- div1->GetBinError(1)- 1.0)*1.5 + 1.0;
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->GetYaxis()->SetTitle("Bias vs flat");
  div1->GetYaxis()->SetTitleOffset(1.3);
  div1->GetYaxis()->SetNdivisions(806);
  //  div1->GetYaxis()->SetLabelSize(0.2);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlue);
  div1->SetMarkerStyle(27);
  div1->SetMarkerColor(kBlue);
  div1->Draw("p e");
  float xmin = div1->GetBinLowEdge(1); 
  float xmax = xmin + div1->GetBinWidth(1)* div1->GetNbinsX();
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->Draw("p e same");

  TLegend *leg0 = new TLegend(0.60,0.20,0.90,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(histRef, legend1,"  ");
  leg0->AddEntry(histRef, legend2,"  ");
  leg0->AddEntry(histRef, legend3," lfp ");
  leg0->Draw("same");

  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}



void drawIsotropicOne(TH1D* histRef, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
             TString legend1, TString legend2, TString legend3, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();
  div1 = (TH1D*) histRef->Clone();
  div1->Sumw2();
  float scale = 1./div1->Integral()*div1->GetNbinsX();
  div1->Scale(scale);

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  float divMaximum =  (div1->GetMaximum()+ div1->GetBinError(1)- 1.0)*1.5 + 1.0;
  float divMinimum =  (div1->GetMinimum()- div1->GetBinError(1)- 1.0)*1.5 + 1.0;
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->GetYaxis()->SetTitle(Ylabel);
  div1->GetYaxis()->SetTitleOffset(1.3);
  div1->GetYaxis()->SetNdivisions(806);
  div1->GetXaxis()->SetTitle(Xlabel);
  //  div1->GetYaxis()->SetLabelSize(0.2);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlue);
  div1->SetMarkerStyle(20);
  div1->SetMarkerColor(kBlue);
  div1->Draw("p e");
  float xmin = div1->GetBinLowEdge(1); 
  float xmax = xmin + div1->GetBinWidth(1)* div1->GetNbinsX();
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->Draw("p e same");

  TLegend *leg0 = new TLegend(0.20,0.80,0.50,0.90);
  leg0->SetFillColor(0);
  leg0->SetMargin(0.01);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1, legend1,"  ");
  //  leg0->AddEntry(div1, legend2,"  ");
  leg0->AddEntry(div1, legend3,"  ");
  leg0->Draw("same");

  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}


void drawIsotropicTwo(TH1D* histRef1, TH1D* histRef2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
             TString legend1, TString legend2a, TString legend2b, TString legend3, int LegOpt ) {

  histRef1 = (TH1D*) histRef1->Clone();
  div1 = (TH1D*) histRef1->Clone();
  div1->Sumw2();
  float scale = 1./div1->Integral()*div1->GetNbinsX();
  div1->Scale(scale);

  histRef2 = (TH1D*) histRef2->Clone();
  div2 = (TH1D*) histRef2->Clone();
  div2->Sumw2();
  scale = 1./div2->Integral()*div2->GetNbinsX();
  div2->Scale(scale);

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  float div1Maximum =  (div1->GetMaximum()+ div1->GetBinError(1)- 1.0)*1.5 + 1.0;
  float div1Minimum =  (div1->GetMinimum()- div1->GetBinError(1)- 1.0)*1.5 + 1.0;
 
  float div2Maximum =  (div2->GetMaximum()+ div2->GetBinError(1)- 1.0)*1.5 + 1.0;
  float div2Minimum =  (div2->GetMinimum()- div2->GetBinError(1)- 1.0)*1.5 + 1.0;

  float divMaximum = div1Maximum;
  if( div1Maximum < div2Maximum ) divMaximum = div2Maximum;
  float divMinimum = div1Minimum;
  if( div2Minimum < div1Minimum ) divMinimum = div2Minimum;
  

  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->GetYaxis()->SetTitle(Ylabel);
  div1->GetYaxis()->SetTitleOffset(1.3);
  div1->GetYaxis()->SetNdivisions(806);
  div1->GetXaxis()->SetTitle(Xlabel);
  //  div1->GetYaxis()->SetLabelSize(0.2);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlue);
  div1->SetMarkerStyle(20);
  div1->SetMarkerColor(kBlue);
  div1->Draw("p e");
  div2->SetLineWidth(3);
  div2->SetLineColor(kRed);
  div2->SetMarkerStyle(24);
  div2->SetMarkerColor(kRed);
  div2->Draw("p e same");
  float xmin = div1->GetBinLowEdge(1); 
  float xmax = xmin + div1->GetBinWidth(1)* div1->GetNbinsX();
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->Draw("p e same");

  TLegend *leg0 = new TLegend(0.20,0.70,0.60,0.90);
  leg0->SetFillColor(0);
  leg0->SetMargin(0.20);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1, legend1,"  ");
  leg0->AddEntry(div1, legend2a," lp ");
  leg0->AddEntry(div2, legend2b," lp ");
  leg0->AddEntry(div1, legend3,"   ");
  leg0->Draw("same");

  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}


void drawIsotropicRatio(TH1D* hist, TH1D* histRef, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
             TString legend1, TString legend2, TString legend3, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();
  float scale = 1./histRef->Integral();
  histRef->Sumw2();
  histRef->Scale(scale);
  hist    = (TH1D*) hist->Clone();
  scale = 1./hist->Integral();
  hist->Sumw2();
  hist->Scale(scale);

  div1 = (TH1D*) histRef->Clone();
  div1->Divide(hist,histRef,1.0,1.0);

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  
  float divMaximum =  (div1->GetMaximum()+ div1->GetBinError(1)- 1.0)*1.5 + 1.0;
  float divMinimum =  (div1->GetMinimum()- div1->GetBinError(1)- 1.0)*1.5 + 1.0;
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->GetXaxis()->SetTitle(Xlabel);
  div1->GetYaxis()->SetTitle(Ylabel);
  div1->GetYaxis()->SetTitleOffset(1.3);
  div1->GetYaxis()->SetNdivisions(806);
  //  div1->GetYaxis()->SetLabelSize(0.2);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlue);
  div1->SetMarkerStyle(27);
  div1->SetMarkerColor(kBlue);
  div1->Draw("p e");
  float xmin = div1->GetBinLowEdge(1); 
  float xmax = xmin + div1->GetBinWidth(1)* div1->GetNbinsX();
  TLine *line = new TLine(  xmin,1.0,xmax,1.0);
  line->Draw("p e same");

  TLegend *leg0 = new TLegend(0.60,0.20,0.90,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1, legend1,"  ");
  leg0->AddEntry(div1, legend2,"  ");
  leg0->AddEntry(div1, legend3," lfp ");
  leg0->Draw("same");

  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawOne(TH1D* histRef, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
             TString legend1, TString legend2, TString legendspace, TString legend3, int LegOpt, int LogOpt, int LineOpt ) {

  histRef = (TH1D*) histRef->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);


  
  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
   histRef->SetMaximum(maximum);
  histRef->SetMinimum(minimum);
  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    histRef->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    histRef->SetMinimum(minhist);
  }

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetFillColor(kOrange);
  histRef->SetLineColor(kOrange);
  histRef->Draw("hist");
  histRef->SetMarkerColor(kOrange-3);
  histRef->SetMarkerStyle(1);
  histRef->Draw("e same");

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legendspace,"  ");
  leg->AddEntry(histRef, legend3," lfp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawOneLogy(TH1D* histRef, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
             TString legend1, TString legend2, TString legend3, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  c->SetLogy(1);


  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
 
  maxhist =  1.35 * maxhist;
  if( minhist > 0 ){
     minhist =  0.75 * minhist;
  } else {
     minhist =  1.35 * minhist;
  }

  histRef->SetMaximum(maxhist);
  histRef->SetMinimum(minhist);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetFillColor(kOrange);
  histRef->SetLineColor(kOrange);
  histRef->Draw("hist");
  histRef->SetMarkerColor(kOrange-3);
  histRef->SetMarkerStyle(1);
  histRef->Draw("e same");

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.80,0.40);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lfp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawMultiLogy(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
               TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  c->SetLogy(1);

  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();
 
  TH1D* hist1_scale = (TH1D*)hist1->Clone();
  TH1D* hist2_scale = (TH1D*)hist2->Clone();

  float scale = histRef->Integral()/hist1->Integral();
  hist1_scale->Sumw2();
  hist1_scale->Scale(scale);
  scale = histRef->Integral()/hist2->Integral();
  hist2_scale->Sumw2();
  hist2_scale->Scale(scale);

  float maxhist1 = hist1_scale->GetMaximum();
  if( maxhist1 > maxhist ) maxhist =  maxhist1;
  float maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
  maxhist =  1.35 * maxhist;

  float minhist1 = hist1_scale->GetMinimum();
  if( minhist1 < minhist ) minhist =  minhist1;
  float minhist2 = hist2_scale->GetMinimum();
  if( minhist2 < minhist ) minhist =  minhist2;
  if( minhist > 0 ){
    minhist =  0.75 * minhist;
  } else {
    minhist =  1.35 * minhist;
  }

  histRef->SetMaximum(maxhist);
  histRef->SetMinimum(minhist);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetFillColor(kOrange);
  histRef->SetLineColor(kOrange);
  histRef->Draw("hist");

  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(22);
  hist1_scale->Draw("hist same");
  hist1_scale->Draw("e same");
  hist2_scale->SetLineColor(kRed-3);
  hist2_scale->SetMarkerColor(kRed-3);
  hist2_scale->SetMarkerStyle(23);
  hist2_scale->Draw("hist same");
  hist2_scale->Draw("e same");
 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3," lf ");
  leg->AddEntry(hist1_scale,legend4 ," lp ");
  leg->AddEntry(hist2_scale,legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwo(TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
             TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt ) {

  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);


  float maxhist = hist1->GetMaximum();
  float minhist = hist1->GetMinimum();
 
  TH1D* hist1_scale = (TH1D*)hist1->Clone();
  TH1D* hist2_scale = (TH1D*)hist2->Clone();

  float scale = hist1->Integral()/hist2->Integral();
  hist2_scale->Sumw2();
  hist2_scale->Scale(scale);

  float maxhist1 = hist1_scale->GetMaximum();
  if( maxhist1 > maxhist ) maxhist =  maxhist1;
  float maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
  maxhist =  1.35 * maxhist;

  float minhist1 = hist1_scale->GetMinimum();
  if( minhist1 < minhist ) minhist =  minhist1;
  float minhist2 = hist2_scale->GetMinimum();
  if( minhist2 < minhist ) minhist =  minhist2;
  minhist =  0.75 * minhist;

  hist1_scale->SetMaximum(maxhist);
  hist1_scale->SetMinimum(minhist);

  hist1_scale->GetXaxis()->SetTitle( Xlabel );
  hist1_scale->GetYaxis()->SetTitleOffset(1.2);
  hist1_scale->GetYaxis()->SetTitle( Ylabel );
  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(22);
  hist1_scale->Draw("hist ");
  hist1_scale->Draw("e same");
  hist2_scale->SetLineColor(kRed-3);
  hist2_scale->SetMarkerColor(kRed-3);
  hist2_scale->SetMarkerStyle(23);
  hist2_scale->Draw("hist same");
  hist2_scale->Draw("e same");
 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.90,0.40);
   
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1_scale, legend1,"  ");
  leg->AddEntry(hist1_scale, legend2,"  ");
  leg->AddEntry(hist1_scale, legend3," ");
  leg->AddEntry(hist1_scale,legend4 ," lp ");
  leg->AddEntry(hist2_scale,legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

/*
void drawThreeOverly(TH1D* hist1, TH1D* hist2, TH1D* hist3, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		   TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt ) {

  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist3 = (TH1D*) hist3->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
 
  if( LogOpt == 1 ) 
    c->SetLogx();
 
  if( LogOpt == 2 ) 
    c->SetLogy();

  TH1D* hist1_scale = (TH1D*)hist1->Clone();
  TH1D* hist2_scale = (TH1D*)hist2->Clone();
  TH1D* hist3_scale = (TH1D*)hist3->Clone();


  float maxhist = hist1_scale->GetMaximum();
  float maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
  

  float minhist = hist1_scale->GetMinimum();
  float minhist2 = hist2_scale->GetMinimum();
  if( minhist2 < minhist ) minhist =  minhist2;

  hist1_scale->SetMaximum(maximum);
  hist1_scale->SetMinimum(minimum);

  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    hist1_scale->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    hist1_scale->SetMinimum(minhist);
  }


  hist1_scale->SetMaximum(maximum);
  hist1_scale->SetMinimum(minimum);

  hist1_scale->GetXaxis()->SetTitle( Xlabel );
  hist1_scale->GetYaxis()->SetTitleOffset(1.2);
  hist1_scale->GetYaxis()->SetTitle( Ylabel );
  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(22);
  //  hist1_scale->Draw("hist ");
  hist1_scale->Draw("p e ");
  hist2_scale->SetLineColor(kRed-3);
  hist2_scale->SetMarkerColor(kRed-3);
  hist2_scale->SetMarkerStyle(23);
  //  hist2_scale->Draw("hist same");
  hist2_scale->Draw("p e same");
  hist3_scale->SetLineColor(kGreen-3);
  hist3_scale->SetMarkerColor(kGreen-3);
  hist3_scale->SetMarkerStyle(24);
  //  hist2_scale->Draw("hist same");
  hist3_scale->Draw("p e same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = hist1->GetBinLowEdge(hist1->GetNbinsX())+ hist1->GetBinWidth(hist1->GetNbinsX());
  TLine *line = new TLine(  xmin,0,xmax,0);
  line->Draw("p e same");
 

 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.65,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.50,0.40);
   
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1_scale, legend1,"  ");
  leg->AddEntry(hist1_scale, legend2,"  ");
  leg->AddEntry(hist1_scale, legend3," lp ");
  leg->AddEntry(hist2_scale,legend4 ," lp ");
  leg->AddEntry(hist3_scale,legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}
*/

void drawTwoOverly(TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		   TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
 
  if( LogOpt == 1 ) 
    c->SetLogx();
 
  if( LogOpt == 2 ) 
    c->SetLogy();

  TH1D* hist1_scale = (TH1D*)hist1->Clone();
  TH1D* hist2_scale = (TH1D*)hist2->Clone();

  /*
  float maxhist = hist1_scale->GetMaximum();
  float maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
  

  float minhist = hist1_scale->GetMinimum();
  float minhist2 = hist2_scale->GetMinimum();
  if( minhist2 < minhist ) minhist =  minhist2;

  hist1_scale->SetMaximum(maximum);
  hist1_scale->SetMinimum(minimum);

  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    hist1_scale->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    hist1_scale->SetMinimum(minhist);
  }
  */

  hist1_scale->SetMaximum(maximum);
  hist1_scale->SetMinimum(minimum);

  hist1_scale->GetXaxis()->SetTitle( Xlabel );
  hist1_scale->GetYaxis()->SetTitleOffset(1.2);
  hist1_scale->GetYaxis()->SetTitle( Ylabel );
  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(23);
  //  hist1_scale->Draw("hist ");
  hist1_scale->Draw("p e ");
  hist2_scale->SetLineColor(kRed-3);
  hist2_scale->SetMarkerColor(kRed-3);
  hist2_scale->SetMarkerStyle(22);
  //  hist2_scale->Draw("hist same");
  hist2_scale->Draw("p e same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = hist1->GetBinLowEdge(hist1->GetNbinsX())+ hist1->GetBinWidth(hist1->GetNbinsX());
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmi,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 TLegend *leg = new TLegend(0.55,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.65,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.50,0.40);
   
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1_scale, legend1,"  ");
  leg->AddEntry(hist1_scale, legend2,"  ");
  leg->AddEntry(hist1_scale, legend3," ");
  leg->AddEntry(hist1_scale,legend4 ," lp ");
  leg->AddEntry(hist2_scale,legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoOverlyNoError(TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		   TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
 
  if( LogOpt == 1 ) 
    c->SetLogx();
 
  if( LogOpt == 2 ) 
    c->SetLogy();

  TH1D* hist1_scale = (TH1D*)hist1->Clone();
  TH1D* hist2_scale = (TH1D*)hist2->Clone();

  /*
  float maxhist = hist1_scale->GetMaximum();
  float maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
  

  float minhist = hist1_scale->GetMinimum();
  float minhist2 = hist2_scale->GetMinimum();
  if( minhist2 < minhist ) minhist =  minhist2;

  hist1_scale->SetMaximum(maximum);
  hist1_scale->SetMinimum(minimum);

  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    hist1_scale->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    hist1_scale->SetMinimum(minhist);
  }
  */

  hist1_scale->SetMaximum(maximum);
  hist1_scale->SetMinimum(minimum);

  hist1_scale->GetXaxis()->SetTitle( Xlabel );
  hist1_scale->GetYaxis()->SetTitleOffset(1.2);
  hist1_scale->GetYaxis()->SetTitle( Ylabel );
  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(23);
  //  hist1_scale->Draw("hist ");
  hist1_scale->Draw("p e ");
  hist2_scale->SetLineColor(kRed-3);
  hist2_scale->SetMarkerColor(kRed-3);
  hist2_scale->SetMarkerStyle(22);
  hist2_scale->SetMarkerSize(1.5);

  //  hist2_scale->Draw("hist same");
  hist2_scale->Draw("p e same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = hist1->GetBinLowEdge(hist1->GetNbinsX())+ hist1->GetBinWidth(hist1->GetNbinsX());
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.40,0.65,0.90,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.50,0.40);
 if(LegOpt == 5 ) 
   leg = new TLegend(0.20,0.75,0.70,0.90);
 if(LegOpt == 6 ) 
   leg = new TLegend(0.20,0.65,0.90,0.90);
   
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1_scale, legend1,"  ");
  if(LegOpt != 5 && LegOpt != 6)  leg->AddEntry(hist1_scale, legend2," ");
  hist1->SetLineStyle(2);
  hist1->SetLineColor(1);
  if(LegOpt != 5 && LegOpt != 6 )  leg->AddEntry(hist1, legend3,"l ");
  leg->AddEntry(hist1_scale,legend4 ," lp ");
  leg->AddEntry(hist2_scale,legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}


void drawTwoOverlyNoErrorRange50(TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		   TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  for( ibin=1; ibin < hist1->GetNbinsX()+1; ibin++){
    hist1->SetBinError(ibin,0.0);
    hist2->SetBinError(ibin,0.0);
  }

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
 
  if( LogOpt == 1 ) 
    c->SetLogx();
 
  if( LogOpt == 2 ) 
    c->SetLogy();

  TH1D* hist1_scale = (TH1D*)hist1->Clone();
  TH1D* hist2_scale = (TH1D*)hist2->Clone();

  /*
  float maxhist = hist1_scale->GetMaximum();
  float maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
  

  float minhist = hist1_scale->GetMinimum();
  float minhist2 = hist2_scale->GetMinimum();
  if( minhist2 < minhist ) minhist =  minhist2;

  hist1_scale->SetMaximum(maximum);
  hist1_scale->SetMinimum(minimum);

  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    hist1_scale->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    hist1_scale->SetMinimum(minhist);
  }
  */

  hist1_scale->SetMaximum(maximum);
  hist1_scale->SetMinimum(minimum);
  hist1_scale->GetXaxis()->SetRange(1,65);
  hist2_scale->GetXaxis()->SetRange(1,65);

  hist1_scale->GetXaxis()->SetTitle( Xlabel );
  hist1_scale->GetYaxis()->SetTitleOffset(1.2);
  hist1_scale->GetYaxis()->SetTitle( Ylabel );
  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(23);
  //  hist1_scale->Draw("hist ");
  hist1_scale->Draw("p e ");
  hist2_scale->SetLineColor(kRed-3);
  hist2_scale->SetMarkerColor(kRed-3);
  hist2_scale->SetMarkerStyle(22);
  hist2_scale->SetMarkerSize(1.5);

  //  hist2_scale->Draw("hist same");
  hist2_scale->Draw("p e same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = hist1->GetBinLowEdge(hist1->GetNbinsX())+ hist1->GetBinWidth(hist1->GetNbinsX());
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmin,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.65,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.50,0.40);
 if(LegOpt == 5 ) 
   leg = new TLegend(0.20,0.75,0.70,0.90);
 if(LegOpt == 6 ) 
   leg = new TLegend(0.20,0.65,0.90,0.90);
   
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1_scale, legend1,"  ");
  if(LegOpt != 5 && LegOpt != 6)  leg->AddEntry(hist1_scale, legend2," ");
  hist1->SetLineStyle(2);
  hist1->SetLineColor(1);
  if(LegOpt != 5 && LegOpt != 6 )  leg->AddEntry(hist1, legend3,"l ");
  leg->AddEntry(hist1_scale,legend4 ," lp ");
  leg->AddEntry(hist2_scale,legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}


void drawThreeOverly(TH1D* hist1, TH1D* hist2, TH1D* hist3, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		   TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt, int LineOpt ) {

  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();
  hist3 = (TH1D*) hist3->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
 
  if( LogOpt == 1 ) 
    c->SetLogx();
 
  if( LogOpt == 2 ) 
    c->SetLogy();

  TH1D* hist1_scale = (TH1D*)hist1->Clone();
  TH1D* hist2_scale = (TH1D*)hist2->Clone();
  TH1D* hist3_scale = (TH1D*)hist3->Clone();

  /*
  float maxhist = hist1_scale->GetMaximum();
  float maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
  

  float minhist = hist1_scale->GetMinimum();
  float minhist2 = hist2_scale->GetMinimum();
  if( minhist2 < minhist ) minhist =  minhist2;

  hist1_scale->SetMaximum(maximum);
  hist1_scale->SetMinimum(minimum);

  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    hist1_scale->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    hist1_scale->SetMinimum(minhist);
  }
  */

  hist1_scale->SetMaximum(maximum);
  hist1_scale->SetMinimum(minimum);

  hist1_scale->GetXaxis()->SetTitle( Xlabel );
  hist1_scale->GetYaxis()->SetTitleOffset(1.2);
  hist1_scale->GetYaxis()->SetTitle( Ylabel );
  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(23);
  //  hist1_scale->Draw("hist ");
  hist1_scale->Draw("p e ");
  hist2_scale->SetLineColor(kRed-3);
  hist2_scale->SetMarkerColor(kRed-3);
  hist2_scale->SetMarkerStyle(22);
  //  hist2_scale->Draw("hist same");
  hist2_scale->Draw("p e same");
  hist3_scale->SetLineColor(kGreen-3);
  hist3_scale->SetMarkerColor(kGreen-3);
  hist3_scale->SetMarkerStyle(24);
  //  hist3_scale->Draw("hist same");
  hist3_scale->Draw("p e same");

  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = hist1->GetBinLowEdge(hist1->GetNbinsX())+ hist1->GetBinWidth(hist1->GetNbinsX());
  if( LineOpt == 1){
    TLine *line = new TLine(  xmin,0.0,xmax,0.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }
  if( LineOpt == 2){
    TLine *line = new TLine(  xmi,1.0,xmax,1.0);
    line->SetLineStyle(2);
    line->Draw("p e same");
  }

 TLegend *leg = new TLegend(0.55,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.65,0.70,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.90,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.50,0.40);
   
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1_scale, legend1,"  ");
  leg->AddEntry(hist1_scale, legend2,"  ");
  leg->AddEntry(hist1_scale, legend3,"lp ");
  leg->AddEntry(hist2_scale, legend4 ," lp ");
  leg->AddEntry(hist3_scale, legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawTwoRatio(TH1D* histRef, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		   TString legend1, TString legend2, TString legend3, TString legend4, int LegOpt, int LogOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
 
  if( LogOpt == 1 ) {
    c->SetLogx();
  }

  hist2->SetMaximum(maximum);
  hist2->SetMinimum(minimum);

  hist2->Divide(histRef);
  
  hist2->GetXaxis()->SetTitle( Xlabel );
  hist2->GetYaxis()->SetTitleOffset(1.2);
  hist2->GetYaxis()->SetTitle( Ylabel );
  hist2->SetLineColor(kBlack);
  hist2->SetMarkerColor(kBlack);
  hist2->SetMarkerStyle(20);
  hist2->Draw("p e ");

  float xmin = hist2->GetBinLowEdge(1); 
  float xmax = hist2->GetBinLowEdge(hist2->GetNbinsX())+ hist2->GetBinWidth(hist2->GetNbinsX());
  TLine *line = new TLine(  xmin,1,xmax,1);
  line->Draw("p e same");
 

 TLegend *leg = new TLegend(0.60,0.70,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.60,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.50,0.40);
   
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist2, legend1,"  ");
  leg->AddEntry(hist2, legend2,"  ");
  //  leg->AddEntry(histRef, legend3," ");
  leg->AddEntry(hist2,legend4 ," lp ");
  //  leg->AddEntry(hist2_scale,legend5," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}


void drawTwoDiv(TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
		   TString legend1, TString legend2, TString legend3, TString legend4, TString legend5, int LegOpt, int LogOpt ) {

  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
 
  if( LogOpt == 1 ) {
    c->SetLogx();
    //    c->SetGridx();
    //    c->SetTickx(1);
    //    c->SetTicky(1);
  }

  TH1D* hist1_scale = (TH1D*)hist1->Clone();
  TH1D* hist2_scale = (TH1D*)hist2->Clone();
  /*
  float maxhist = hist1_scale->GetMaximum();
  float maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
  if(maxhist < maximum )  maxhist = maximum;
  

  float minhist = hist1_scale->GetMinimum();
  float minhist2 = hist2_scale->GetMinimum();
  if( minhist2 < minhist ) minhist =  minhist2;
  if(minhist > minimum )  minhist = minimum;

  hist1_scale->SetMaximum(maximum);
  hist1_scale->SetMinimum(minimum);

  if( maxhist > maximum ){
    maxhist =  1.35 * maxhist;
    hist1_scale->SetMaximum(maxhist);
  }
  if( minhist < minimum ){
    if( minhist > 0 ){
      minhist =  0.75 * minhist;
    } else {
      minhist =  1.35 * minhist;
    }
    hist1_scale->SetMinimum(minhist);
  }
  */

  hist1_scale->Add(hist1_scale, hist2_scale, 1.0, -1.0);
  hist1_scale->SetMaximum(maximum);
  hist1_scale->SetMinimum(minimum);


  hist1_scale->GetXaxis()->SetTitle( Xlabel );
  hist1_scale->GetYaxis()->SetTitleOffset(1.2);
  hist1_scale->GetYaxis()->SetTitle( Ylabel );
  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->SetMarkerColor(kBlue-3);
  hist1_scale->SetMarkerStyle(22);
  //  hist1_scale->Draw("hist ");
  hist1_scale->Draw("p e");
  //  hist2_scale->SetLineColor(kRed-3);
  // hist2_scale->SetMarkerColor(kRed-3);
  // hist2_scale->SetMarkerStyle(23);
  // hist2_scale->Draw("hist same");
  // hist2_scale->Draw("e same");
  float xmin = hist1_scale->GetBinLowEdge(1); 
  float xmax = hist1_scale->GetBinLowEdge(hist1_scale->GetNbinsX())+ hist1_scale->GetBinWidth(hist1_scale->GetNbinsX());
  TLine *line = new TLine(  xmin,0,xmax,0);
  line->Draw("p e same");


 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.70,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
 if(LegOpt == 3 ) 
   leg = new TLegend(0.60,0.20,0.90,0.40);
 if(LegOpt == 4 ) 
   leg = new TLegend(0.20,0.20,0.40,0.40);
   
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist1_scale, legend1,"  ");
  leg->AddEntry(hist1_scale, legend2,"  ");
  leg->AddEntry(hist1_scale, legend3," ");
  leg->AddEntry(hist1_scale, legend4 ," lp ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawLogyMulti(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
          TString legend1, TString legend2, TString legend3, int LegOpt ) {

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  c->SetLogy(1);


  float maxhist = histRef->GetMaximum();
  float minhist = histRef->GetMinimum();

  TH1D* hist1_scale = (TH1D*) hist1->Clone();
  TH1D* hist2_scale = (TH1D*) hist2->Clone();

 
  float scale = histRef->Integral()/hist1->Integral();
  hist1_scale->Sumw2();
  hist1_scale->Scale(scale);
  scale = histRef->Integral()/hist2->Integral();
  hist2_scale->Sumw2();
  hist2_scale->Scale(scale);

  maxhist1 = hist1_scale->GetMaximum();
  if( maxhist1 > maxhist ) maxhist =  maxhist1;
  maxhist2 = hist2_scale->GetMaximum();
  if( maxhist2 > maxhist ) maxhist =  maxhist2;
  maxhist =  1.e+1 * maxhist;
  minhist =  1.e-1 * minhist;

  if(minhist == 0.0) minhist = 1.e-5 * maxhist; 

  histRef->SetMaximum(maxhist);
  histRef->SetMinimum(minhist);

  histRef->GetXaxis()->SetTitle( Xlabel );
  histRef->GetYaxis()->SetTitleOffset(1.2);
  histRef->GetYaxis()->SetTitle( Ylabel );
  histRef->SetFillColor(kOrange);
  histRef->SetLineColor(kOrange);
  histRef->Draw("hist");

  hist1_scale->SetLineColor(kBlue-3);
  hist1_scale->Draw("hist same");
  hist2_scale->SetLineColor(kRed-3);
  hist2_scale->Draw("hist same");
 

 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(histRef, legend1,"  ");
  leg->AddEntry(histRef, legend2,"  ");
  leg->AddEntry(histRef, legend3,"  ");
  leg->AddEntry(histRef, "HORACE exp"," lf ");
  leg->AddEntry(hist1_scale,   "HORACE born"," l ");
  leg->AddEntry(hist2_scale,   "HORACE alpha"," l ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawLogy(TH1D* hist, TH1D* histRef, TString figname, float maximum, float minimum, TString Xlabel, TString Ylabel, 
          TString legend1, TString legend2, TString legend3, TString legend4,int LegOpt ) {

  hist = (TH1D*) hist->Clone();
  histRef = (TH1D*) histRef->Clone();


  //////////////////////////////////////////////////
  TCanvas *c = new TCanvas("c1","canvas",800,601);
  c->SetFillColor(0);
  gPad->SetFillColor(0);
  c->SetLogy(1);

  TH1D* histRef_scale = (TH1D*) histRef->Clone();

  float maxhist = hist->GetMaximum();
  float minhist = hist->GetMinimum();
  float scale = hist->Integral()/histRef->Integral();
  histRef_scale->Sumw2();
  histRef_scale->Scale(scale);

  float maxhistRef_scale = histRef->GetMaximum();
  float minhistRef_scale = histRef->GetMinimum();
  if( maxhistRef_scale > maxhist ) maxhist =  maxhistRef_scale;
  if( minhistRef_scale < minhist ) minhist =  minhistRef_scale;
  maxhist =  1.e+1 * maxhist;
  minhist =  1.e-1 * minhist;

  if(minhist == 0.0) minhist = 1.e-5 * maxhist; 

  hist->SetMaximum(maxhist);
  hist->SetMinimum(minhist);

  hist->GetXaxis()->SetTitle( Xlabel );
  hist->GetYaxis()->SetTitleOffset(1.2);
  hist->GetYaxis()->SetTitle( Ylabel );
  hist->SetLineColor(1);
  hist->SetMarkerColor(1);
  hist->SetMarkerStyle(20);
  hist->Draw(" e");

  histRef_scale->SetFillColor(kGreen - 10);
  histRef_scale->SetMarkerStyle(27);
  histRef_scale->SetLineColor(kGreen-3);
  histRef_scale->Draw("hist same");
 
  hist->Draw("hist same");
  hist->Draw("e same");


 TLegend *leg = new TLegend(0.60,0.75,0.90,0.90);  
 if(LegOpt == 1 ) 
   leg = new TLegend(0.20,0.75,0.50,0.90);
 if(LegOpt == 2 ) 
   leg = new TLegend(0.40,0.75,0.75,0.90);
    
  leg->SetFillColor(0);
  leg->SetBorderSize(0);
  leg->AddEntry(hist, legend1,"  ");
  leg->AddEntry(hist, legend2,"  ");
  leg->AddEntry(hist, legend3," lp ");
  leg->AddEntry(histRef_scale, legend4," lf ");

  leg->Draw("same"); 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 
  //////////////////////////////////////////////////

}

void drawMee(TH1D* hist, TH1D* histRef, TString figname, float divMaximum, float divMinimum, TString Xlabel, TString Ylabel, 
	     TString legend1, TString legend2, TString legend3,  TString legend4, int binMin, int binMax, int LegOpt ){

  hist = (TH1D*) hist->Clone();
  histRef = (TH1D*) histRef->Clone();

 //here are plots
 //------------------------------------------  
  TCanvas *c = new TCanvas("c1","canvas",800,800);
  c->Clear();
  c->SetFillColor(0);
  
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.60,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();

  float maxhist = hist->GetMaximum();
  float minhist = hist->GetMinimum();
  float maxhistRef = histRef->GetMaximum();
  float minhistRef = histRef->GetMinimum();
  if( maxhistRef > maxhist ) maxhist =  maxhistRef;
  if( minhistRef < minhist ) minhist =  minhistRef;
  maxhist =  1.2 * maxhist;

  hist->SetMaximum(maxhist);
  hist->SetMinimum( 0);
  hist->SetTitle("");
  hist->GetXaxis()->SetTitle(Xlabel);
  hist->GetXaxis()->SetRange(binMin,binMax);
  hist->GetYaxis()->SetTitle(Ylabel);
  hist->SetLineColor(kBlue); 
  hist->SetMarkerColor(kBlue); 
  hist->SetMarkerStyle(24); 
  hist->Draw("p e"); 
  histRef->SetLineColor(kRed); 
  histRef->SetMarkerColor(kRed);
  histRef->SetMarkerStyle(23); 
  histRef->Draw("p e same"); 

  TLegend *leg0 = new TLegend(0.20,0.75,0.50,0.90);
  if(LegOpt == 1)
      leg0 = new TLegend(0.60,0.40,0.90,0.60);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(hist,    legend1,"" );
  leg0->AddEntry(hist,    legend2,"" );
  leg0->AddEntry(hist,    legend3,"" );
  leg0->AddEntry(hist,    "HORACE","lp" );
  leg0->AddEntry(histRef, legend4,"lp"  );
  leg0->Draw("same");


  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.65);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  TH1D *div1 = (TH1D *)hist->Clone("temp");
  div1->Sumw2();
  TH1D *div2 = (TH1D *)hist->Clone("temp");
  div2->Sumw2();
  //  div1->Divide(hist, histRef, 1.0, 1.0, "B");
  //  div2->Divide(hist, hist, 1.0, 1.0, "B");
  div1->Add(hist, histRef, 1.0, -1.0);
  //  div2->Add(hist, hist, 1.0, -1.0);
  float max = div1->GetMaximum();
  if( div2->GetMaximum() > max ) max =  div2->GetMaximum();
  if(max > 1.1) max= 1.1;
  div1->SetMaximum(max+0.0001);
  div1->SetMinimum( 1.- (max-1.0) -0.0001);
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->GetYaxis()->SetTitle("#Delta (normalised entries)");
  div1->GetXaxis()->SetTitle(Xlabel);
  //  div1->GetYaxis()->SetTitleSize(0.2);
  div1->GetYaxis()->SetTitleOffset(1.3);
  div1->GetYaxis()->SetNdivisions(806);
  //  div1->GetYaxis()->SetLabelSize(0.2);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlue);
  div1->SetMarkerStyle(27);
  div1->SetMarkerColor(kBlue);
  div1->Draw("p e");
  //  div2->SetLineWidth(3);
  //  div2->SetLineColor(kRed);
  //  div2->SetMarkerStyle(23);
  //  div2->SetMarkerColor(kRed);
  //  div2->Draw("p e same");
  float xmin = hist->GetBinLowEdge(1); 
  float xmax = xmin + hist->GetBinWidth(1)* hist->GetNbinsX();
  TLine *line = new TLine(  xmin,0,xmax,0);
  line->Draw("p e same");

  TLegend *leg0 = new TLegend(0.20,0.20,0.90,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1,legend1, "" );
  leg0->AddEntry(div1,legend2, "" );
  leg0->AddEntry(div1,legend3, "" );
  leg0->AddEntry(div1,"HORACE -" + legend4, "lp" );
  leg0->Draw("same");

 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 

} 

void drawMeeMulti(TH1D* histRef, TH1D* hist1, TH1D* hist2, TString figname, float divMaximum, float divMinimum, TString Xlabel, TString Ylabel, 
		  TString legend1, TString legend2, TString legend3, int binMin, int binMax, int LegOpt ){

  histRef = (TH1D*) histRef->Clone();
  hist1 = (TH1D*) hist1->Clone();
  hist2 = (TH1D*) hist2->Clone();

 //here are plots
 //------------------------------------------  
  TCanvas *c = new TCanvas("c1","canvas",800,800);
  c->Clear();
  c->SetFillColor(0);
  
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.60,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();

  float maxhist = hist2->GetMaximum();
  float minhist = hist2->GetMinimum();
  float maxhistRef = histRef->GetMaximum();
  float minhistRef = histRef->GetMinimum();
  if( maxhistRef > maxhist ) maxhist =  maxhistRef;
  if( minhistRef < minhist ) minhist =  minhistRef;
  maxhist =  1.2 * maxhist;

  histRef->SetMaximum(maxhist);
  histRef->SetMinimum( 0);
  histRef->SetTitle("");
  histRef->GetXaxis()->SetTitle(Xlabel);
  histRef->GetXaxis()->SetRange(binMin, binMax);
  histRef->GetYaxis()->SetTitle(Ylabel);
  histRef->SetMarkerColor(kOrange); 
  histRef->SetMarkerStyle(29); 
  histRef->SetLineColor(kOrange); 
  histRef->Draw("e"); 
  hist1->SetLineColor(kBlue); 
  hist1->Draw("e same"); 
  hist2->SetLineColor(kRed); 
  hist2->Draw("e same"); 

  TLegend *leg0 = new TLegend(0.20,0.70,0.50,0.90);
  if(LegOpt == 1)
      leg0 = new TLegend(0.60,0.40,0.90,0.70);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(histRef,  legend1,"" );
  leg0->AddEntry(histRef,  legend2,"" );
  leg0->AddEntry(histRef,  legend3,"" );
  leg0->AddEntry(histRef, "HORACE exp","lp" );
  leg0->AddEntry(hist1   ,"HORACE born","lp"  );
  leg0->AddEntry(hist2   ,"HORACE alpha","lp"  );
  leg0->Draw("same");


  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.65);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  TH1D *div1 = (TH1D *)histRef->Clone("temp");
  div1->Sumw2();
  TH1D *div2 = (TH1D *)histRef->Clone("temp");
  div2->Sumw2();
  //  div1->Divide(hist, histRef, 1.0, 1.0, "B");
  //  div2->Divide(hist, hist, 1.0, 1.0, "B");
  div1->Add(hist1, histRef, 1.0, -1.0);
  div2->Add(hist2, histRef, 1.0, -1.0);
  //  div2->Add(hist, hist, 1.0, -1.0);
  float max = div1->GetMaximum();
  if( div2->GetMaximum() > max ) max =  div2->GetMaximum();
  if(max > 1.1) max= 1.1;
  div1->SetMaximum(divMaximum);
  div1->SetMinimum(divMinimum);
  div1->GetYaxis()->SetTitle("#Delta (normalised entries)");
  div1->GetXaxis()->SetTitle(Xlabel);
  //  div1->GetYaxis()->SetTitleSize(0.2);
  div1->GetYaxis()->SetTitleOffset(1.3);
  div1->GetYaxis()->SetNdivisions(806);
  //  div1->GetYaxis()->SetLabelSize(0.2);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlue);
  div1->SetMarkerStyle(27);
  div1->SetMarkerColor(kBlue);
  div1->Draw("p e");
  div2->SetLineWidth(3);
  div2->SetLineColor(kRed);
  div2->SetMarkerStyle(28);
  div2->SetMarkerColor(kRed);
  div2->Draw("p e same");
  float xmin = hist1->GetBinLowEdge(1); 
  float xmax = xmin + hist1->GetBinWidth(1)* hist1->GetNbinsX();
  TLine *line = new TLine(  xmin,0,xmax,0);
  line->Draw("same");

  TLegend *leg0 = new TLegend(0.60,0.20,0.90,0.35);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1,legend1, "" );
  leg0->AddEntry(div1,legend2, "" );
  leg0->AddEntry(div1,legend3, "" );
  leg0->AddEntry(div1,"HORACE (born  - exp)", "lp" );
  leg0->AddEntry(div2,"HORACE (alpha - exp)", "lp" );
  leg0->Draw("same");
 
  c->Print("figures/"+figname+".eps"); 
  c->Print("figures/"+figname+".pdf"); 
  c->Print("figures/"+figname+".C"); 

} 

//----------------------------------------------------------------------------------------------------------
void drawAsym( TH1D *hist_pos,  TH1D *hist_neg, TH1D *histRef_pos, TH1D *histRef_neg, TString figname,  
               float divMaximum, float divMinimum, TString Xlabel, TString Ylabel, 
	       TString legend1, TString legend2, TString legend3, TString legend4, int binMin, int binMax, int LegOpt ){ 

 TH1 *asymhist    = (TH1*)hist_pos->GetAsymmetry(hist_neg)->Clone();
 TH1 *asymhistRef = (TH1*)histRef_pos->GetAsymmetry(histRef_neg)->Clone();

 //------------------------------------------  
  TCanvas *c = new TCanvas("c1","canvas",800,800);
  c->Clear();
  c->SetFillColor(0);
  
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.60,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();

  asymhist->SetMaximum( 0.35);
  asymhist->SetMinimum(-0.35);
  asymhist->SetLineColor(kRed);
  asymhist->SetTitle("");
  asymhist->GetXaxis()->SetTitle(Xlabel);
  asymhist->GetYaxis()->SetTitle(Ylabel);
  asymhist->GetXaxis()->SetRange(binMin, binMax);
  asymhist->SetLineColor(kBlue); 
  asymhist->SetMarkerColor(kBlue); 
  asymhist->SetMarkerStyle(24); 
  asymhist->Draw(); 
  asymhistRef->SetLineColor(kRed); 
  asymhistRef->SetMarkerColor(kRed); 
  asymhistRef->SetMarkerStyle(23); 
  asymhistRef->Draw("same"); 
 

  TLegend *leg0 = new TLegend(0.20,0.80,0.60,0.90);
  if(LegOpt == 1)
      leg0 = new TLegend(0.60,0.40,0.90,0.60);
   leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(asymhist,    legend1 ,"" );
  leg0->AddEntry(asymhist,    legend2 ,"" );
  leg0->AddEntry(asymhist,    legend3 ,"" );
  leg0->AddEntry(asymhist,    "HORACE" ,"lp"  );
  leg0->AddEntry(asymhistRef, legend4 ,"lp  ");
  leg0->Draw("same");
 

  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.65);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  TH1D *div1 = (TH1D *)asymhist->Clone("temp");
  div1->Sumw2();
  div1->Add(asymhist, asymhistRef,  1.0, -1.0);
  //  float max = div1->GetMaximum();
  /*
  div1->SetMaximum(2.);
  div1->SetMinimum(0);
  */
  div1->SetMaximum( divMaximum );
  div1->SetMinimum( divMinimum );
  
  div1->GetXaxis()->SetRange(binMin, binMax);
  div1->GetYaxis()->SetTitle("#Delta (A_{FB})");
  div1->GetXaxis()->SetTitle(Xlabel);
  div1->GetYaxis()->SetNdivisions(806);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlue);
  div1->SetMarkerStyle(24);
  div1->SetMarkerColor(kBlue);
  div1->Draw("p e");
  float xmin = asymhist->GetBinLowEdge(1); 
  float xmax = xmin + asymhist->GetBinWidth(1)*asymhist->GetNbinsX();
  TLine *line = new TLine(  xmin,0,xmax,0);
  line->Draw("same");

  TLegend *leg0 = new TLegend(0.20,0.20,0.60,0.30);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1,  legend1,"" );
  leg0->AddEntry(div1,  legend2,"" );
  leg0->AddEntry(div1,  legend3,""  );
  leg0->AddEntry(div1,  "HORACE -"+ legend4,"lp"  );
  leg0->Draw("same");
  
  c->Print("figures/" + figname + ".eps");
  c->Print("figures/" + figname + ".C");
  c->Print("figures/" + figname + ".pdf");




}

//----------------------------------------------------------------------------------------------------------
void drawAsymMulti( TH1D *histRef_pos,  TH1D *histRef_neg, TH1D *hist1_pos, TH1D *hist1_neg, TH1D *hist2_pos, TH1D *hist2_neg, 
               TString figname, float divMaximum, float divMinimum, TString Xlabel, TString Ylabel, 
		    TString legend1, TString legend2, TString legend3, int binMin, int binMax, int LegOpt ){ 


 TH1 *asymhistRef = (TH1*)histRef_pos->GetAsymmetry(histRef_neg)->Clone();
 TH1 *asymhist1    = (TH1*)hist1_pos->GetAsymmetry(hist1_neg)->Clone();
 TH1 *asymhist2    = (TH1*)hist2_pos->GetAsymmetry(hist2_neg)->Clone();
 //------------------------------------------  
  TCanvas *c = new TCanvas("c1","canvas",800,800);
  c->Clear();
  c->SetFillColor(0);
  
  gPad->SetFillColor(0);
  
  TVirtualPad *parentPad = gPad;
  TPad *pad1 = new TPad("pad1","This is pad1",0.05,0.60,0.95,0.97);
  pad1->SetBottomMargin(0.31);
  pad1->SetFillColor(0);
  pad1->Draw();
  pad1->cd();

  asymhist1->SetMaximum( 0.25);
  asymhist1->SetMinimum(-0.25);
  asymhist1->SetLineColor(kRed);
  asymhist1->SetTitle("");
  asymhist1->GetXaxis()->SetTitle(Xlabel);
  asymhist1->GetYaxis()->SetTitle(Ylabel);
  asymhist1->GetXaxis()->SetRange(binMin, binMax);
  asymhist1->SetLineColor(kBlue); 
  asymhist1->SetMarkerColor(kBlue); 
  asymhist1->SetMarkerStyle(24); 
  asymhist1->Draw("hist"); 
  asymhist2->SetLineColor(kRed); 
  asymhist2->SetMarkerColor(kRed); 
  asymhist2->SetMarkerStyle(23); 
  asymhist2->Draw("hist same"); 
  asymhistRef->SetLineColor(kOrange); 
  asymhistRef->SetMarkerColor(kOrange); 
  asymhistRef->SetMarkerStyle(29); 
  asymhistRef->Draw("e same"); 
 

  TLegend *leg0 = new TLegend(0.20,0.70,0.60,0.90);
  if(LegOpt == 1)
           leg0 = new TLegend(0.60,0.40,0.90,0.60);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(asymhistRef, legend1 ,"" );
  leg0->AddEntry(asymhistRef, legend2 ,"" );
  leg0->AddEntry(asymhistRef, legend3 ,"" );
  leg0->AddEntry(asymhistRef, "HORACE exp"   ,"lp");
  leg0->AddEntry(asymhist1  , "HORACE born"  ,"l");
  leg0->AddEntry(asymhist2  , "HORACE alpha" ,"l");
  leg0->Draw("same");
 

  parentPad->cd();
  TPad *pad2 = new TPad("pad2","This is pad2",0.05,0.0,0.95,0.65);
  //  pad2->SetBottomMargin(0.02);
  pad2->SetFillColor(0);
  pad2->Draw();
  pad2->cd();
  TH1D *div1 = (TH1D *)asymhist1->Clone("temp");
  div1->Sumw2();
  div1->Add(asymhist1, asymhistRef,  1.0, -1.0);
  div1->GetXaxis()->SetRange(1,18);
  TH1D *div2 = (TH1D *)asymhist2->Clone("temp");
  div2->Sumw2();
  div2->Add(asymhist2, asymhistRef,  1.0, -1.0);
  //  float max = div1->GetMaximum();

  div1->SetMaximum( divMaximum );
  div1->SetMinimum( divMinimum );
  
  div1->GetXaxis()->SetRange(binMin,binMax);
  div1->GetYaxis()->SetTitle("#Delta (A_{FB})");
  div1->GetXaxis()->SetTitle(Xlabel);
  div1->GetYaxis()->SetNdivisions(806);
  div1->SetLineWidth(3);
  div1->SetLineColor(kBlue);
  div1->SetMarkerStyle(28);
  div1->SetMarkerColor(kBlue);
  div1->Draw("p e");
  div2->SetLineWidth(3);
  div2->SetLineColor(kRed);
  div2->SetMarkerStyle(27);
  div2->SetMarkerColor(kRed);
  div2->Draw("p e same");
  float xmin = asymhist1->GetBinLowEdge(1); 
  float xmax = xmin + asymhist1->GetBinWidth(1)*asymhist1->GetNbinsX();
  TLine *line = new TLine(  xmin,0,xmax,0);
  line->Draw("same");

  TLegend *leg0 = new TLegend(0.60,0.20,0.90,0.35);
  leg0->SetFillColor(0);
  leg0->SetBorderSize(0);
  leg0->AddEntry(div1,  legend1,"" );
  leg0->AddEntry(div1,  legend2,"" );
  leg0->AddEntry(div1,  legend3,""  );
  leg0->AddEntry(div1, "HORACE (born  - exp)","lp"  );
  leg0->AddEntry(div2, "HORACE (alpha - exp)","lp"  );
  leg0->Draw("same");
  
  c->Print("figures/" + figname + ".eps");
  c->Print("figures/" + figname + ".C");
  c->Print("figures/" + figname + ".pdf");




}
