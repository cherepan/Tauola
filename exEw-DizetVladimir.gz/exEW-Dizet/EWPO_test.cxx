#include <iostream>
#include <fstream>
#include <complex>
#include <string>
#include "TauSpinner/ew_born.h"
#include "TauSpinner/EWtables.h"

using namespace std;
using namespace TauSpinner;
//ROOT headers
#include "TH1.h"
#include "TF1.h"   
#include "TFile.h"

 

int main(){

  // NOTE that choice for <mumu> implicates histograms header names
  //
  char* tabmu=     "table.mu-6.45";  
  char* tabdown=   "table.down-6.45";
  char* tabup=     "table.up-6.45";
   
  int FLAV=0;  // 0-lepton 2-up   1-down
    
  int j=initTables(tabmu,tabdown,tabup); // initialization
  //int i=testit();  // general printout
  int i=0;
  cout << " Is all OK? Control variables j,i=" << i <<" "<<j << endl;
  //   return 1;
  
 
  // histograms for: cross-sections, asymmetry, polarisation
  
  int NB=400;
  double Xmin= 91.1876-5.;//20.;//90.;//20.;//230.;//145.;//230.;//49.185;//AMZ00-0.5 ;//90.; //70.;//20; //70;
  double Xmax= 91.1876+5.;//150.;//93.;//150.;//260.;//155.;//260.;//149.19; //AMZ00+0.5 ;//92.;//150.; //200; //150;
  double aa=(Xmax-Xmin)/NB;
  TH1D* hSig_000  = new TH1D("hSig_000"," ",NB,Xmin,  Xmax);
  TH1D* hAsym_000 = new TH1D("hAsym_000"," " ,NB,Xmin,  Xmax);
  TH1D* hPol_000  = new TH1D("hPol_000"," ",NB,Xmin,  Xmax);
  TH1D* hSig_001  = new TH1D("hSig_001"," ",NB,Xmin,  Xmax);
  TH1D* hAsym_001 = new TH1D("hAsym_001"," ",NB,Xmin,  Xmax);
  TH1D* hPol_001  = new TH1D("hPol_001"," ",NB,Xmin,  Xmax);
  //
  TH1D* hSig_100  = new TH1D("hSig_100"," ",NB,Xmin,  Xmax);
  TH1D* hAsym_100 = new TH1D("hAsym_100"," ",NB,Xmin,  Xmax);
  TH1D* hPol_100  = new TH1D("hPol_100"," ",NB,Xmin,  Xmax);
  TH1D* hSig_101  = new TH1D("hSig_101"," ",NB,Xmin,  Xmax);
  TH1D* hAsym_101 = new TH1D("hAsym_101"," ",NB,Xmin,  Xmax);
  TH1D* hPol_101  = new TH1D("hPol_101"," ",NB,Xmin,  Xmax);
  //
  TH1D* hSig_200  = new TH1D("hSig_200"," ",NB,Xmin,  Xmax);
  TH1D* hAsym_200 = new TH1D("hAsym_200"," ",NB,Xmin,  Xmax);
  TH1D* hPol_200  = new TH1D("hPol_200"," ",NB,Xmin,  Xmax);
  TH1D* hSig_201  = new TH1D("hSig_201"," ",NB,Xmin,  Xmax);
  TH1D* hAsym_201 = new TH1D("hAsym_201"," ",NB,Xmin,  Xmax);
  TH1D* hPol_201  = new TH1D("hPol_201"," ",NB,Xmin,  Xmax);

  double AMZ=91.1876; //91.18870000;
  double GAM=2.495378;//2.49520000;
  double DeltSQ = 0.0;
  double DeltV  = 0.0;
  double Gmu = 0.00001166389;
  for (int ID=0;ID<3;ID++){
    for (int kk=0;kk<NB;kk++){
      double Ener =Xmin+(0.5+kk)*aa;
      double s=Ener*Ener;
      int NN=500;
      for (int nn=0;nn<NN;nn++){
	double cc=-1.0+ 1./NN+(2.0/NN)*nn ;
	double Nor=2./NN;
	double Aor=2./NN;
	if(cc<0.) Aor=-2./NN;
	int mode,keyGSW;   // mode=1:  AMZ, GAM, s2w read from headers of the tables
	                   // keyGSW=1: complete set of form-factors
	                   // keyGSW=2: form-factors (1.0, 0.0), effective Born
	double s2w, alfinv;
	if (ID == 0 ) {

	  // Effective Born Approximation 
	  mode=0;  s2w=0.231499; alfinv=128.950302056; keyGSW=2;
	  hSig_000->Fill(Ener,Nor*sigbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  hAsym_000->Fill(Ener,Aor*sigbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  hPol_000->Fill(Ener,Nor*AsNbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  // Improved Born Approximation
	  mode=1;  s2w=0.0; alfinv=137.0359895; keyGSW=1;
	  hSig_001->Fill(Ener,Nor*sigbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  hAsym_001->Fill(Ener,Aor*sigbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  hPol_001->Fill(Ener,Nor*AsNbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	}
	if (ID == 1 ) {
	  // Effective Born Approximation 
	  mode=0;  s2w=0.231499;   alfinv=128.950302056; keyGSW=2;
	  hSig_100->Fill(Ener,Nor*sigbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  hAsym_100->Fill(Ener,Aor*sigbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  hPol_100->Fill(Ener,Nor*AsNbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  // Improved Born Approximation
	  mode=1;  s2w=0.0; alfinv=137.0359895; keyGSW=1;
	  hSig_101->Fill(Ener,Nor*sigbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  hAsym_101->Fill(Ener,Aor*sigbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  hPol_101->Fill(Ener,Nor*AsNbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	}
	if (ID == 2 ) {
	  // Effective Born Approximation 
	  mode=0;  s2w=0.231499;   alfinv=128.950302056; keyGSW=2;
	  hSig_200->Fill(Ener,Nor*sigbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  hAsym_200->Fill(Ener,Aor*sigbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  hPol_200->Fill(Ener,Nor*AsNbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  // Improved Born Approximation
	  mode=1;  s2w=0.0; alfinv=137.0359895; keyGSW=1;
	  hSig_201->Fill(Ener,Nor*sigbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  hAsym_201->Fill(Ener,Aor*sigbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	  hPol_201->Fill(Ener,Nor*AsNbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ, GAM, keyGSW));
	}
      }
    }
  }
  
  // writing histograms to file     
  TFile *file = new TFile("EWPO_test.root","recreate");

  hSig_001->Write();
  hAsym_001->Divide(hSig_001);
  hAsym_001->Write();
  hPol_001->Divide(hSig_001);
  hPol_001->Write();

  hSig_000->Write();
  hAsym_000->Divide(hSig_000);
  hAsym_000->Write();
  hPol_000->Divide(hSig_000);
  hPol_000->Write();

  hSig_101->Write();
  hAsym_101->Divide(hSig_101);
  hAsym_101->Write();
  hPol_101->Divide(hSig_101);
  hPol_101->Write();

  hSig_100->Write();
  hAsym_100->Divide(hSig_100);
  hAsym_100->Write();
  hPol_100->Divide(hSig_100);
  hPol_100->Write();

  hSig_201->Write();
  hAsym_201->Divide(hSig_201);
  hAsym_201->Write();
  hPol_201->Divide(hSig_201);
  hPol_201->Write();

  hSig_200->Write();
  hAsym_200->Divide(hSig_200);
  hAsym_200->Write();
  hPol_200->Divide(hSig_200);
  hPol_200->Write();


  
  file->Close();
   
}

      
