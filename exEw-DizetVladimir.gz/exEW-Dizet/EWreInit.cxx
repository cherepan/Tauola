void EWreInit(int variant){

       int mode=0;
       double GAMZ=2.495378490842;
       double AMZ0=91.1876;
       double s2w=0.231499;
       double DeltSQ=0.;
       double DeltV=0.;
       double Gmu=0.00001166389;
       double alfinv=128.9503020;
       int keyGSW=1;

       int ID=1;// dummy
       double s=(AMZ0)*(AMZ0);// dummy
       double si;// dummy
       double cc=0.5;// dummy

       if(variant==0){ //Born setup Tauola
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=2;  // no FF, fixed width
	 AMZ0=91.1887;
	 GAMZ=2.49520;
	 s2w=0.231520;
	 Gmu=0.00001166389;
	 alfinv=128.86674175;
       }
       if(variant==1){ //EW LO alpha(0) scheme
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=9;  // no FF, running width
	 GAMZ=2.49520;
         s2w=0.2121517;
	 alfinv =137.035999139;
       }      
       if(variant==2){ //EW NLO+HO alpha(0)
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=1;   // complete FF, running width
	 GAMZ=2.49520;
	 s2w=0.223401084;
	 alfinv =137.035999139;
       }
       if(variant==3){ //EW LO Gmu scheme
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=9;   // no FF, running width
	 GAMZ=2.49520;
	 s2w=0.2228972;
	 alfinv=132.233323;
       }
       if(variant==4){ //Born effective parametrised according to Dizet 6.45 EWPO
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=9;   // no FF, running width
	 GAMZ=2.49520;
	 s2w=0.231499;
	 alfinv=128.9503020;
       }
       if(variant==5){ //Born effective parametrised according to Dizet 6.45 EWPO
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=3;   // used selected FF(MZ), running width
	 GAMZ=2.49520;
	 s2w=0.231499;
	 alfinv=137.035999139;
       }
       if(variant==6){ //Born effective parametrised according to Dizet 6.45 EWPO
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=4;   // used selected FF(MZ), running width
	 GAMZ=2.49520;
	 s2w=0.231499;
	 alfinv=137.035999139;
       }
       if(variant==7){ //Born effective parametrised according to Dizet 6.45 EWPO
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=5;   // used selected FF(MZ), running width
	 GAMZ=2.49520;
	 s2w=0.2228972;
	 alfinv=137.035999139;
       }
       si=sigbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ0, GAMZ, keyGSW);
}
