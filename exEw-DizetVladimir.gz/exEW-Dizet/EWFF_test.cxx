#include <iostream>
#include <fstream>
#include <complex>
#include <string>
#include "TauSpinner/ew_born.h"
#include "TauSpinner/EWtables.h"

using namespace std;
using namespace TauSpinner;
//ROOT headers
#include "TH1.h"
#include "TF1.h"   
#include "TFile.h"

#include "DefHistograms.h"

int main(){

  // NOTE that choice for <mumu> implicates histograms header names
  //
  char* fmu=   "table.mu-6.45";  
  char* fdown= "table.down-6.45";
  char* fup=   "table.up-6.45";
   
  int FLAV=0;  // 0-lepton, 2-up, 1-down
    
  int j=initTables(fmu,fdown,fup); // initialization
  //int i=testit();  // general printout
  int i=0;
  cout << " Is initialisation OK? Control variables j,i=" << i <<" "<<j << endl;
  //   return 1;

  cout <<" "<< endl;
  cout <<" Electroweak formfactors as function of (flavour, consecutive number, s and cos(theta)): "<< endl;
  cout <<" "<< endl;
  cout.precision(8);
  
  double ener[10];  
  for (int kk=0;kk<10;kk++) ener[kk]=25.0+kk*50.0; // table of energies

  for (int iflav=0;iflav<=2;iflav++){
    printf(" *************************************\n");
    printf(" *  Tables of EW formfactors iflav= %d   *\n",iflav);
    printf(" *************************************\n");
    
    for (int kk=0;kk<10;kk++){
      printf("==> \n");
      printf("ene= %5.1f\n", ener[kk]);
      for (int ll=0;ll<=6;ll++){
	double cc= 0.1*(3*ll-9);
	double s=ener[kk]*ener[kk];
	printf("cos=%5.2f", cc);
	printf(":");
	
	for(int JJ=0; JJ<=3;JJ++){
	  int iffac=JJ;
	  complex<double> rezu= EWFACT(iflav, iffac, s, cc); 
	  printf(" FF%d =(%12.5e,%12.5e)", iffac,rezu.real(),rezu.imag());
	}
	for(int JJ=5; JJ<=6;JJ++){
	  int iffac=JJ;
	  complex<double> rezu= EWFACT(iflav, iffac, s, cc); 
	  printf(" FF%d =(%12.5e,%12.5e)", iffac,rezu.real(),rezu.imag());
	}
	cout <<" "<< endl;
      }
      cout <<" "<< endl;   
    }
    
    
    cout <<" "<< endl;
    cout <<" "<< endl;
    cout <<" Tables of QCD formfactors  "<< endl;
    cout <<" "<< endl;
    for (int kk=0;kk<10;kk++){
      double s=ener[kk]*ener[kk];
      printf("ene= %5.1f", ener[kk]);
      printf(": ");
      for(int JJ=0; JJ<=3;JJ++){
	int iffac=JJ;
	double rezu1= QCDFACT(iflav, iffac, s);
	printf(" FS%d = %8.3e", iffac,rezu1);
      }
      cout <<" "<< endl;
    }
    cout <<" "<< endl;
  }
  cout <<" "<< endl;
  cout <<" "<< endl;


  // Fill histograms with EW from-factors
  double dx=(xmax-xmin)/nbin;
  for (int kk=0;kk<nbin;kk++){
    double Ener =xmin+(0.5+kk)*dx;
    double SS = Ener*Ener;
    //FF for muons    
    hFF_000_1->Fill(Ener,real(EWFACT(0,0,SS,-0.99)));
    hFF_010_1->Fill(Ener,imag(EWFACT(0,0,SS,-0.99)));
    hFF_000_2->Fill(Ener,real(EWFACT(0,0,SS,-0.33)));
    hFF_010_2->Fill(Ener,imag(EWFACT(0,0,SS,-0.33)));
    hFF_000_3->Fill(Ener,real(EWFACT(0,0,SS, 0.0)));
    hFF_010_3->Fill(Ener,imag(EWFACT(0,0,SS, 0.0)));
    hFF_000_4->Fill(Ener,real(EWFACT(0,0,SS, 0.33)));
    hFF_010_4->Fill(Ener,imag(EWFACT(0,0,SS, 0.33)));
    hFF_000_5->Fill(Ener,real(EWFACT(0,0,SS, 0.99)));
    hFF_010_5->Fill(Ener,imag(EWFACT(0,0,SS, 0.99)));

    hFF_001_1->Fill(Ener,real(EWFACT(0,1,SS,-0.99)));
    hFF_011_1->Fill(Ener,imag(EWFACT(0,1,SS,-0.99)));
    hFF_001_2->Fill(Ener,real(EWFACT(0,1,SS,-0.33)));
    hFF_011_2->Fill(Ener,imag(EWFACT(0,1,SS,-0.33)));
    hFF_001_3->Fill(Ener,real(EWFACT(0,1,SS, 0.0)));
    hFF_011_3->Fill(Ener,imag(EWFACT(0,1,SS, 0.0)));
    hFF_001_4->Fill(Ener,real(EWFACT(0,1,SS, 0.33)));
    hFF_011_4->Fill(Ener,imag(EWFACT(0,1,SS, 0.33)));
    hFF_001_5->Fill(Ener,real(EWFACT(0,1,SS, 0.99)));
    hFF_011_5->Fill(Ener,imag(EWFACT(0,1,SS, 0.99)));

    hFF_002_1->Fill(Ener,real(EWFACT(0,2,SS,-0.99)));
    hFF_012_1->Fill(Ener,imag(EWFACT(0,2,SS,-0.99)));
    hFF_002_2->Fill(Ener,real(EWFACT(0,2,SS,-0.33)));
    hFF_012_2->Fill(Ener,imag(EWFACT(0,2,SS,-0.33)));
    hFF_002_3->Fill(Ener,real(EWFACT(0,2,SS, 0.0)));
    hFF_012_3->Fill(Ener,imag(EWFACT(0,2,SS, 0.0)));
    hFF_002_4->Fill(Ener,real(EWFACT(0,2,SS, 0.33)));
    hFF_012_4->Fill(Ener,imag(EWFACT(0,2,SS, 0.33)));
    hFF_002_5->Fill(Ener,real(EWFACT(0,2,SS, 0.99)));
    hFF_012_5->Fill(Ener,imag(EWFACT(0,2,SS, 0.99)));

    hFF_003_1->Fill(Ener,real(EWFACT(0,3,SS,-0.99)));
    hFF_013_1->Fill(Ener,imag(EWFACT(0,3,SS,-0.99)));
    hFF_003_2->Fill(Ener,real(EWFACT(0,3,SS,-0.33)));
    hFF_013_2->Fill(Ener,imag(EWFACT(0,3,SS,-0.33)));
    hFF_003_3->Fill(Ener,real(EWFACT(0,3,SS, 0.0)));
    hFF_013_3->Fill(Ener,imag(EWFACT(0,3,SS, 0.0)));
    hFF_003_4->Fill(Ener,real(EWFACT(0,3,SS, 0.33)));
    hFF_013_4->Fill(Ener,imag(EWFACT(0,3,SS, 0.33)));
    hFF_003_5->Fill(Ener,real(EWFACT(0,3,SS, 0.99)));
    hFF_013_5->Fill(Ener,imag(EWFACT(0,3,SS, 0.99)));

    hFF_006_1->Fill(Ener,real(EWFACT(0,6,SS,-0.99)));
    hFF_016_1->Fill(Ener,imag(EWFACT(0,6,SS,-0.99)));
    hFF_006_2->Fill(Ener,real(EWFACT(0,6,SS,-0.33)));
    hFF_016_2->Fill(Ener,imag(EWFACT(0,6,SS,-0.33)));
    hFF_006_3->Fill(Ener,real(EWFACT(0,6,SS, 0.0)));
    hFF_016_3->Fill(Ener,imag(EWFACT(0,6,SS, 0.0)));
    hFF_006_4->Fill(Ener,real(EWFACT(0,6,SS, 0.33)));
    hFF_016_4->Fill(Ener,imag(EWFACT(0,6,SS, 0.33)));
    hFF_006_5->Fill(Ener,real(EWFACT(0,6,SS, 0.99)));
    hFF_016_5->Fill(Ener,imag(EWFACT(0,6,SS, 0.99)));
    
    //FF for down-quarks    
    hFF_100_1->Fill(Ener,real(EWFACT(1,0,SS,-0.99)));
    hFF_110_1->Fill(Ener,imag(EWFACT(1,0,SS,-0.99)));
    hFF_100_2->Fill(Ener,real(EWFACT(1,0,SS,-0.33)));
    hFF_110_2->Fill(Ener,imag(EWFACT(1,0,SS,-0.33)));
    hFF_100_3->Fill(Ener,real(EWFACT(1,0,SS, 0.0)));
    hFF_110_3->Fill(Ener,imag(EWFACT(1,0,SS, 0.0)));
    hFF_100_4->Fill(Ener,real(EWFACT(1,0,SS, 0.33)));
    hFF_110_4->Fill(Ener,imag(EWFACT(1,0,SS, 0.33)));
    hFF_100_5->Fill(Ener,real(EWFACT(1,0,SS, 0.99)));
    hFF_110_5->Fill(Ener,imag(EWFACT(1,0,SS, 0.99)));

    hFF_101_1->Fill(Ener,real(EWFACT(1,1,SS,-0.99)));
    hFF_111_1->Fill(Ener,imag(EWFACT(1,1,SS,-0.99)));
    hFF_101_2->Fill(Ener,real(EWFACT(1,1,SS,-0.33)));
    hFF_111_2->Fill(Ener,imag(EWFACT(1,1,SS,-0.33)));
    hFF_101_3->Fill(Ener,real(EWFACT(1,1,SS, 0.0)));
    hFF_111_3->Fill(Ener,imag(EWFACT(1,1,SS, 0.0)));
    hFF_101_4->Fill(Ener,real(EWFACT(1,1,SS, 0.33)));
    hFF_111_4->Fill(Ener,imag(EWFACT(1,1,SS, 0.33)));
    hFF_101_5->Fill(Ener,real(EWFACT(1,1,SS, 0.99)));
    hFF_111_5->Fill(Ener,imag(EWFACT(1,1,SS, 0.99)));

    hFF_102_1->Fill(Ener,real(EWFACT(1,2,SS,-0.99)));
    hFF_112_1->Fill(Ener,imag(EWFACT(1,2,SS,-0.99)));
    hFF_102_2->Fill(Ener,real(EWFACT(1,2,SS,-0.33)));
    hFF_112_2->Fill(Ener,imag(EWFACT(1,2,SS,-0.33)));
    hFF_102_3->Fill(Ener,real(EWFACT(1,2,SS, 0.0)));
    hFF_112_3->Fill(Ener,imag(EWFACT(1,2,SS, 0.0)));
    hFF_102_4->Fill(Ener,real(EWFACT(1,2,SS, 0.33)));
    hFF_112_4->Fill(Ener,imag(EWFACT(1,2,SS, 0.33)));
    hFF_102_5->Fill(Ener,real(EWFACT(1,2,SS, 0.99)));
    hFF_112_5->Fill(Ener,imag(EWFACT(1,2,SS, 0.99)));

    hFF_103_1->Fill(Ener,real(EWFACT(1,3,SS,-0.99)));
    hFF_113_1->Fill(Ener,imag(EWFACT(1,3,SS,-0.99)));
    hFF_103_2->Fill(Ener,real(EWFACT(1,3,SS,-0.33)));
    hFF_113_2->Fill(Ener,imag(EWFACT(1,3,SS,-0.33)));
    hFF_103_3->Fill(Ener,real(EWFACT(1,3,SS, 0.0)));
    hFF_113_3->Fill(Ener,imag(EWFACT(1,3,SS, 0.0)));
    hFF_103_4->Fill(Ener,real(EWFACT(1,3,SS, 0.33)));
    hFF_113_4->Fill(Ener,imag(EWFACT(1,3,SS, 0.33)));
    hFF_103_5->Fill(Ener,real(EWFACT(1,3,SS, 0.99)));
    hFF_113_5->Fill(Ener,imag(EWFACT(1,3,SS, 0.99)));

    hFF_106_1->Fill(Ener,real(EWFACT(1,6,SS,-0.99)));
    hFF_116_1->Fill(Ener,imag(EWFACT(1,6,SS,-0.99)));
    hFF_106_2->Fill(Ener,real(EWFACT(1,6,SS,-0.33)));
    hFF_116_2->Fill(Ener,imag(EWFACT(1,6,SS,-0.33)));
    hFF_106_3->Fill(Ener,real(EWFACT(1,6,SS, 0.0)));
    hFF_116_3->Fill(Ener,imag(EWFACT(1,6,SS, 0.0)));
    hFF_106_4->Fill(Ener,real(EWFACT(1,6,SS, 0.33)));
    hFF_116_4->Fill(Ener,imag(EWFACT(1,6,SS, 0.33)));
    hFF_106_5->Fill(Ener,real(EWFACT(1,6,SS, 0.99)));
    hFF_116_5->Fill(Ener,imag(EWFACT(1,6,SS, 0.99)));
    
    //FF for up-quarks    
    hFF_200_1->Fill(Ener,real(EWFACT(2,0,SS,-0.99)));
    hFF_210_1->Fill(Ener,imag(EWFACT(2,0,SS,-0.99)));
    hFF_200_2->Fill(Ener,real(EWFACT(2,0,SS,-0.33)));
    hFF_210_2->Fill(Ener,imag(EWFACT(2,0,SS,-0.33)));
    hFF_200_3->Fill(Ener,real(EWFACT(2,0,SS, 0.0)));
    hFF_210_3->Fill(Ener,imag(EWFACT(2,0,SS, 0.0)));
    hFF_200_4->Fill(Ener,real(EWFACT(2,0,SS, 0.33)));
    hFF_210_4->Fill(Ener,imag(EWFACT(2,0,SS, 0.33)));
    hFF_200_5->Fill(Ener,real(EWFACT(2,0,SS, 0.99)));
    hFF_210_5->Fill(Ener,imag(EWFACT(2,0,SS, 0.99)));

    hFF_201_1->Fill(Ener,real(EWFACT(2,1,SS,-0.99)));
    hFF_211_1->Fill(Ener,imag(EWFACT(2,1,SS,-0.99)));
    hFF_201_2->Fill(Ener,real(EWFACT(2,1,SS,-0.33)));
    hFF_211_2->Fill(Ener,imag(EWFACT(2,1,SS,-0.33)));
    hFF_201_3->Fill(Ener,real(EWFACT(2,1,SS, 0.0)));
    hFF_211_3->Fill(Ener,imag(EWFACT(2,1,SS, 0.0)));
    hFF_201_4->Fill(Ener,real(EWFACT(2,1,SS, 0.33)));
    hFF_211_4->Fill(Ener,imag(EWFACT(2,1,SS, 0.33)));
    hFF_201_5->Fill(Ener,real(EWFACT(2,1,SS, 0.99)));
    hFF_211_5->Fill(Ener,imag(EWFACT(2,1,SS, 0.99)));

    hFF_202_1->Fill(Ener,real(EWFACT(2,2,SS,-0.99)));
    hFF_212_1->Fill(Ener,imag(EWFACT(2,2,SS,-0.99)));
    hFF_202_2->Fill(Ener,real(EWFACT(2,2,SS,-0.33)));
    hFF_212_2->Fill(Ener,imag(EWFACT(2,2,SS,-0.33)));
    hFF_202_3->Fill(Ener,real(EWFACT(2,2,SS, 0.0)));
    hFF_212_3->Fill(Ener,imag(EWFACT(2,2,SS, 0.0)));
    hFF_202_4->Fill(Ener,real(EWFACT(2,2,SS, 0.33)));
    hFF_212_4->Fill(Ener,imag(EWFACT(2,2,SS, 0.33)));
    hFF_202_5->Fill(Ener,real(EWFACT(2,2,SS, 0.99)));
    hFF_212_5->Fill(Ener,imag(EWFACT(2,2,SS, 0.99)));

    hFF_203_1->Fill(Ener,real(EWFACT(2,3,SS,-0.99)));
    hFF_213_1->Fill(Ener,imag(EWFACT(2,3,SS,-0.99)));
    hFF_203_2->Fill(Ener,real(EWFACT(2,3,SS,-0.33)));
    hFF_213_2->Fill(Ener,imag(EWFACT(2,3,SS,-0.33)));
    hFF_203_3->Fill(Ener,real(EWFACT(2,3,SS, 0.0)));
    hFF_213_3->Fill(Ener,imag(EWFACT(2,3,SS, 0.0)));
    hFF_203_4->Fill(Ener,real(EWFACT(2,3,SS, 0.33)));
    hFF_213_4->Fill(Ener,imag(EWFACT(2,3,SS, 0.33)));
    hFF_203_5->Fill(Ener,real(EWFACT(2,3,SS, 0.99)));
    hFF_213_5->Fill(Ener,imag(EWFACT(2,3,SS, 0.99)));

    hFF_206_1->Fill(Ener,real(EWFACT(2,6,SS,-0.99)));
    hFF_216_1->Fill(Ener,imag(EWFACT(2,6,SS,-0.99)));
    hFF_206_2->Fill(Ener,real(EWFACT(2,6,SS,-0.33)));
    hFF_216_2->Fill(Ener,imag(EWFACT(2,6,SS,-0.33)));
    hFF_206_3->Fill(Ener,real(EWFACT(2,6,SS, 0.0)));
    hFF_216_3->Fill(Ener,imag(EWFACT(2,6,SS, 0.0)));
    hFF_206_4->Fill(Ener,real(EWFACT(2,6,SS, 0.33)));
    hFF_216_4->Fill(Ener,imag(EWFACT(2,6,SS, 0.33)));
    hFF_206_5->Fill(Ener,real(EWFACT(2,6,SS, 0.99)));
    hFF_216_5->Fill(Ener,imag(EWFACT(2,6,SS, 0.99)));

  }
  
  // write histograms to a file     
  TFile *file = new TFile("EWFF_test.root","recreate");

  writeHistos();
  
  file->Close();
   
}
