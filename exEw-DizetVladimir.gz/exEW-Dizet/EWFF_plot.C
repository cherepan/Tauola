#include "DefPlots.h"

void EWFF_plot()
{ 

 gStyle->SetStatColor(0);
 gStyle->SetTitleFillColor(0);

 gROOT->SetStyle("ATLAS");
 gROOT->ForceStyle();

//-------------------------------------------------------------------------------------------------------
TFile *fout  = TFile::Open("EWFF_test.root");
//-------------------------------------------------------------------------------------------------------


 TString legend2 = "cos#theta = -0.99";
 TString legend3 = "cos#theta = -0.33";
 TString legend4 = "cos#theta = 0.0";
 TString legend5 = "cos#theta = 0.33";
 TString legend6 = "cos#theta = 0.99";

 TString Xlabel  = "m_{#mu#mu} (GeV)";
 //-----------------------------------------------------

 //-----
 TString Ylabel  = "Re(#rho)";
 TString legend1 = "EWFF Re(#rho): e^{+}e^{-} #rightarrow #mu^{+}#mu^{-} ";
 drawFiveOverlyNoError(hFF_000_1,hFF_000_2,hFF_000_3, hFF_000_4, hFF_000_5,
		    "hEWFF_000",
		     1.02, 0.995, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);

 TString Ylabel  = "Im(#rho)";
 TString legend1 = "EWFF Im(#rho): e^{+}e^{-} #rightarrow #mu^{+}#mu^{-} ";
 drawFiveOverlyNoError(hFF_010_1,hFF_010_2,hFF_010_3, hFF_010_4, hFF_010_5,
		    "hEWFF_010",
		     0.0, -0.01, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 0, 0, 2);

 //-----
 TString Ylabel  = "Re(K)";
 TString legend1 = "EWFF Re(K): e^{+}e^{-} #rightarrow #mu^{+}#mu^{-} ";
 drawFiveOverlyNoError(hFF_001_1,hFF_001_2,hFF_001_3, hFF_001_4, hFF_001_5,
		    "hEWFF_001",
		     1.06, 1.02, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
 
 TString Ylabel  = "Im(K)";
 TString legend1 = "EWFF Im(K): e^{+}e^{-} #rightarrow #mu^{+}#mu^{-} ";
 drawFiveOverlyNoError(hFF_011_1,hFF_011_2,hFF_011_3, hFF_011_4, hFF_011_5,
		    "hEWFF_011",
		     0.02, 0.01, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);

 //-----
 TString Ylabel  = "Re(K)";
 TString legend1 = "EWFF Re(K): e^{+}e^{-} #rightarrow #mu^{+}#mu^{-} ";
 drawFiveOverlyNoError(hFF_002_1,hFF_002_2,hFF_002_3, hFF_002_4, hFF_002_5,
		    "hEWFF_002",
		     1.06, 1.02, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
 
 TString Ylabel  = "Im(K)";
 TString legend1 = "EWFF Im(K): e^{+}e^{-} #rightarrow #mu^{+}#mu^{-} ";
 drawFiveOverlyNoError(hFF_012_1,hFF_012_2,hFF_012_3, hFF_012_4, hFF_012_5,
		    "hEWFF_012",
		     0.02, 0.01, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);

 //-----
 TString Ylabel  = "Re(K)";
 TString legend1 = "EWFF Re(K): e^{+}e^{-} #rightarrow #mu^{+}#mu^{-} ";
 drawFiveOverlyNoError(hFF_003_1,hFF_003_2,hFF_003_3, hFF_003_4, hFF_003_5,
		    "hEWFF_003",
		     1.10, 1.06, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
 
 TString Ylabel  = "Im(K)";
 TString legend1 = "EWFF Im(K): e^{+}e^{-} #rightarrow #mu^{+}#mu^{-} ";
 drawFiveOverlyNoError(hFF_013_1,hFF_013_2,hFF_013_3, hFF_013_4, hFF_013_5,
		    "hEWFF_013",
		     0.04, 0.02, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
 //-----
 TString Ylabel  = "Re(#pi)";
 TString legend1 = "EWFF Re(#pi): e^{+}e^{-} #rightarrow #mu^{+}#mu^{-} ";
 drawFiveOverlyNoError(hFF_006_1,hFF_006_2,hFF_006_3, hFF_006_4, hFF_006_5,
		    "hEWFF_006",
		     1.07, 1.05, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);


 TString Ylabel  = "Im(#pi)";
 TString legend1 = "EWFF Im(#pi): e^{+}e^{-} #rightarrow #mu^{+}#mu^{-} ";
 drawFiveOverlyNoError(hFF_016_1,hFF_016_2,hFF_016_3, hFF_016_4, hFF_016_5,
		    "hEWFF_016",
		     -0.01, -0.02, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
 

 TString Xlabel  = "m_{d dbar} (GeV)";
 //-----------------------------------------------------
 
 //-----
 TString Ylabel  = "Re(#rho)";
 TString legend1 = "EWFF Re(#rho): e^{+}e^{-} #rightarrow d^{+}d^{-} ";
 drawFiveOverlyNoError(hFF_100_1,hFF_100_2,hFF_100_3, hFF_100_4, hFF_100_5,
		    "hEWFF_100",
		     1.02, 0.995, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);

 TString Ylabel  = "Im(#rho)";
 TString legend1 = "EWFF Im(#rho): e^{+}e^{-} #rightarrow d^{+}d^{-} ";
 drawFiveOverlyNoError(hFF_110_1,hFF_110_2,hFF_110_3, hFF_110_4, hFF_110_5,
		    "hEWFF_110",
		     0.0, -0.01, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 0, 0, 2);

 //-----
 TString Ylabel  = "Re(K)";
 TString legend1 = "EWFF Re(K): e^{+}e^{-} #rightarrow d^{+}d^{-} ";
 drawFiveOverlyNoError(hFF_101_1,hFF_101_2,hFF_101_3, hFF_101_4, hFF_101_5,
		    "hEWFF_101",
		     1.06, 1.02, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
 
 TString Ylabel  = "Im(K)";
 TString legend1 = "EWFF Im(K): e^{+}e^{-} #rightarrow d^{+}d^{-} ";
 drawFiveOverlyNoError(hFF_111_1,hFF_111_2,hFF_111_3, hFF_111_4, hFF_111_5,
		    "hEWFF_111",
		     0.025, 0.01, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);

 //-----
 TString Ylabel  = "Re(K)";
 TString legend1 = "EWFF Re(K): e^{+}e^{-} #rightarrow d^{+}d^{-} ";
 drawFiveOverlyNoError(hFF_102_1,hFF_102_2,hFF_102_3, hFF_102_4, hFF_102_5,
		    "hEWFF_102",
		     1.06, 1.02, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
 
 TString Ylabel  = "Im(K)";
 TString legend1 = "EWFF Im(K): e^{+}e^{-} #rightarrow d^{+}d^{-} ";
 drawFiveOverlyNoError(hFF_112_1,hFF_112_2,hFF_112_3, hFF_112_4, hFF_112_5,
		    "hEWFF_112",
		     0.025, 0.01, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);

 //-----
 TString Ylabel  = "Re(K)";
 TString legend1 = "EWFF Re(K): e^{+}e^{-} #rightarrow d^{+}d^{-} ";
 drawFiveOverlyNoError(hFF_103_1,hFF_103_2,hFF_103_3, hFF_103_4, hFF_103_5,
		    "hEWFF_103",
		     1.10, 1.05, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
 
 TString Ylabel  = "Im(K)";
 TString legend1 = "EWFF Im(K): e^{+}e^{-} #rightarrow d^{+}d^{-} ";
 drawFiveOverlyNoError(hFF_113_1,hFF_113_2,hFF_113_3, hFF_113_4, hFF_113_5,
		    "hEWFF_113",
		     0.04, 0.02, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
 //-----
 TString Ylabel  = "Re(#pi)";
 TString legend1 = "EWFF Re(#pi): e^{+}e^{-} #rightarrow d^{+}d^{-} ";
 drawFiveOverlyNoError(hFF_106_1,hFF_106_2,hFF_106_3, hFF_106_4, hFF_106_5,
		    "hEWFF_106",
		     1.07, 1.05, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);


 TString Ylabel  = "Im(#pi)";
 TString legend1 = "EWFF Im(#pi): e^{+}e^{-} #rightarrow d^{+}d^{-} ";
 drawFiveOverlyNoError(hFF_116_1,hFF_116_2,hFF_116_3, hFF_116_4, hFF_116_5,
		    "hEWFF_116",
		     -0.01, -0.02, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
 

 TString Xlabel  = "m_{u ubar} (GeV)";
 //-----------------------------------------------------

 //-----
 TString Ylabel  = "Re(#rho)";
 TString legend1 = "EWFF Re(#rho): e^{+}e^{-} #rightarrow u^{+}u^{-} ";
 drawFiveOverlyNoError(hFF_200_1,hFF_200_2,hFF_200_3, hFF_200_4, hFF_200_5,
		    "hEWFF_200",
		     1.03, 0.98, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);

 TString Ylabel  = "Im(#rho)";
 TString legend1 = "EWFF Im(#rho): e^{+}e^{-} #rightarrow u^{+}u^{-} ";
 drawFiveOverlyNoError(hFF_210_1,hFF_210_2,hFF_210_3, hFF_210_4, hFF_210_5,
		    "hEWFF_210",
		     0.0, -0.01, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 0, 0, 2);

 //-----
 TString Ylabel  = "Re(K)";
 TString legend1 = "EWFF Re(K): e^{+}e^{-} #rightarrow u^{+}u^{-} ";
 drawFiveOverlyNoError(hFF_201_1,hFF_201_2,hFF_201_3, hFF_201_4, hFF_201_5,
		    "hEWFF_201",
		     1.08, 1.02, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
 
 TString Ylabel  = "Im(K)";
 TString legend1 = "EWFF Im(K): e^{+}e^{-} #rightarrow u^{+}u^{-} ";
 drawFiveOverlyNoError(hFF_211_1,hFF_211_2,hFF_211_3, hFF_211_4, hFF_211_5,
		    "hEWFF_211",
		     0.02, 0.01, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);

 //-----
 TString Ylabel  = "Re(K)";
 TString legend1 = "EWFF Re(K): e^{+}e^{-} #rightarrow u^{+}u^{-} ";
 drawFiveOverlyNoError(hFF_202_1,hFF_202_2,hFF_202_3, hFF_202_4, hFF_202_5,
		    "hEWFF_202",
		     1.08, 1.02, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
 
 TString Ylabel  = "Im(K)";
 TString legend1 = "EWFF Im(K): e^{+}e^{-} #rightarrow u^{+}u^{-} ";
 drawFiveOverlyNoError(hFF_212_1,hFF_212_2,hFF_212_3, hFF_212_4, hFF_212_5,
		    "hEWFF_212",
		     0.02, 0.01, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);

 //-----
 TString Ylabel  = "Re(K)";
 TString legend1 = "EWFF Re(K): e^{+}e^{-} #rightarrow u^{+}u^{-} ";
 drawFiveOverlyNoError(hFF_203_1,hFF_203_2,hFF_203_3, hFF_203_4, hFF_203_5,
		    "hEWFF_203",
		     1.12, 1.06, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
 
 TString Ylabel  = "Im(K)";
 TString legend1 = "EWFF Im(K): e^{+}e^{-} #rightarrow u^{+}u^{-} ";
 drawFiveOverlyNoError(hFF_213_1,hFF_213_2,hFF_213_3, hFF_213_4, hFF_213_5,
		    "hEWFF_213",
		     0.04, 0.02, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
 //-----
 TString Ylabel  = "Re(#pi)";
 TString legend1 = "EWFF Re(#pi): e^{+}e^{-} #rightarrow u^{+}u^{-} ";
 drawFiveOverlyNoError(hFF_206_1,hFF_206_2,hFF_206_3, hFF_206_4, hFF_206_5,
		    "hEWFF_206",
		     1.07, 1.05, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);


 TString Ylabel  = "Im(#pi)";
 TString legend1 = "EWFF Im(#pi): e^{+}e^{-} #rightarrow u^{+}u^{-} ";
 drawFiveOverlyNoError(hFF_216_1,hFF_216_2,hFF_216_3, hFF_216_4, hFF_216_5,
		    "hEWFF_216",
		     -0.01, -0.02, Xlabel, Ylabel, legend1, legend2, legend3, legend4, legend5, legend6, 1, 0, 2);
  
}
