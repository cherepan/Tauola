#include "DefPlots.h"

void EWPO_MCevt_plot()
{ 

 gStyle->SetStatColor(0);
 gStyle->SetTitleFillColor(0);

 gROOT->SetStyle("ATLAS");
 gROOT->ForceStyle();



//-------------------------------------------------------------------------------------------------------
TFile *froot  = TFile::Open("EWPO_MCevt_test.root");

TH1D* hMC_Sig_0 = (TH1D*)(froot->Get("hSig_0")->Clone());
TH1D* hMC_Sig_0_ratio_1 = (TH1D*)(froot->Get("hSig_0")->Clone());
TH1D* hMC_Sig_1 = (TH1D*)(froot->Get("hSig_1")->Clone());
TH1D* hMC_Sig_2 = (TH1D*)(froot->Get("hSig_2")->Clone());
TH1D* hMC_Sig_2_ratio_1 = (TH1D*)(froot->Get("hSig_2")->Clone());
TH1D* hMC_Sig_3 = (TH1D*)(froot->Get("hSig_3")->Clone());
TH1D* hMC_Sig_3_ratio_1 = (TH1D*)(froot->Get("hSig_3")->Clone());
TH1D* hMC_Sig_3_ratio_2 = (TH1D*)(froot->Get("hSig_3")->Clone());
TH1D* hMC_Sig_4 = (TH1D*)(froot->Get("hSig_4")->Clone());
TH1D* hMC_Sig_4_ratio_1 = (TH1D*)(froot->Get("hSig_4")->Clone());
TH1D* hMC_Sig_4_ratio_2 = (TH1D*)(froot->Get("hSig_4")->Clone());
TH1D* hMC_Sig_5 = (TH1D*)(froot->Get("hSig_5")->Clone());
TH1D* hMC_Sig_5_ratio_1 = (TH1D*)(froot->Get("hSig_5")->Clone());
TH1D* hMC_Sig_5_ratio_2 = (TH1D*)(froot->Get("hSig_5")->Clone());
TH1D* hMC_Sig_6 = (TH1D*)(froot->Get("hSig_6")->Clone());
TH1D* hMC_Sig_6_ratio_1 = (TH1D*)(froot->Get("hSig_6")->Clone());
TH1D* hMC_Sig_6_ratio_2 = (TH1D*)(froot->Get("hSig_6")->Clone());
TH1D* hMC_Sig_7 = (TH1D*)(froot->Get("hSig_7")->Clone());
TH1D* hMC_Sig_7_ratio_1 = (TH1D*)(froot->Get("hSig_7")->Clone());
TH1D* hMC_Sig_7_ratio_2 = (TH1D*)(froot->Get("hSig_7")->Clone());

TH1D* hMC_Sig_F_0 = (TH1D*)(froot->Get("hSig_F_0")->Clone());
TH1D* hMC_Sig_B_0 = (TH1D*)(froot->Get("hSig_B_0")->Clone());
TH1D* hMC_Sig_F_1 = (TH1D*)(froot->Get("hSig_F_1")->Clone());
TH1D* hMC_Sig_B_1 = (TH1D*)(froot->Get("hSig_B_1")->Clone());
TH1D* hMC_Sig_F_2 = (TH1D*)(froot->Get("hSig_F_2")->Clone());
TH1D* hMC_Sig_B_2 = (TH1D*)(froot->Get("hSig_B_2")->Clone());
TH1D* hMC_Sig_F_3 = (TH1D*)(froot->Get("hSig_F_3")->Clone());
TH1D* hMC_Sig_B_3 = (TH1D*)(froot->Get("hSig_B_3")->Clone());
TH1D* hMC_Sig_F_4 = (TH1D*)(froot->Get("hSig_F_4")->Clone());
TH1D* hMC_Sig_B_4 = (TH1D*)(froot->Get("hSig_B_4")->Clone());
TH1D* hMC_Sig_F_5 = (TH1D*)(froot->Get("hSig_F_5")->Clone());
TH1D* hMC_Sig_B_5 = (TH1D*)(froot->Get("hSig_B_5")->Clone());
TH1D* hMC_Sig_F_6 = (TH1D*)(froot->Get("hSig_F_6")->Clone());
TH1D* hMC_Sig_B_6 = (TH1D*)(froot->Get("hSig_B_6")->Clone());
TH1D* hMC_Sig_F_7 = (TH1D*)(froot->Get("hSig_F_7")->Clone());
TH1D* hMC_Sig_B_7 = (TH1D*)(froot->Get("hSig_B_7")->Clone());

TH1D* hMC_Costhe_0 = (TH1D*)(froot->Get("hCosthe_0")->Clone());
TH1D* hMC_Costhe_0_ratio_1 = (TH1D*)(froot->Get("hCosthe_0")->Clone());
TH1D* hMC_Costhe_1 = (TH1D*)(froot->Get("hCosthe_1")->Clone());
TH1D* hMC_Costhe_2 = (TH1D*)(froot->Get("hCosthe_2")->Clone());
TH1D* hMC_Costhe_2_ratio_1 = (TH1D*)(froot->Get("hCosthe_2")->Clone());
TH1D* hMC_Costhe_3 = (TH1D*)(froot->Get("hCosthe_3")->Clone());
TH1D* hMC_Costhe_3_ratio_1 = (TH1D*)(froot->Get("hCosthe_3")->Clone());
TH1D* hMC_Costhe_3_ratio_2 = (TH1D*)(froot->Get("hCosthe_3")->Clone());
TH1D* hMC_Costhe_4 = (TH1D*)(froot->Get("hCosthe_4")->Clone());
TH1D* hMC_Costhe_4_ratio_1 = (TH1D*)(froot->Get("hCosthe_4")->Clone());
TH1D* hMC_Costhe_4_ratio_2 = (TH1D*)(froot->Get("hCosthe_4")->Clone());
TH1D* hMC_Costhe_5 = (TH1D*)(froot->Get("hCosthe_5")->Clone());
TH1D* hMC_Costhe_5_ratio_1 = (TH1D*)(froot->Get("hCosthe_5")->Clone());
TH1D* hMC_Costhe_5_ratio_2 = (TH1D*)(froot->Get("hCosthe_5")->Clone());
TH1D* hMC_Costhe_6 = (TH1D*)(froot->Get("hCosthe_6")->Clone());
TH1D* hMC_Costhe_6_ratio_1 = (TH1D*)(froot->Get("hCosthe_6")->Clone());
TH1D* hMC_Costhe_6_ratio_2 = (TH1D*)(froot->Get("hCosthe_6")->Clone());
TH1D* hMC_Costhe_7 = (TH1D*)(froot->Get("hCosthe_7")->Clone());
TH1D* hMC_Costhe_7_ratio_1 = (TH1D*)(froot->Get("hCosthe_7")->Clone());
TH1D* hMC_Costhe_7_ratio_2 = (TH1D*)(froot->Get("hCosthe_7")->Clone());

TH1D* hMC_Asym_0 = (TH1D*)(froot->Get("hAsym_0")->Clone());
TH1D* hMC_Asym_0_delt_1 = (TH1D*)(froot->Get("hAsym_0")->Clone());
hMC_Asym_0_delt_1->Reset();
TH1D* hMC_Asym_1 = (TH1D*)(froot->Get("hAsym_1")->Clone());
TH1D* hMC_Asym_2 = (TH1D*)(froot->Get("hAsym_2")->Clone());
TH1D* hMC_Asym_2_delt_1 = (TH1D*)(froot->Get("hAsym_2")->Clone());
hMC_Asym_2_delt_1->Reset();
TH1D* hMC_Asym_3 = (TH1D*)(froot->Get("hAsym_3")->Clone());
TH1D* hMC_Asym_3_delt_1 = (TH1D*)(froot->Get("hAsym_3")->Clone());
hMC_Asym_3_delt_1->Reset();
TH1D* hMC_Asym_3_delt_2 = (TH1D*)(froot->Get("hAsym_3")->Clone());
hMC_Asym_3_delt_2->Reset();
TH1D* hMC_Asym_4 = (TH1D*)(froot->Get("hAsym_4")->Clone());
TH1D* hMC_Asym_4_delt_1 = (TH1D*)(froot->Get("hAsym_4")->Clone());
hMC_Asym_4_delt_1->Reset();
TH1D* hMC_Asym_4_delt_2 = (TH1D*)(froot->Get("hAsym_4")->Clone());
hMC_Asym_4_delt_2->Reset();
TH1D* hMC_Asym_5 = (TH1D*)(froot->Get("hAsym_5")->Clone());
TH1D* hMC_Asym_5_delt_1 = (TH1D*)(froot->Get("hAsym_5")->Clone());
hMC_Asym_5_delt_1->Reset();
TH1D* hMC_Asym_5_delt_2 = (TH1D*)(froot->Get("hAsym_5")->Clone());
hMC_Asym_5_delt_2->Reset();
TH1D* hMC_Asym_6 = (TH1D*)(froot->Get("hAsym_6")->Clone());
TH1D* hMC_Asym_6_delt_1 = (TH1D*)(froot->Get("hAsym_6")->Clone());
hMC_Asym_6_delt_1->Reset();
TH1D* hMC_Asym_6_delt_2 = (TH1D*)(froot->Get("hAsym_6")->Clone());
hMC_Asym_6_delt_2->Reset();
TH1D* hMC_Asym_7 = (TH1D*)(froot->Get("hAsym_7")->Clone());
TH1D* hMC_Asym_7_delt_1 = (TH1D*)(froot->Get("hAsym_7")->Clone());
hMC_Asym_7_delt_1->Reset();
TH1D* hMC_Asym_7_delt_2 = (TH1D*)(froot->Get("hAsym_7")->Clone());
hMC_Asym_7_delt_2->Reset();

 
//-------------------------------------------------------------------------------------------------------

 TString legendspace = " ";

 TString legend1 = "pp#rightarrow Z #rightarrow #tau^{+}#tau^{-} ";
 TString Xlabel  = "m_{#tau#tau} (GeV)";
 
 TString Ylabel  = "Events";
 TString legend2 = "#sigma^{tot} (Born IBA) ";
 drawOneOverlyNoError(hMC_Sig_2,
		    "hMC_Sig_2",
		      3.0e+5., 1.0e+2, Xlabel, Ylabel, legend1, legendspace, legendspace, legend2, 0, 1);

 hMC_Sig_2_ratio_1->Divide(hMC_Sig_1);
 TString Ylabel  = "Ratio";
 TString legend2 = "Ratio #sigma^{tot} (Born IBA)/#sigma^{tot} (Born EW LO #alpha(0))";
 drawOneOverlyNoError(hMC_Sig_2_ratio_1,
		     "hMC_Sig_2_ratio_1",
		      1.05, 0.96, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 2);

 hMC_Sig_3_ratio_1->Divide(hMC_Sig_1);
 TString Ylabel  = "Ratio";
 TString legend2 = "Ratio #sigma^{tot} (Born EW G_{#mu})/#sigma^{tot} (Born EW LO #alpha(0))";
 drawOneOverlyNoError(hMC_Sig_3_ratio_1,
		     "hMC_Sig_3_ratio_1",
		      1.05, 0.95, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 2);

 hMC_Sig_3_ratio_2->Divide(hMC_Sig_2);
 TString Ylabel  = "Ratio";
 TString legend2 = "Ratio #sigma^{tot} (Born EW LO G_{#mu})/#sigma^{tot} (Born IBA)";
 drawOneOverlyNoError(hMC_Sig_3_ratio_2,
		     "hMC_Sig_3_ratio_2",
		      1.02, 0.98, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 2);

 hMC_Sig_4_ratio_2->Divide(hMC_Sig_2);
 TString Ylabel  = "Ratio";
 TString legend2 = "Ratio #sigma^{tot} (Born Eff v0)/#sigma^{tot} (Born IBA)";
 drawOneOverlyNoError(hMC_Sig_4_ratio_2,
		     "hMC_Sig_4_ratio_2",
		      1.02, 0.98, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 2);

 hMC_Sig_5_ratio_2->Divide(hMC_Sig_2);
 TString Ylabel  = "Ratio";
 TString legend2 = "Ratio #sigma^{tot} (Born Eff v1)/#sigma^{tot} (Born IBA)";
 drawOneOverlyNoError(hMC_Sig_5_ratio_2,
		     "hMC_Sig_5_ratio_2",
		      1.02, 0.98, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 2);

 hMC_Sig_6_ratio_2->Divide(hMC_Sig_2);
 TString Ylabel  = "Ratio";
 TString legend2 = "Ratio #sigma^{tot} (Born Eff v2)/#sigma^{tot} (Born IBA)";
 drawOneOverlyNoError(hMC_Sig_6_ratio_2,
		     "hMC_Sig_6_ratio_2",
		      1.01, 0.995, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 2);

 hMC_Sig_7_ratio_2->Divide(hMC_Sig_2);
 TString Ylabel  = "Ratio";
 TString legend2 = "Ratio #sigma^{tot} (Born Eff v3)/#sigma^{tot} (Born IBA)";
 drawOneOverlyNoError(hMC_Sig_7_ratio_2,
		     "hMC_Sig_7_ratio_2",
		      1.01, 0.995, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 2);

  
//-------------------------------------------------------------------------------------------------------

 TString Ylabel  = "Events";
 TString Xlabel  = "cos#theta^{*} ";
 TString legend2 = "cos#theta^{*} (Born IBA) ";
 drawOneOverlyNoError(hMC_Costhe_2,
		    "hMC_Costhe_2",
		      2.0e+4, 5.0e+3, Xlabel, Ylabel, legend1, legendspace, legendspace, legend2, 0, 0);
 
 hMC_Costhe_2_ratio_1->Divide(hMC_Costhe_1);
 TString Ylabel  = "Ratio";
 TString Xlabel  = "cos#theta^{*} ";
 TString legend2 = "Ratio cos#theta^{*} (Born IBA)/cos#theta^{*} (Born EW LO #alpha(0))";
 drawOneOverlyNoError(hMC_Costhe_2_ratio_1,
		     "hMC_Costhe_2_ratio_1",
		      1.10, 0.90, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 2);

 hMC_Costhe_3_ratio_1->Divide(hMC_Costhe_1);
 TString Ylabel  = "Ratio";
 TString Xlabel  = "cos#theta^{*} ";
 TString legend2 = "Ratio cos#theta^{*} (Born EW LO G_{#mu})/cos#theta^{*} (Born EW LO #alpha(0))";
 drawOneOverlyNoError(hMC_Costhe_3_ratio_1,
		     "hMC_Costhe_3_ratio_1",
		      1.10, 0.90, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 2);
  
 hMC_Costhe_3_ratio_2->Divide(hMC_Costhe_2);
 TString Ylabel  = "Ratio";
 TString Xlabel  = "cos#theta^{*} ";
 TString legend2 = "Ratio cos#theta^{*} (Born  EW LO G_{#mu})/cos#theta^{*} (Born IBA)";
 drawOneOverlyNoError(hMC_Costhe_3_ratio_2,
		     "hMC_Costhe_3_ratio_2",
		      1.1, 0.95, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 2);
  
 hMC_Costhe_4_ratio_2->Divide(hMC_Costhe_2);
 TString Ylabel  = "Ratio";
 TString Xlabel  = "cos#theta^{*} ";
 TString legend2 = "Ratio cos#theta^{*} (Born  Eff v0 )/cos#theta^{*} (Born IBA)";
 drawOneOverlyNoError(hMC_Costhe_4_ratio_2,
		     "hMC_Costhe_4_ratio_2",
		      1.1, 0.95, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 2);

 hMC_Costhe_5_ratio_2->Divide(hMC_Costhe_2);
 TString Ylabel  = "Ratio";
 TString Xlabel  = "cos#theta^{*} ";
 TString legend2 = "Ratio cos#theta^{*} (Born Eff v1)/cos#theta^{*} (Born IBA)";
 drawOneOverlyNoError(hMC_Costhe_5_ratio_2,
		     "hMC_Costhe_5_ratio_2",
		      0.995, 0.985, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 2);
 
 hMC_Costhe_6_ratio_2->Divide(hMC_Costhe_2);
 TString Ylabel  = "Ratio";
 TString Xlabel  = "cos#theta^{*} ";
 TString legend2 = "Ratio cos#theta^{*} (Born Eff v2)/cos#theta^{*} (Born IBA)";
 drawOneOverlyNoError(hMC_Costhe_6_ratio_2,
		     "hMC_Costhe_6_ratio_2",
		      1.002, 0.998, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 2);
 
 hMC_Costhe_7_ratio_2->Divide(hMC_Costhe_2);
 TString Ylabel  = "Ratio";
 TString Xlabel  = "cos#theta^{*} ";
 TString legend2 = "Ratio cos#theta^{*} (Born Eff v3)/cos#theta^{*} (Born IBA)";
 drawOneOverlyNoError(hMC_Costhe_7_ratio_2,
		     "hMC_Costhe_7_ratio_2",
		      1.005, 0.998, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 2);
 
//-------------------------------------------------------------------------------------------------------
 
 hMC_Asym_0->Add(hMC_Sig_F_0, hMC_Sig_B_0, 1.0, -1.0);
 hMC_Asym_0->Divide(hMC_Sig_0);
 hMC_Asym_1->Add(hMC_Sig_F_1, hMC_Sig_B_1, 1.0, -1.0);
 hMC_Asym_1->Divide(hMC_Sig_1);
 hMC_Asym_2->Add(hMC_Sig_F_2, hMC_Sig_B_2, 1.0, -1.0);
 hMC_Asym_2->Divide(hMC_Sig_2);
 hMC_Asym_3->Add(hMC_Sig_F_3, hMC_Sig_B_3, 1.0, -1.0);
 hMC_Asym_3->Divide(hMC_Sig_3);
 hMC_Asym_4->Add(hMC_Sig_F_4, hMC_Sig_B_4, 1.0, -1.0);
 hMC_Asym_4->Divide(hMC_Sig_4);
 hMC_Asym_5->Add(hMC_Sig_F_5, hMC_Sig_B_5, 1.0, -1.0);
 hMC_Asym_5->Divide(hMC_Sig_5);
 hMC_Asym_6->Add(hMC_Sig_F_6, hMC_Sig_B_6, 1.0, -1.0);
 hMC_Asym_6->Divide(hMC_Sig_6);
 hMC_Asym_7->Add(hMC_Sig_F_7, hMC_Sig_B_7, 1.0, -1.0);
 hMC_Asym_7->Divide(hMC_Sig_7);

 TString Ylabel  = "A_{fb}";
 TString Xlabel  = "m_{#tau#tau} (GeV)";
 TString legend2 = "A_{fb} (Born IBA) ";
 drawOneOverlyNoError(hMC_Asym_2,
		    "hMC_Asym_2",
		      0.6, -0.4, Xlabel, Ylabel, legend1, legendspace, legendspace, legend2, 1, 0);
  
 hMC_Asym_2_delt_1->Add(hMC_Asym_2, hMC_Asym_1, 1.0, -1.0 );
 
 TString Ylabel  = "#Delta";
 TString Xlabel  = "m_{#tau#tau} (GeV)";
 TString legend2 = "#Delta A_{fb} = A_{fb} (Born IBA) - A_{fb} (Born EW LO #alpha(0))";
 drawOneOverlyNoError(hMC_Asym_2_delt_1,
		     "hMC_Asym_2_delt_1",
		      0.10, -0.02, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 1);
  
 hMC_Asym_3_delt_1->Add(hMC_Asym_3, hMC_Asym_1, 1.0, -1.0 );
 
 TString Ylabel  = "#Delta";
 TString Xlabel  = "m_{#tau#tau} (GeV)";
 TString legend2 = "#Delta A_{fb} = A_{fb} (Born EW LO G_{#mu}) - A_{fb} (Born EW LO #alpha(0))";
 drawOneOverlyNoError(hMC_Asym_3_delt_1,
		     "hMC_Asym_3_delt_1",
		      0.05, -0.02, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 1);
  
 hMC_Asym_3_delt_2->Add(hMC_Asym_3, hMC_Asym_2, 1.0, -1.0 );
 
 TString Ylabel  = "#Delta";
 TString Xlabel  = "m_{#tau#tau} (GeV)";
 TString legend2 = "#Delta A_{fb} = A_{fb} (Born EW LO G_{#mu} ) - A_{fb} (IBA)";
 drawOneOverlyNoError(hMC_Asym_3_delt_2,
		     "hMC_Asym_3_delt_2",
		      0.01, -0.02, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 1);
 
 hMC_Asym_4_delt_2->Add(hMC_Asym_4, hMC_Asym_2, 1.0, -1.0 );

 TString Ylabel  = "#Delta";
 TString Xlabel  = "m_{#tau#tau} (GeV)";
 TString legend2 = "#Delta A_{fb} = A_{fb} (Born Eff. v0) - A_{fb} (IBA)";
 drawOneOverlyNoError(hMC_Asym_4_delt_2,
		     "hMC_Asym_4_delt_2",
		      0.01, -0.005, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 1);
   
 hMC_Asym_5_delt_2->Add(hMC_Asym_5, hMC_Asym_2, 1.0, -1.0 );

 TString Ylabel  = "#Delta";
 TString Xlabel  = "m_{#tau#tau} (GeV)";
 TString legend2 = "#Delta A_{fb} = A_{fb} (Born Eff. v1) - A_{fb} (IBA)";
 drawOneOverlyNoError(hMC_Asym_5_delt_2,
		     "hMC_Asym_5_delt_2",
		      0.01, -0.005, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 1);
   
 hMC_Asym_6_delt_2->Add(hMC_Asym_6, hMC_Asym_2, 1.0, -1.0 );

 TString Ylabel  = "#Delta";
 TString Xlabel  = "m_{#tau#tau} (GeV)";
 TString legend2 = "#Delta A_{fb} = A_{fb} (Born Eff. v2) - A_{fb} (Born IBA)";
 drawOneOverlyNoError(hMC_Asym_6_delt_2,
		     "hMC_Asym_6_delt_2",
		      0.01, -0.005, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 1);
   
 hMC_Asym_7_delt_2->Add(hMC_Asym_7, hMC_Asym_2, 1.0, -1.0 );

 TString Ylabel  = "#Delta";
 TString Xlabel  = "m_{#tau#tau} (GeV)";
 TString legend2 = "#Delta A_{fb} = A_{fb} (Born Eff. v3) - A_{fb} (Born IBA)";
 drawOneOverlyNoError(hMC_Asym_7_delt_2,
		     "hMC_Asym_7_delt_2",
		      0.01, -0.005, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0, 1);


  return;

}
