#include <iostream>
#include <fstream>
#include <complex>
#include <string>
#include "TauSpinner/ew_born.h"
#include "TauSpinner/EWtables.h"

#include "eventReader.h"

// HepMC IO_GenEvent header
#include "HepMC/IO_GenEvent.h"

// TAUOLA header
#include "Tauola/Tauola.h"

#include "TauSpinner/Particle.h"
#include "TauSpinner/SimpleParticle.h"
#include "TauSpinner/tau_reweight_lib.h"
#include "TauSpinner/nonSM.h"
#include "TauSpinner/EWtables.h"

// LHAPDF header
#include "LHAPDF/LHAPDF.h"

using namespace std;
using namespace TauSpinner;
using namespace Tauolapp;

//ROOT headers
#include "TH1.h"
#include "TF1.h"   
#include "TFile.h"

// czy to jest potrzebne?
double nonSM_adopt(int ID, double S, double cost, int H1, int H2, int key)
// extern "C" double distjkwk_(int*, double*, double*, int*, int*, int*);
{
  int ID2=3-ID;
  // for distjkwk_ conventions
  if(ID2<1) ID2=ID2+2;  // Since Feb 2016  we allow ID in range [1,5]
  if(ID2<1) ID2=ID2+2;
  int HH1= H1;   // to be fixed a bit later.
  int HH2=-H2;
  //  an example of use:
  //  return distjkwk_(&ID2, &S, &cost, &HH1, &HH2, &key);
  //  }
 
      cout<<"             this function is dummy\n"<<endl;
      cout<<"             user must provide his own nonSM_born"<<endl;
      cout<<"             that is nonSM_adopt()"<<endl;
      exit(-1);
      return 1.0;
}


/*
   EW born can be initialized with the options  passed  through the
   dummy call on sigbornswdelt() the function which is used here 
   as void, but its returned value is used for graphics in Dizet-example.
*/
void EWreInit(int variant){

       int mode=0;
       double GAMZ=2.495378490842;
       double AMZ0=91.1876;
       double s2w=0.231499;
       double DeltSQ=0.;
       double DeltV=0.;
       double Gmu=0.00001166389;
       double alfinv=128.9503020;
       int keyGSW=1;

       int ID=1;// dummy
       double s=(AMZ0)*(AMZ0);// dummy
       double si;// dummy
       double cc=0.5;// dummy

       if(variant==0){ //Born setup Tauola
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=2;  // no FF, fixed width
	 AMZ0=91.1887;
	 GAMZ=2.49520;
	 s2w=0.231520;
	 Gmu=0.00001166389;
	 alfinv=128.86674175;
       }
       if(variant==1){ //EW LO alpha(0) scheme
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=11;  // no FF, running width
	 GAMZ=2.49520;
         s2w=0.2121517;
	 alfinv =137.035999139;
       }      
       if(variant==2){ //EW NLO+HO alpha(0)
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=1;   // complete FF, running width
	 GAMZ=2.49520;
	 s2w=0.223401084;
	 alfinv =137.035999139;
       }
       if(variant==3){ //EW LO Gmu scheme
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=11;   // no FF, running width
	 GAMZ=2.49520;
	 s2w=0.2228972;
	 alfinv=132.233323;
       }
       if(variant==4){ //Born effective parametrised according to Dizet 6.45 EWPO
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=11;   // no FF, running width
	 GAMZ=2.49520;
	 s2w=0.231499;
	 alfinv=128.9503020;
       }
       if(variant==5){ //Born effective parametrised according to Dizet 6.45 EWPO
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=3;   // used selected FF(MZ), running width
	 GAMZ=2.49520;
	 s2w=0.231499;
	 alfinv=137.035999139;
       }
       if(variant==6){ //Born effective parametrised according to Dizet 6.45 EWPO
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=4;   // used selected FF(MZ), running width
	 GAMZ=2.49520;
	 s2w=0.231499;
	 alfinv=137.035999139;
       }
       if(variant==7){ //Born effective parametrised according to Dizet 6.45 EWPO
	 setNonSMkey(1);
	 mode=0;
	 keyGSW=5;   // used selected FF(MZ), running width
	 GAMZ=2.49520;
	 s2w=0.2228972;
	 alfinv=137.035999139;
       }
       si=sigbornswdelt(mode,ID, s, cc, s2w, DeltSQ, DeltV, Gmu, alfinv, AMZ0, GAMZ, keyGSW);
}

/*
   Introduce variation for effective loop corrected Born of Dizet library.
   Some formfactors may be switched off or anomalous couplings added.
*/
void EWanomInit(){

   int FLAV=2;
   double AMZ00=Amz(FLAV);

   double SWeff=0.2121517;
   double DeltSQ=0.;
   double DeltV=0.;
   double Gmu=0.00001166389;
   double alfinv=137.0359895;
   int keyGSW=1;
   double AMZi=91.18870000;
   double GAM=2.49520000;
 
   ExtraEWparamsSet(AMZi, GAM, SWeff, alfinv,DeltSQ, DeltV, Gmu,keyGSW);

}
 
double calculate_signedcosthe(double S, SimpleParticle &taum, SimpleParticle &taup)
{
  Particle tau_minus(  taum.px(),  taum.py(),  taum.pz(),  taum.e(),  taum.pdgid());
  Particle tau_plus (  taup.px(),  taup.py(),  taup.pz(),  taup.e(),  taup.pdgid());


  // P_QQ = sum of tau+ and tau- in lab frame
  Particle P_QQ( tau_plus.px()+tau_minus.px(), tau_plus.py()+tau_minus.py(), tau_plus.pz()+tau_minus.pz(), tau_plus.e()+tau_minus.e(), 0 );
  
  Particle P_B1(0, 0, 1, 1, 0);
  Particle P_B2(0, 0,-1, 1, 0);

  tau_plus. boostToRestFrame(P_QQ);
  tau_minus.boostToRestFrame(P_QQ);
  P_B1.     boostToRestFrame(P_QQ);
  P_B2.     boostToRestFrame(P_QQ);
  
  double costheta1 = (tau_plus.px()*P_B1.px()    +tau_plus.py()*P_B1.py()    +tau_plus.pz()*P_B1.pz()    ) /
                 sqrt(tau_plus.px()*tau_plus.px()+tau_plus.py()*tau_plus.py()+tau_plus.pz()*tau_plus.pz()) /
                 sqrt(P_B1.px()    *P_B1.px()    +P_B1.py()    *P_B1.py()    +P_B1.pz()    *P_B1.pz()    );

  double costheta2 = (tau_minus.px()*P_B2.px()    +tau_minus.py()*P_B2.py()    +tau_minus.pz()*P_B2.pz()    ) /
                 sqrt(tau_minus.px()*tau_minus.px()+tau_minus.py()*tau_minus.py()+tau_minus.pz()*tau_minus.pz()) /
                 sqrt(P_B2.px()    *P_B2.px()    +P_B2.py()    *P_B2.py()    +P_B2.pz()    *P_B2.pz()    );
               
  double sintheta1 = sqrt(1-costheta1*costheta1);
  double sintheta2 = sqrt(1-costheta2*costheta2);
  
  // Cosine of hard scattering
  double costhe = (costheta1*sintheta2 + costheta2*sintheta1) / (sintheta1 + sintheta2);

  // Here assign sign according to pseudorapidity of the Z-boson (laboratory frame)
  double sign = (taup.pz()+taum.pz())/fabs(taum.pz()+taup.pz());
  costhe = costhe*sign;

   
  return costhe;
  
}


  
// This is an example of the program reweighting unpolarized tau events.
int main(int argc, char **argv) {

  char *input_filename = "events.dat";
  
  if(argc<2)
  {
    cout<<endl<<"Processing all available events from default input file: "<<input_filename<<endl;
    cout<<      "You can change this option by using:   "<<argv[0]<<" <filename> [<events_limit>]"<<endl<<endl;
  }
  else input_filename = argv[1];

  //---------------------------------------------------------------------------
  //- Initialization ----------------------------------------------------------
  //---------------------------------------------------------------------------

  // Limit number of processed events
  int events_limit = 0;
  
  if(argc>2) events_limit = atoi(argv[2]);
  
  // Initialize Tauola
  Tauola::initialize();

  string name="MSTW2008nnlo90cl.LHgrid";
  LHAPDF::initPDFSetByName(name);

  
  double CMSENE = 13000.0; // center of mass system energy.
                          // used in PDF calculation. For pp collisions only
  bool Ipp = true;  // for pp collisions
  //bool Ipp = false; // otherwise (not prepared yet)

  int Ipol = 1; // are input samples polarized?

  int nonSM2 = 1; // are we using nonSM calculations?
                  // at present we have checked only that for nonSM2 = 0
                  // all works as in the past. nonSM2 = 1 default is for 
                  // claculation with electroweak corrections from KKMC library. 
                  // More tests are needed  for this option.
  int nonSMN = 0; // If we are using nonSM calculations we may want corrections 
                  // to shapes only: y/n  (1/0)
  int IFset=0;    // status variable whether user provided nonSM Born was set  
  int IFsetH=0;   // status variable whether user provided nonSM Born was set for Higgs channel


  //
  //#############
  // optional initialization for Dizet electroweak tables
  char* tabmu=     "table.mu-6.45";  
  char* tabdown=   "table.down-6.45";
  char* tabup=     "table.up-6.45";
  int initResult=initTables(tabmu,tabdown,tabup);
  EWanomInit();
  //#############
  
  // Initialize TauSpinner
  initialize_spinner(Ipp, Ipol, nonSM2, nonSMN,  CMSENE);
  
  /*
     Set function for user-defined  born, including new physics
     This function must be of format:

     double fun(int ID, double S, double cost, int H1, int H2, int key)

     Where: ID    -- 1 for down-type qqbar, 2 for up-type qqbar
            S     -- cm qqbar energy^2
            cost  -- cosTheta (scattering angle of tau- with respect to quark)
            H1,H2 -- spin state of first, second tau 
            key   -- 1 when new effect is added, 0  Standard Model

     If set to NULL, default function will be used.

     Here, as an example, we are using FUNCTION DISTR from file 'distr.f'
     file. Wrapper/adopter nonSM_adopt (adjustments for conventions of some input variables)  
     is defined earlier in our example.
  */

  //  set nonSM borns to user provided function, leave a track if it was done
  // IFset=set_nonSM_born( nonSM_adopt );
  // IFsetH=set_nonSM_bornH( nonSM_adoptH );
  
  // next line is needed for CP-test  CP-bench-pi
  // FOR SCALAR H USE:
  //setHiggsParametersTR(-1.0, 1.0, 0.0, 0.0);
  // FOR PSEUDOSCALAR A USE:
  //  setHiggsParametersTR( 1.0,-1.0, 0.0, 0.0);
  // for mixed parity case
  // double theta=0.2;
  // setHiggsParametersTR(-cos(2*theta),cos(2*theta) ,-sin(2*theta),-sin(2*theta));

  // Next line is needed for CP-test-Z-pi, CP-test-Z-rho
  // Switch components of transverse density matrix for DY
  //                  (Rxx,Ryy,Rxy,Ryx)
  //setZgamMultipliersTR(1., 1., 1., 1. );

  // For use of electroweak corrections KKMC style
  // default_nonSM_born and default_nonSM_bornH must be  used
  // user nonSM_born has a priority
   IFset=set_nonSM_born( NULL );
   IFsetH=set_nonSM_bornH( NULL );

  // Initialize EW tables and electroweak effective Born if it is requested
  if (nonSM2 ==1&& IFset==0){
   if (initResult == 1)cout << "EW tables initialized from: " << tabmu << " " << tabdown << " " << tabup << endl;
   if (initResult != 1){
      cout << "Error initializing tables from files " << tabmu << " " << tabdown << " " << tabup << endl;
      return -1;
   }
  }

  // histograms for: cross-sections, asymmetry, polarisation
  
  int NB=90;
  double Xmin= 65.0;
  double Xmax= 155.0;
  
  TH1D* hSig_0     = new TH1D("hSig_0"," ",NB,Xmin,  Xmax);
  TH1D* hSig_F_0   = new TH1D("hSig_F_0"," ",NB,Xmin,  Xmax);
  TH1D* hSig_B_0   = new TH1D("hSig_B_0"," ",NB,Xmin,  Xmax);
  TH1D* hAsym_0    = new TH1D("hAsym_0"," " ,NB,Xmin,  Xmax);
  TH1D* hPol_0     = new TH1D("hPol_0"," ",NB,Xmin,  Xmax);
  TH1D* hCosthe_0  = new TH1D("hCosthe_0"," ",NB,-1.0,  1.0);
  
  TH1D* hSig_1     = new TH1D("hSig_1"," ",NB,Xmin,  Xmax);
  TH1D* hSig_F_1   = new TH1D("hSig_F_1"," ",NB,Xmin,  Xmax);
  TH1D* hSig_B_1   = new TH1D("hSig_B_1"," ",NB,Xmin,  Xmax);
  TH1D* hAsym_1    = new TH1D("hAsym_1"," ",NB,Xmin,  Xmax);
  TH1D* hPol_1     = new TH1D("hPol_1"," ",NB,Xmin,  Xmax);
  TH1D* hCosthe_1  = new TH1D("hCosthe_1"," ",NB,-1.0,  1.0);
  
  TH1D* hSig_2    = new TH1D("hSig_2"," ",NB,Xmin,  Xmax);
  TH1D* hSig_F_2  = new TH1D("hSig_F_2"," ",NB,Xmin,  Xmax);
  TH1D* hSig_B_2  = new TH1D("hSig_B_2"," ",NB,Xmin,  Xmax);
  TH1D* hAsym_2   = new TH1D("hAsym_2"," ",NB,Xmin,  Xmax);
  TH1D* hPol_2    = new TH1D("hPol_2"," ",NB,Xmin,  Xmax);
  TH1D* hCosthe_2 = new TH1D("hCosthe_2"," ",NB,-1.0,  1.0);
  
  TH1D* hSig_3    = new TH1D("hSig_3"," ",NB,Xmin,  Xmax);
  TH1D* hSig_F_3  = new TH1D("hSig_F_3"," ",NB,Xmin,  Xmax);
  TH1D* hSig_B_3  = new TH1D("hSig_B_3"," ",NB,Xmin,  Xmax);
  TH1D* hAsym_3   = new TH1D("hAsym_3"," ",NB,Xmin,  Xmax);
  TH1D* hPol_3    = new TH1D("hPol_3"," ",NB,Xmin,  Xmax);
  TH1D* hCosthe_3 = new TH1D("hCosthe_3"," ",NB,-1.0,  1.0);
  
  TH1D* hSig_4    = new TH1D("hSig_4"," ",NB,Xmin,  Xmax);
  TH1D* hSig_F_4  = new TH1D("hSig_F_4"," ",NB,Xmin,  Xmax);
  TH1D* hSig_B_4  = new TH1D("hSig_B_4"," ",NB,Xmin,  Xmax);
  TH1D* hAsym_4   = new TH1D("hAsym_4"," ",NB,Xmin,  Xmax);
  TH1D* hPol_4    = new TH1D("hPol_4"," ",NB,Xmin,  Xmax);
  TH1D* hCosthe_4 = new TH1D("hCosthe_4"," ",NB,-1.0,  1.0);
  
  TH1D* hSig_5    = new TH1D("hSig_5"," ",NB,Xmin,  Xmax);
  TH1D* hSig_F_5  = new TH1D("hSig_F_5"," ",NB,Xmin,  Xmax);
  TH1D* hSig_B_5  = new TH1D("hSig_B_5"," ",NB,Xmin,  Xmax);
  TH1D* hAsym_5   = new TH1D("hAsym_5"," ",NB,Xmin,  Xmax);
  TH1D* hPol_5    = new TH1D("hPol_5"," ",NB,Xmin,  Xmax);
  TH1D* hCosthe_5 = new TH1D("hCosthe_5"," ",NB,-1.0,  1.0);
  
  TH1D* hSig_6    = new TH1D("hSig_6"," ",NB,Xmin,  Xmax);
  TH1D* hSig_F_6  = new TH1D("hSig_F_6"," ",NB,Xmin,  Xmax);
  TH1D* hSig_B_6  = new TH1D("hSig_B_6"," ",NB,Xmin,  Xmax);
  TH1D* hAsym_6   = new TH1D("hAsym_6"," ",NB,Xmin,  Xmax);
  TH1D* hPol_6    = new TH1D("hPol_6"," ",NB,Xmin,  Xmax);
  TH1D* hCosthe_6 = new TH1D("hCosthe_6"," ",NB,-1.0,  1.0);
  
  TH1D* hSig_7    = new TH1D("hSig_7"," ",NB,Xmin,  Xmax);
  TH1D* hSig_F_7  = new TH1D("hSig_F_7"," ",NB,Xmin,  Xmax);
  TH1D* hSig_B_7  = new TH1D("hSig_B_7"," ",NB,Xmin,  Xmax);
  TH1D* hAsym_7   = new TH1D("hAsym_7"," ",NB,Xmin,  Xmax);
  TH1D* hPol_7    = new TH1D("hPol_7"," ",NB,Xmin,  Xmax);
  TH1D* hCosthe_7 = new TH1D("hCosthe_7"," ",NB,-1.0,  1.0);

  
  // Open I/O files  (in our example events are taken from "events.dat")
  HepMC::IO_GenEvent input_file(input_filename,std::ios::in);
   //---------------------------------------------------------------------------
  //- Event loop --------------------------------------------------------------
  //---------------------------------------------------------------------------
  int events_count = 0;
  
  while(true) {
    double WT1    = 1.0, WT2    = 1.0;  // we assume that there may be be at most two bosons decaying into
    int    pdgid1 = 0,   pdgid2 = 0;    // taus (tau neutrinos) and requiring reweight

    SimpleParticle X, tau, tau2;      // SimpleParticle consist of 4 momentum and PDGid.
    vector<SimpleParticle> tau_daughters, tau_daughters2;

    // Here, we read another event from input_file.
    
    // In this example, we use event generated by Pythia8 with tau decays from
    // Pythia8 or Tauola++.

    // NOTE: for W+/- or H+/- tau2 contain neutrino and tau_daughters2 is empty
    // User may introduce his own method of initializing X, tau, tau2, tau_daughters, tau_daughters2.
    int status =  read_HepMC(input_file, X, tau, tau2, tau_daughters, tau_daughters2);

    // Go to next one if there is nothing more to do with this event
    if( status==1 ) continue;
    
    // Finish if there is nothing more to read from the file
    if( status==0 ) break;
    
    events_count++;
    
    pdgid1 = X.pdgid();
    // nonSM2=1 !!  Special case for reweighting with user defined contribution to Born: can be Z', spin 2 state etc.
    //              WT1 is calculate   for gamma/Z sample with spin effects  included.
    
    // basic initialization of nonSM Born
    EWreInit(0); // Effective Born as in Tauola
    WT1 = calculateWeightFromParticlesH(X, tau, tau2, tau_daughters,tau_daughters2);  
    double wtnonSM = getWtNonSM();    
    double wtBornTauola = wtnonSM;
    
    // basic initialization of nonSM Born
    EWreInit(1); // EW LO alpha(0)
    WT1 = calculateWeightFromParticlesH(X, tau, tau2, tau_daughters,tau_daughters2); 
    double wtBornEWLO = getWtNonSM()/wtnonSM;
    
    EWreInit(2); // EW NLO+HO alpha(0)
    WT1 = calculateWeightFromParticlesH(X, tau, tau2, tau_daughters,tau_daughters2); 
    double wtBornIBA = getWtNonSM()/wtnonSM;
    
    EWreInit(3); // EW LO Gmu
    WT1 = calculateWeightFromParticlesH(X, tau, tau2, tau_daughters,tau_daughters2); 
    double wtBornEWLOGmu = getWtNonSM()/wtnonSM;
     
    EWreInit(4); // Effective Born_v0 a la Dizet 6.45
    WT1 = calculateWeightFromParticlesH(X, tau, tau2, tau_daughters,tau_daughters2); 
    double wtBornEff_v0 = getWtNonSM()/wtnonSM;

    EWreInit(5); // Effective Born_v1 a la Dizet 6.45
    WT1 = calculateWeightFromParticlesH(X, tau, tau2, tau_daughters,tau_daughters2); 
    double wtBornEff_v1 = getWtNonSM()/wtnonSM;

    EWreInit(6); // Effective Born_v2 a la Dizet 6.45
    WT1 = calculateWeightFromParticlesH(X, tau, tau2, tau_daughters,tau_daughters2); 
    double wtBornEff_v2 = getWtNonSM()/wtnonSM;

    EWreInit(7); // Effective Born_v3 a la Dizet 6.45
    WT1 = calculateWeightFromParticlesH(X, tau, tau2, tau_daughters,tau_daughters2); 
    double wtBornEff_v3 = getWtNonSM()/wtnonSM;
     
    
    double cmsene=sqrt((tau.e()+tau2.e())*(tau.e()+tau2.e())
		       -(tau.px()+tau2.px())*(tau.px()+tau2.px())
		       -(tau.py()+tau2.py())*(tau.py()+tau2.py())
		       -(tau.pz()+tau2.pz())*(tau.pz()+tau2.pz()) );
    double s = cmsene*cmsene;
    double costhe = calculate_signedcosthe(s, tau, tau2);
    
    hSig_0->Fill(cmsene,  wtBornTauola);	
    hSig_1->Fill(cmsene,  wtBornEWLO);
    hSig_2->Fill(cmsene,  wtBornIBA);
    hSig_3->Fill(cmsene,  wtBornEWLOGmu);
    hSig_4->Fill(cmsene,  wtBornEff_v0);
    hSig_5->Fill(cmsene,  wtBornEff_v1);
    hSig_6->Fill(cmsene,  wtBornEff_v2);
    hSig_7->Fill(cmsene,  wtBornEff_v3);
     
    if( costhe > 0 ) {
      hSig_F_0->Fill(cmsene,  wtBornTauola);
      hSig_F_1->Fill(cmsene,  wtBornEWLO);
      hSig_F_2->Fill(cmsene,  wtBornIBA);
      hSig_F_3->Fill(cmsene,  wtBornEWLOGmu);
      hSig_F_4->Fill(cmsene,  wtBornEff_v0);
      hSig_F_5->Fill(cmsene,  wtBornEff_v1);
      hSig_F_6->Fill(cmsene,  wtBornEff_v2);
      hSig_F_7->Fill(cmsene,  wtBornEff_v3);
    } else {
      hSig_B_0->Fill(cmsene,  wtBornTauola);
      hSig_B_1->Fill(cmsene,  wtBornEWLO);
      hSig_B_2->Fill(cmsene,  wtBornIBA);
      hSig_B_3->Fill(cmsene,  wtBornEWLOGmu);
      hSig_B_4->Fill(cmsene,  wtBornEff_v0);
      hSig_B_5->Fill(cmsene,  wtBornEff_v1);
      hSig_B_6->Fill(cmsene,  wtBornEff_v2);
      hSig_B_7->Fill(cmsene,  wtBornEff_v3);
    }
    
    hCosthe_0->Fill(costhe,  wtBornTauola);	
    hCosthe_1->Fill(costhe,  wtBornEWLO);
    hCosthe_2->Fill(costhe,  wtBornIBA);
    hCosthe_3->Fill(costhe,  wtBornEWLOGmu);
    hCosthe_4->Fill(costhe,  wtBornEff_v0);
    hCosthe_5->Fill(costhe,  wtBornEff_v1);
    hCosthe_6->Fill(costhe,  wtBornEff_v2);
    hCosthe_7->Fill(costhe,  wtBornEff_v3);
    
    if( events_count < 100){
      printf(" Event No:%5i Inv mass=%13.6f costhe=%13.6f",events_count+1,cmsene, costhe);
      // alfinv=137.0359895;
      // wtnonSM*alfinv*alfinv; //  needed for normalization matching of Tauola born and nonSM born 
      printf(" wtBornTauola:%13.10f wtBornEWLO = %13.10f wtBornIBA = %13.10f wtBornEff_v0 = %13.10f wtBornEff_v2 = %13.10f wtBornEff_v3 = %13.10f\n",
	       wtBornTauola, wtBornEWLO, wtBornIBA, wtBornEff_v0, wtBornEff_v2, wtBornEff_v3);
    }

    if( events_count%1000 == 0) printf(" Event No:%5i \n",events_count+1);

  }
  
  // writing histograms to file     
  TFile *file = new TFile("EWPO_MCevt_test.root","recreate");

  // using weight from TauSpinner
  hSig_1->Write();
  hSig_F_1->Write();
  hSig_B_1->Write();
  hAsym_1->Write();
  hPol_1->Write();
  hCosthe_1->Write();

  hSig_0->Write();
  hSig_F_0->Write();
  hSig_B_0->Write();
  hAsym_0->Write();
  hPol_0->Write();
  hCosthe_0->Write();

  hSig_2->Write();
  hSig_F_2->Write();
  hSig_B_2->Write();
  hAsym_2->Write();
  hPol_2->Write();
  hCosthe_2->Write();

  hSig_3->Write();
  hSig_F_3->Write();
  hSig_B_3->Write();
  hAsym_3->Write();
  hPol_3->Write();
  hCosthe_3->Write();

  hSig_4->Write();
  hSig_F_4->Write();
  hSig_B_4->Write();
  hAsym_4->Write();
  hPol_4->Write();
  hCosthe_4->Write();

  hSig_5->Write();
  hSig_F_5->Write();
  hSig_B_5->Write();
  hAsym_5->Write();
  hPol_5->Write();
  hCosthe_5->Write();

  hSig_6->Write();
  hSig_F_6->Write();
  hSig_B_6->Write();
  hAsym_6->Write();
  hPol_6->Write();
  hCosthe_6->Write();

  hSig_7->Write();
  hSig_F_7->Write();
  hSig_B_7->Write();
  hAsym_7->Write();
  hPol_7->Write();
  hCosthe_7->Write();

 

  file->Close();
   
}

      
