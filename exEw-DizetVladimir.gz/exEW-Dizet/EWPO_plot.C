#include "DefPlots.h"

void EWPO_plot()
{ 

 gStyle->SetStatColor(0);
 gStyle->SetTitleFillColor(0);

 gROOT->SetStyle("ATLAS");
 gROOT->ForceStyle();

//-------------------------------------------------------------------------------------------------------
TFile *fout  = TFile::Open("EWPO_test.root");
//-------------------------------------------------------------------------------------------------------

 TString legendspace = " ";

 
//-------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------

 TString legend1 = "e^{+}e^{-} #rightarrow #mu^{+}#mu^{-} ";
 TString Xlabel  = "m_{#mu#mu} (GeV)";
 
 TString Ylabel  = "#sigma^{tot}";
 TString legend2 = "#sigma^{tot} (Born EW) ";
 drawOneOverlyNoError(hSig_001,
		    "hSig_001",
		      0.15, 0.0, Xlabel, Ylabel, legend1, legendspace, legendspace, legend2, 0, 0);

 hSig_000->Divide(hSig_001);
 TString Ylabel  = "Ratio";
 TString legend2 = "Ratio #sigma^{tot} (Born Eff.)/#sigma^{tot} (Born EW)";
 drawOneOverlyNoError(hSig_000,
		     "hSig_000_ratio_001",
		      1.0008, 1.00, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0);

 TString Ylabel  = "A_{fb}";
 TString legend2 = "A_{fb} (Born EW) ";
 drawOneOverlyNoError(hAsym_001,
		    "hAsym_001",
		      1.0, -1.0, Xlabel, Ylabel, legend1, legendspace, legendspace, legend2, 1, 0);

 hAsym_000->Add(hAsym_000, hAsym_001,1.0,-1.0 );
 TString Ylabel  = "#Delta";
 TString legend2 = "#Delta A_{fb} = A_{fb} (Born Eff.) - A_{fb} (Born EW)";
 drawOneOverlyNoError(hAsym_000,
		     "hAsym_000_delta_001",
		      -0.001, -0.002, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0);

 TString legend1 = "e^{+}e^{-} #rightarrow #tau^{+}#tau^{-} ";
 TString Xlabel  = "m_{#tau#tau} (GeV)";

 TString Ylabel  = "Pol";
 TString legend2 = "Pol (Born EW) ";
 drawOneOverlyNoError(hPol_001,
		    "hPol_001",
		      0.3, 0.0, Xlabel, Ylabel, legend1, legendspace, legendspace, legend2, 1, 0);

 hPol_000->Add(hPol_000, hPol_001,1.0,-1.0 );
 TString Ylabel  = "#Delta";
 TString legend2 = "#Delta Pol = Pol (Born Eff.) - Pol (Born EW)";
 drawOneOverlyNoError(hPol_000,
		     "hPol_000_delta_001",
		      0.003, 0.0, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0);


//-------------------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------

 TString legend1 = "e^{+}e^{-} #rightarrow d^{+}d^{-} ";
 TString Xlabel  = "m_{dd} (GeV)";
 
 TString Ylabel  = "#sigma^{tot}";
 TString legend2 = "#sigma^{tot} (Born EW) ";
 drawOneOverlyNoError(hSig_101,
		    "hSig_101",
		      0.30, 0.0, Xlabel, Ylabel, legend1, legendspace, legendspace, legend2, 0, 0);

 hSig_100->Divide(hSig_101);
 TString Ylabel  = "Ratio";
 TString legend2 = "Ratio #sigma^{tot} (Born Eff.)/#sigma^{tot} (Born EW)";
 drawOneOverlyNoError(hSig_100,
		     "hSig_100_ratio_001",
		      0.999, 0.998, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0);


 TString Ylabel  = "A_{fb}";
 TString legend2 = "A_{fb} (Born EW) ";
 drawOneOverlyNoError(hAsym_101,
		    "hAsym_101",
		      0.3, -0.1, Xlabel, Ylabel, legend1, legendspace, legendspace, legend2, 1, 0);

 hAsym_100->Add(hAsym_100, hAsym_101,1.0,-1.0 );
 TString Ylabel  = "#Delta";
 TString legend2 = "#Delta A_{fb} = A_{fb} (Born Eff.) - A_{fb} (Born EW)";
 drawOneOverlyNoError(hAsym_100,
		     "hAsym_100_delta_101",
		      0.001, -0.0015, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0);
 
 
//-------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------
 

 TString legend1 = "e^{+}e^{-} #rightarrow u^{+}u^{-} ";
 TString Xlabel  = "m_{uu} (GeV)";
 
 TString Ylabel  = "#sigma^{tot}";
 TString legend2 = "#sigma^{tot} (Born EW) ";
 drawOneOverlyNoError(hSig_201,
		    "hSig_201",
		      0.30, 0.0, Xlabel, Ylabel, legend1, legendspace, legendspace, legend2, 0, 0);

 hSig_200->Divide(hSig_201);
 TString Ylabel  = "Ratio";
 TString legend2 = "Ratio #sigma^{tot} (Born Eff.)/#sigma^{tot} (Born EW)";
 drawOneOverlyNoError(hSig_200,
		     "hSig_200_ratio_001",
		      1.0020, 0.9985, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0);


 TString Ylabel  = "A_{fb}";
 TString legend2 = "A_{fb} (Born EW) ";
 drawOneOverlyNoError(hAsym_201,
		    "hAsym_201",
		      0.5, -0.3, Xlabel, Ylabel, legend1, legendspace, legendspace, legend2, 1, 0);

 hAsym_200->Add(hAsym_200, hAsym_201,1.0,-1.0 );
 TString Ylabel  = "#Delta";
 TString legend2 = "#Delta A_{fb} = A_{fb} (Born Eff.) - A_{fb} (Born EW)";
 drawOneOverlyNoError(hAsym_200,
		     "hAsym_200_delta_201",
		      0.001, -0.003, Xlabel, Ylabel, legend1,legendspace ,legendspace, legend2, 1, 0);
 
 return;
//-------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------



 
 

 TString Ylabel  = "A_{FB} (EW)";
 drawOneOverlyNoError(hout_645_exact_complex_Asym1,
		    "h_Asym1_trace_effective",
		      0.6, -0.6, Xlabel, Ylabel, legend1, legendempty, legendempty, legend3, 1, 0);

 hout_645_exact_complex_Asym1->Add(hout_645_exact_complex_Asym1, hout_645_exact_complex_Asym0, 1.0, -1.0);
 hout_645_effective_Asym1->Add(hout_645_effective_Asym1, hout_645_effective_Asym0, 1.0, -1.0);
 hout_645_real_v_Asym1->Add(hout_645_real_v_Asym1, hout_645_real_v_Asym0, 1.0, -1.0);
 TString legend2 = "A_{FB} (EW) - A_{FB} (Born)  ";
 TString Ylabel  = "#Delta A_{FB}";
 drawThreeOverlyNoError(hout_645_exact_complex_Asym1,hout_645_effective_Asym1,hout_645_real_v_Asym1,
		    "h_deltAsym1_trace_effective",
		      0.003, -0.0005, Xlabel, Ylabel, legend1, legend2, legendempty, legend3, legend4, legend5, 0, 0, 1);

 //------------------------------------------------------------------
 
 TString Xlabel  = "m_{#tau#tau} (GeV)";

 TString legend1 = "e^{+}e^{-} #rightarrow #tau^{+}#tau^{-} ";

 TString Ylabel  = "P_{#tau} (EW)";
 drawOneOverlyNoError(hout_645_exact_complex_Pol0,
		    "h_Pol1_trace_effective",
		    0.2, 0.0, Xlabel, Ylabel, legend1, legend2, legend2, legend3, 1, 0);

 hout_645_exact_complex_Pol1->Add(hout_645_exact_complex_Pol1, hout_645_exact_complex_Pol0, 1.0, -1.0);
 hout_645_effective_Pol1->Add(hout_645_effective_Pol1, hout_645_effective_Pol0, 1.0, -1.0);
 hout_645_real_v_Pol1->Add(hout_645_real_v_Pol1, hout_645_real_v_Pol0, 1.0, -1.0);
 TString legend2 = "#Delta P_{#tau} (EW) - #Delta P_{#tau} (Born)  ";
 TString Ylabel  = "#Delta P_{#tau}";
 drawThreeOverlyNoError(hout_645_exact_complex_Pol1, hout_645_effective_Pol1, hout_645_real_v_Pol1,
		    "h_deltPol1_trace_effective",
		    0.001, -0.002, Xlabel, Ylabel, legend1, legend2, legendempty, legend3, legend4, legend5, 0, 0, 1);

  return;
  
}
